import { fileURLToPath } from "node:url";
import { configDefaults, defineConfig, mergeConfig } from "vitest/config";

import { coverageExcludes } from "@quiverai/tooling/vitest-coverage";
import { vitestPackagePreset } from "@quiverai/tooling/vitest-package-preset";

const floored = ["src/mastra/lib/directory/join.ts"];

export default defineConfig(
  mergeConfig(
    vitestPackagePreset("packages/mastra", {
      exclude: coverageExcludes,
      include: floored,
      provider: "v8",
      thresholds: { branches: 98, functions: 98, lines: 98, statements: 98 },
    }),
    {
      test: {
        // `mastra dev` writes a build tree under `.mastra/output/` that vendors
        // dependency SOURCE, including zod's own test suite, whose dev
        // dependencies are not installed here. Vitest's default exclude misses
        // it because the directory is named `node_modules.__tmp`.
        exclude: [...configDefaults.exclude, ".mastra/**"],
      },
      resolve: {
        alias: { "@": fileURLToPath(new URL("src", import.meta.url)) },
      },
    },
  ),
);
