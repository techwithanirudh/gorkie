# archy — open work

Backlog for `@quiverai/mastra` ([ENG-5412](https://linear.app/quiverai/issue/ENG-5412)).

These are engineering notes, not Linear issues. `docs/agents/issue-tracker.md` gates what
reaches Linear: paper cuts, cleanups and speculative work stay out of it, and an unowned
issue is cancelled after 168 hours. Only items with a real owner and a bounded outcome
graduate to a sub-issue of ENG-5412.

## P1

- [ ] **Move Mastra off the 1.69 alphas.** archy pins `@mastra/core`, `@mastra/deployer`
      and `@mastra/server` at `1.69.0-alpha.1`, `@mastra/deployer-vercel` at
      `1.2.28-alpha.1` and the `mastra` CLI at `1.31.1-alpha.2`, because deployer 1.69
      (mastra-ai/mastra#21716) carries workspace pnpm patches into the build output and
      replaced `scripts/postbuild.mjs`. When `1.69.0` is released, move to it, rebase
      `patches/@mastra+core@*.patch`, and confirm the built output's `@mastra/core`
      still contains `advanceFallbackModel`. Rollup content-hashes the bundle names, so a
      version change renames `dist/agent-*.js` and a stale patch fails with
      `ERR_PNPM_PATCH_FAILED`. Drop the `minimumReleaseAgeExclude` entries for them in
      `pnpm-workspace.yaml` after 2026-09-25.
- [ ] **First Vercel deploy.** `archy-mastra` deploys this branch as production, with no
      preview deployments. To do: link Git with root directory `packages/mastra` and
      "include files outside root directory"; set the production env vars, including a
      fresh `MASTRA_API_TOKEN`; turn on large functions, because the function is about 600 MB
      against a 250 MB standard limit; confirm the plan covers `maxDuration: 1800`; create
      the dev Slack app from `slack-manifest.dev.json`; and reinstall both Slack apps for
      the trimmed scopes and the `app_home_opened` and `agent_session_stopped` events.
- [ ] **Scheduled tasks and `wait` on Vercel.** Mastra's scheduler ticks only in a
      long-running process, so on Vercel it is off and the model is not offered `wait` or
      the scheduled-task tools. Bringing them back needs an external tick.
- [x] **Switch the channel state adapter.** `channels.state` is a
      `RedisStateAdapter` (`chat/state.ts`), so thread subscriptions, locks and
      dedupe keys are shared by every instance, and one tagged message gets one reply.
- [ ] **Set `REDIS_URL` in Vercel before the next deploy.** Add Upstash for Redis from
      the Vercel Marketplace and connect it to `archy-mastra` Production; it injects
      `REDIS_URL`. `src/env.ts` refuses to boot on Vercel without it. Threads archy
      followed before the switch need one fresh tag.
- [ ] **Stop across instances.** `!stop` and Slack's Stop button reach the running turn
      only when they land on the Vercel instance running it. Set `channels.pubsub` to
      Mastra's `RedisStreamsPubSub` (`@mastra/redis-streams`), on the same Redis as the
      state adapter, and it routes the signal to the instance that owns the run. Anyone
      in the thread may answer an approval card: the requester-only patch was dropped.

- [ ] **Rotate every credential onto company-owned accounts.** The deploy runs on
      keys issued to personal accounts during development; replace each in Vercel
      Production and the local `.env`. Rotate `GITHUB_APP_PRIVATE_KEY` first, because
      a test script printed it into a coding-agent session transcript on 2026-09-23.
      Get company keys for `EXA_API_KEY` and the three `LANGFUSE_*` values from
      Nicklas.
- [ ] Reissue each personal key under a bot or service account. `LINEAR_API_KEY` is
      personal, so Linear's `me` resolves to that person. `POSTHOG_API_KEY` is a
      personal `phx_` key. `VERCEL_TOKEN` carries full team access, because Vercel has
      no read-only tokens.
- [ ] Ask E2B for a company account and move `E2B_API_KEY` to it. Regenerate
      `MASTRA_API_TOKEN` and `DATABASE_AUTH_TOKEN` if they were ever shared.

## Relevance engine: silent triage

- [ ] Build the unattended triage mode. The classifier gets a code-side gate. Unattended
      turns get their own prompt set, a processor that drops every text part, and a
      `reply` tool as the only way to speak. It uses new `triage` and `linear` skills and
      a 👀 reaction while it works. Follow-ups need a tag. There is no step budget and no
      channel cap. Ship only at 0.9 or better triage and answer precision on about 100
      labelled messages.
- [ ] First, fix the missing `→` markers on prompted turns. `connectors.ts` and
      `slack.ts` still tell the model not to narrate.
- [ ] Unprompted turns skip `runTurn`, so they get neither `withHistory` nor the
      attachment handling that tagged turns get.

## Workspace-level memory

- [ ] archy has no shared memory of the workspace itself. Memory is per thread
      (observational, with semantic `recall` across threads) and per person (the
      working-memory profile). The `<directory>` block covers who is who. Nothing yet
      covers who works on what, which decisions are settled, or who owns which area.

## Decisions still open

- [ ] **Memory scope.** Observations stay thread-scoped. `retrieval: { vector: true }`
      gives `recall` a semantic mode across threads, using `bge-m3` on Workers AI, which
      handles cross-lingual queries. Resource scope stays off, because Mastra marks it
      experimental and one thread can pick up another's unfinished work.
- [ ] **Package location.** ENG-5412 records `internal/**` as the intended home. This
      lives at `packages/mastra`.
- [ ] **Licensing.** Upstream `LICENSE` is AGPL-3.0-only and was not vendored. Settle it
      before this merges.

## Dependency work

- [ ] **`typescript: 6.0.3` pin is a workaround.** The rest of the monorepo runs
      TypeScript 7. `@mastra/deployer` depends on `typescript-paths@1.5.2`, which reads
      `ts.sys`, and TypeScript 7 does not expose it, so `mastra build` dies in dependency
      analysis. An override does not fix a peer. Remove the pin once `typescript-paths`
      supports TypeScript 7.
- [ ] **Root `overrides` reach this package.** `pnpm-workspace.yaml` `overrides` apply to
      every resolution in the workspace. `js-yaml: "4.3.0"` makes Mastra's
      `WorkspaceSkills` fail skill loads with "Function yaml.safeLoad is removed in
      js-yaml 4". The caller is still unidentified.

## Architecture

- [ ] **E2B → Vercel Sandbox.** `src/mastra/workspace/` is E2B-specific and `E2B_API_KEY`
      is required. `@mastra/vercel`'s `VercelSandbox` is a Workspace provider that could
      replace the hand-rolled `workspace/filesystem.ts`. It would need its own native
      `grep()` too, or Mastra's grep falls back to reading one file at a time. The Vercel
      sandbox filesystem is per session.

## Hygiene

- [ ] **Mastra evals.** No datasets or scorers yet. Build two: classifier precision and
      recall scored separately and shared with ENG-5409, and answer quality, meaning
      whether the answer is sourced and whether its citation supports it. Real Slack
      history is a free source of labels.
- [ ] **Upstream Mastra issues.** Drafts are ready for seven new issues: code mode
      skips tool approval, `logger.child("CHANNEL")` spreads a string, the `add_reaction`
      system prompt, no public thread-to-memory lookup, no per-server tool filter in
      `MCPClient`, `@mastra/e2b` hard-codes `--depth=1`, and `REPROCESS_PART_KEY` is not
      exported. Comment on #21875 and PR #24475 rather than filing duplicates.
- [ ] **Rewrite README.md.** It still describes the AI Gateway, Postgres and removed
      features.

## Ranked search over the repository, if grep ever proves not enough

- [ ] A BM25 index over the monorepo's prose was built and removed. It indexed 215 files
      in about 207ms, but it indexed a staler copy of files the agent can already grep.
      Rebuild it only if ranking beats grep on real questions; the shape is in git
      history.
- [ ] Measurements worth keeping. Vector search over the same corpus took 49s against
      179ms for BM25, and upserting one row at a time blocked the event loop.
      `maxBatchSize: 2048` exceeds the embedding API's 300,000-token request limit, and
      Mastra then silently falls back to one chunk per request; 128 is safe for
      4,000-character chunks. The sandbox `Workspace` cannot index its own filesystem,
      because `filesystem` is a per-thread resolver.
