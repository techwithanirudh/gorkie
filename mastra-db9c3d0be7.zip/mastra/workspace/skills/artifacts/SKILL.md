---
name: artifacts
description: Build a self-contained HTML page and put it behind a link archy can paste into Slack. Use when an answer is better looked at than read, such as a chart or dashboard, a table too wide for a Slack message, a comparison, a timeline, or a summary someone will want to share. Also use whenever the user asks for a page, a site, a mockup, a visualisation, a report, or something they can look at. Produces one HTML file deployed to a temporary Cloudflare Worker, so the user gets a live URL that stays up for 60 minutes.
---

# artifacts

Some answers do not belong in a Slack message. A ten-row table, a chart, a week
of deploy failures grouped by cause, a side-by-side of two proposals: Slack
flattens all of it. An artifact is the escape hatch. One HTML file, one link.

## When to build one, and when not to

Build one when the shape of the answer is the point: anything tabular past a few
rows, anything comparative, anything someone will want to send to a person who
is not in the channel.

Do not build one for an answer that is three sentences long. A link is friction,
and a link to a paragraph is worse than the paragraph. If the whole answer fits
comfortably in a Slack message, post the Slack message.

Never put a secret, a credential, an access token, or anything from a private
channel into an artifact. A temporary Worker URL is public to anyone holding it.

## How to build one

1. **Write one self-contained HTML file.** Inline the CSS and any JavaScript.
   No CDN links, no external fonts, no remote images: the page has to survive
   being opened on someone's phone on a train. If you have data, inline it as a
   literal rather than fetching it.
2. **Make it readable in both themes**, or commit to one and set the background
   explicitly. A page that inherits a dark background and paints dark text on it
   is unreadable, and you will not notice because you never open it.

## How to publish it

Deploy it as a temporary Cloudflare Worker that serves the file as a static asset:

```bash
mkdir -p /home/user/artifact/public && cd /home/user/artifact
# write your page to public/index.html
cat > wrangler.jsonc <<'JSON'
{
  "name": "archy-artifact",
  "compatibility_date": "2026-09-21",
  "assets": { "directory": "./public" }
}
JSON
wrangler deploy --temporary
```

`--temporary` needs no Cloudflare account and no token. It prints two URLs, a
live `*.workers.dev` one and a claim one. **Only the live URL goes to the
user.** Give them that link and nothing else.

**Say plainly that the link dies in 60 minutes.** Not "unless claimed": the
claim URL is not yours to hand out, since claiming binds the deployment to
whoever opens it. From the reader's side the link simply expires, so tell them
that. Someone who reads the message tomorrow and finds a dead link will assume
archy broke, not that they missed an expiry nobody mentioned.

If something is worth keeping, the answer is not a longer-lived link. Put the
substance in the Slack message, or in a Linear issue, and let the page be the
view of it.

To revise it, edit the file and run `wrangler deploy --temporary` again inside
the 60-minute window; it reuses the same temporary account and the same URL.

A fresh subdomain can take a minute to get its TLS certificate, so an
`ERR_SSL_VERSION_OR_CIPHER_MISMATCH` immediately after deploying is normal.
Wait and retry before reporting it as broken.
