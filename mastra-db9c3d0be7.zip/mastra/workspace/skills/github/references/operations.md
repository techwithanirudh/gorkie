# GitHub CLI Operations (read-only)

`GH_REPO` is `quiverai/quiverai-monorepo`, so every command below targets the monorepo without `-R`.

## Repository Context

```bash
gh repo view --json nameWithOwner,url,defaultBranchRef,isPrivate
gh api repos/quiverai/quiverai-monorepo --jq '{full_name, default_branch, pushed_at}'
```

## Search

```bash
gh search prs "query" --repo quiverai/quiverai-monorepo --limit 20 --json number,title,url,state,author
gh search prs --repo quiverai/quiverai-monorepo --author <login> --state open --json number,title,url
gh search code "symbol repo:quiverai/quiverai-monorepo" --limit 20
```

Prefer targeted searches. For code, `rg` in `~/quiverai-monorepo` is faster and sees the checkout you just fetched. `gh search code` sees only the default branch index.

## Pull Requests

```bash
gh pr list --state open --limit 50 --json number,title,url,reviewDecision,headRefName,isDraft
gh pr list --state merged --limit 20 --json number,title,mergedAt,author,url
gh pr list --author <login> --state open --json number,title,url
gh pr list --label <label> --json number,title,url
gh pr view 123 --comments --json title,body,state,url,files,reviewDecision,statusCheckRollup
gh pr diff 123
gh pr checks 123
```

`gh pr checkout` works for reading a branch locally, but a branch fetch (see the skill's History section) keeps `main` checked out.

## Workflow Runs

```bash
gh run list --limit 20 --json databaseId,name,status,conclusion,event,headBranch,url
gh run list --workflow ci.yml --branch main --limit 10 --json databaseId,conclusion,headSha,url
gh run view RUN_ID --json jobs,conclusion,url
gh run view RUN_ID --log-failed
gh run view RUN_ID --job JOB_ID --log
gh workflow list
```

For failing CI, inspect the failed logs first, then the files they name in the checkout.

## Output Discipline

- Use `--json`, `--jq`, and `--limit`.
- Save huge logs to files, summarize the relevant lines, then mention the file path.
- Never print tokens or authorization headers.
