# GitHub API Through `gh` (read-only)

Use `gh api` when the typed `gh` commands do not cover a read. Prefer compact `--jq` filters. Only `GET` requests and GraphQL queries work: never pass `-X POST`, `PATCH`, `PUT` or `DELETE`, and never run a GraphQL mutation.

## REST Reads

```bash
gh api repos/{owner}/{repo}/branches/main \
  --jq '{name, protected, commit: .commit.sha}'

gh api repos/{owner}/{repo}/compare/main...some-branch \
  --jq '{ahead_by, behind_by, files: [.files[].filename]}'

gh api repos/{owner}/{repo}/commits/SHA/pulls \
  --jq '.[] | {number, title, html_url}'

gh api repos/{owner}/{repo}/commits/SHA/status \
  --jq '{state, statuses: [.statuses[] | {context, state, target_url}]}'

gh api repos/{owner}/{repo}/pulls/123/comments \
  --jq '.[] | {path, line, user: .user.login, body}'
```

`{owner}` and `{repo}` are filled in from `GH_REPO`.

## GraphQL

Open review threads:

```bash
gh api graphql \
  -F number=123 \
  -f query='
query($number: Int!) {
  repository(owner: "quiverai", name: "quiverai-monorepo") {
    pullRequest(number: $number) {
      reviewThreads(first: 50) {
        nodes {
          isResolved
          path
          line
          comments(first: 10) {
            nodes { author { login } body url }
          }
        }
      }
    }
  }
}' \
  --jq '.data.repository.pullRequest.reviewThreads.nodes'
```

Blame without deepening the checkout:

```bash
gh api graphql \
  -f path="package.json" \
  -f query='
query($path: String!) {
  repository(owner: "quiverai", name: "quiverai-monorepo") {
    object(expression: "main") {
      ... on Commit {
        blame(path: $path) {
          ranges { startingLine endingLine commit { oid messageHeadline author { name } committedDate } }
        }
      }
    }
  }
}' \
  --jq '.data.repository.object.blame.ranges'
```

## Pagination

```bash
gh api repos/{owner}/{repo}/pulls --paginate \
  --jq '.[] | {number, title, head: .head.ref}'
```

Use pagination only when needed. Paginated output can become very large.

## Error Handling

- `401`: GitHub access is not available in this sandbox right now.
- `403` "Resource not accessible by integration": the App lacks that permission, or the request was a write.
- `403` with a rate-limit message: wait, or narrow the request.
- `404`: the path is wrong, or the resource is outside `quiverai/quiverai-monorepo`.
- `422`: invalid input.

```bash
gh api rate_limit --jq '.resources.core'
```
