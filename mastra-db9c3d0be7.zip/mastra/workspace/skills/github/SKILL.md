---
name: github
description: Read GitHub for quiverai/quiverai-monorepo through `gh` and `git` in the sandbox, read-only. Use when the user asks about pull requests (open PRs, a PR's diff, reviews, checks), CI runs and failure logs, which PRs belong to a Linear issue (ENG-1234), whether a PR for something already exists, or who changed what and when (`git log`, `git blame`).
---

# GitHub (read-only)

The sandbox template preinstalls `gh` and `git`, and the monorepo is checked out at `~/quiverai-monorepo`. Both are already authenticated to `quiverai/quiverai-monorepo` as the `archy-mastra[bot]` GitHub App, **read-only**, and to that one repository only. `GH_REPO` is set, so `gh` targets the monorepo without `-R`.

The credential is injected by the network on the way out. `GH_TOKEN` in the sandbox is a placeholder: never print it, pass it along, or add an `Authorization` header yourself. Never ask anyone to paste a token into Slack or a file.

## Workflow

1. For PRs, runs and checks, use `gh pr`, `gh run`, `gh search prs` or `gh api`, always with `--json` and `--jq` to keep output small, and `--limit`.
2. For history, use `git log` and `git blame` in `~/quiverai-monorepo`, after deepening the checkout: it is a `--depth=1` clone of `main`, and in a resumed sandbox it can be days old. See [History](#history).
3. Report PR and run URLs with what you found.

## Pull Requests

```bash
gh pr list --state open --limit 30 --json number,title,author,headRefName,isDraft,reviewDecision,updatedAt,url
gh pr view 123 --json title,body,state,author,headRefName,baseRefName,files,reviews,reviewDecision,statusCheckRollup,url
gh pr view 123 --comments
gh pr diff 123 --name-only
gh pr diff 123
gh pr checks 123
```

## Linear Issues To PRs

Branches are named after the Linear issue (`name/eng-1234-...`) and titles carry `(ENG-1234)`:

```bash
gh pr list --state all --search "ENG-1234 in:title" --json number,title,state,headRefName,url
gh pr list --state all --limit 100 --json number,title,state,headRefName,url \
  --jq '.[] | select(.headRefName | test("eng-1234-"; "i"))'
```

## Duplicate-PR Check

Before saying nothing exists yet, search open and recently closed PRs by keywords and issue key:

```bash
gh pr list --state open --search "<keywords> in:title,body" --json number,title,author,url
gh search prs "<keywords>" --repo quiverai/quiverai-monorepo --state open --limit 20 --json number,title,url
```

## CI Runs

```bash
gh run list --branch <branch> --limit 10 --json databaseId,name,status,conclusion,event,headSha,url
gh run list --status failure --limit 10 --json databaseId,name,headBranch,url
gh run view <run-id> --json jobs,conclusion,url --jq '.jobs[] | select(.conclusion == "failure") | {name, url}'
gh run view <run-id> --log-failed | tail -n 200
```

For a failing PR, read the failed log first, then the files it names in the checkout. Save long logs to a file and summarize the relevant lines.

## History

The checkout is shallow. Deepen it before `git log` or `git blame`, or blame stops at the shallow boundary (lines marked `^`):

```bash
cd ~/quiverai-monorepo
git fetch --deepen=200 origin main                # the last 200 more commits
git fetch --shallow-since="90 days ago" origin main
git fetch --unshallow origin                      # full history, about 15 s
git log --oneline -20 origin/main -- path/to/file
git blame -L 10,40 origin/main -- path/to/file
```

The clone tracks `main` only. To read another branch:

```bash
git fetch --depth=50 origin "+refs/heads/<branch>:refs/remotes/origin/<branch>"
git log --oneline -10 "origin/<branch>"
```

More commands, and `gh api` for what the typed commands miss: [Operations](references/operations.md), [API](references/api.md).

## Limits

- **Read-only.** Never attempt a write: no `git push`, `gh pr create`, `gh pr merge`, `gh pr comment` or `review`, `gh issue create` or `comment`, `gh run rerun`, `gh workflow run`, or `gh api -X POST/PATCH/PUT/DELETE`. They fail with 403, and the answer is to tell the person what to do, not to retry.
- **No user.** The token belongs to an App, not a person. `@me` silently matches nothing, `gh pr status` reports nothing to review, `gh api user` fails with 403, and `gh auth status` names the bot. Filter by a login instead (`--author <login>`).
- **403 "Resource not accessible by integration"** on a read means the App has not been granted that permission yet. Say which data was unavailable, not that GitHub is down.
- **One repository.** Other repositories return 404 or "Could not resolve to a Repository".
- If `gh` answers 401 or "Bad credentials", GitHub access is not available in this sandbox right now. Say so and do not retry.
