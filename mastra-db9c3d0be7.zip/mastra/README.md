# @quiverai/mastra

**archy** is QuiverAI's internal Slack operations agent, built on
[Mastra](https://mastra.ai). It answers questions in Slack by reading what is spread
across Linear, PostHog, Vercel, the `quiverai/quiverai-monorepo` repository, the web
and Slack itself, and links the sources it used. It answers mentions, DMs and threads
it follows, and, in channels that opt in, top-level messages nobody addressed to it.
It is tracked by [ENG-5412](https://linear.app/quiverai/issue/ENG-5412).

## How it works

### Request flow

1. Slack sends events and interactivity to one webhook,
   `/api/agents/orchestrator/channels/slack/webhook`. The Chat SDK Slack adapter
   ([`src/mastra/chat/client.ts`](src/mastra/chat/client.ts)) checks each request
   against `SLACK_SIGNING_SECRET`.
2. The handlers in [`src/mastra/chat/handlers.ts`](src/mastra/chat/handlers.ts) drop
   bot messages and route the rest:
   - `onMention`: a mention on a top-level message also makes archy follow that
     thread (`respondOnThreadMessages` in thread state).
   - `onSubscribedMessage`: a thread reply is answered if archy follows the thread or
     is mentioned. Replies that start with `##` are side comments and are skipped.
   - `onDirectMessage`: every DM is answered.
3. `!stop` ([`src/mastra/chat/commands/stop.ts`](src/mastra/chat/commands/stop.ts))
   is handled before any turn starts. It aborts the thread's running turn and cancels
   its background tasks.
4. `withHistory` prepends thread messages archy has not seen yet (below), and the
   turn goes to the `orchestrator` agent.
5. The orchestrator
   ([`src/mastra/agents/orchestrator.ts`](src/mastra/agents/orchestrator.ts)) builds
   its system prompt from [`src/mastra/prompts/`](src/mastra/prompts/), plus a
   `<directory>` block that joins the Slack and Linear rosters on email address
   ([`src/mastra/lib/directory/`](src/mastra/lib/directory/), refreshed every 6
   hours). With that block, "my issues" means the asker's issues and not the API key
   owner's. The orchestrator then calls tools and delegates to sub-agents.
6. The reply streams back to Slack. While it runs, the Slack status line names the
   current tool ([`src/mastra/chat/status/`](src/mastra/chat/status/)). The
   `turn-footer` processor ends a prompted reply with how long the turn took.

### Agents

| Agent                  | File                                                          | Role                                                                                                                                                                                                     |
| ---------------------- | ------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `orchestrator`         | [`agents/orchestrator.ts`](src/mastra/agents/orchestrator.ts) | Owns the Slack channel, memory, tools, connectors and sandbox. Delegates to the two sub-agents.                                                                                                          |
| `explore`              | [`agents/explore.ts`](src/mastra/agents/explore.ts)           | Sub-agent for the sandbox and repository: file tools, `grep`, `search_web`, `fetch_url`. Memory is in-process only.                                                                                      |
| `research`             | [`agents/research.ts`](src/mastra/agents/research.ts)         | Sub-agent for the web and Slack: `search_web`, `fetch_url`, `search_slack`, `read_conversation_history`, `get_user`, `get_channel_info`, `get_permalink`, `summarize_thread`. Memory is in-process only. |
| `summarizer`           | [`agents/summarizer.ts`](src/mastra/agents/summarizer.ts)     | Summarizes Slack transcripts for `summarize_thread`.                                                                                                                                                     |
| `relevance-classifier` | [`chat/relevance.ts`](src/mastra/chat/relevance.ts)           | Decides whether archy should answer a message nobody addressed to it.                                                                                                                                    |

Delegation passes a sub-agent only the latest user message.

### Models

Inference goes through Cloudflare Workers AI
([`src/mastra/providers.ts`](src/mastra/providers.ts)). Mastra's model router
resolves `cloudflare-workers-ai/@cf/...` ids from `CLOUDFLARE_API_KEY` and
`CLOUDFLARE_ACCOUNT_ID`. Each list is a fallback chain with 3 retries per model:

- Agents and observational memory: `@cf/deepseek-ai/deepseek-v4-flash-0731`, then
  `@cf/zai-org/glm-5.3-flash`. Thread titles use DeepSeek alone.
- Relevance classifier: `@cf/openai/gpt-oss-120b`, then
  `@cf/ibm-granite/granite-4.0-h-micro`.
- Embeddings: `@cf/baai/bge-m3`.

### Tools

The orchestrator's tools come from
[`src/mastra/tools/toolsets.ts`](src/mastra/tools/toolsets.ts):

- Slack: `search_slack`, `read_conversation_history`, `summarize_thread`,
  `get_user`, `get_permalink`, `get_slack_file`, `post_message`, `upload_file`,
  `react`, `join_thread` and `leave_thread`.
- The web: `search_web` and `fetch_url`, both backed by Exa.
- Turn control: `skip` ends the turn without replying. `wait` schedules the thread to
  resume later and also ends the turn.
- `view_image` loads an image from the sandbox into the model's context.
- `query_connectors`: code mode (below).
- The sandbox workspace tools (below).

The tools below are deferred and loaded through tool search (`ToolSearchProcessor`,
top 12, auto-load): the scheduled-task tools (`create_scheduled_task`,
`list_scheduled_tasks`, `pause_scheduled_task`, `resume_scheduled_task`,
`delete_scheduled_task`), `get_channel_info`,
`list_channels`, `list_threads`, and the canvas tools (`list_canvases`,
`read_canvas`, `create_canvas`, `edit_canvas`, `lookup_canvas_sections`).

### Sandbox and repository

Each Slack thread gets its own E2B sandbox
([`src/mastra/workspace/`](src/mastra/workspace/)). Its id is a hash of the thread
id, its working directory is `/home/user`, and it pauses when the turn ends. The
sandbox template ([`workspace/template.ts`](src/mastra/workspace/template.ts)) clones
`quiverai/quiverai-monorepo` using a contents-read token from the GitHub App. It
installs `git`, `gh`, `ripgrep`, `fd`, ImageMagick, ffmpeg, Python with pandas and
matplotlib, Node 24.15.0, `agent-browser` and `wrangler`. Git hooks are disabled
system-wide.

- The workspace tools are `read_file`, `write_file`, `edit_file`, `delete_file`,
  `list_files`, `file_stat`, `grep`, `execute_command`, `get_process_output` and
  `kill_process`. `grep` runs one native `rg --json` call in the sandbox
  ([`workspace/ripgrep.ts`](src/mastra/workspace/ripgrep.ts)). Without it, Mastra's
  grep reads one file at a time.
- The skills in [`workspace/skills/`](workspace/skills/) are `agent-browser`,
  `artifacts` (an HTML page on a temporary Cloudflare Worker, up for 60 minutes),
  `github` and `writing-guidelines`.
- `github` reads PRs, CI runs, checks and history through `gh` and `git`, read-only.

### Memory

There are three layers, and each covers something different:

- **`withHistory`** ([`src/mastra/chat/history.ts`](src/mastra/chat/history.ts))
  covers what was said in the Slack thread since archy last saw it. Before a turn, it
  reads up to 30 recent thread messages back to the `lastSeenMessage` in thread
  state. It prepends up to 10 of them to the message, excluding `##` comments, and
  notes how many comments it left out. DMs skip this step. Mastra's own channel
  thread context is off (`threadContext.maxMessages: 0`), so this is the only way
  unseen Slack messages reach the model.
- **Mastra message history** (`messageHistory.maxTokens: 200_000`) is archy's own
  conversation in the thread: past turns, tool calls and results, stored in libSQL.
- **Working and observational memory**
  ([`orchestrator.ts`](src/mastra/agents/orchestrator.ts)):
  - Working memory is scoped to the resource. It holds one profile per person
    ([`src/mastra/memory/profile.ts`](src/mastra/memory/profile.ts)): role, areas,
    timezone, stated preferences and writing style.
  - Observational memory is scoped to the thread. It compresses long threads into
    observations and reflections, and it manages the working-memory profile.
    `retrieval: { vector: true }` gives `recall` a semantic search across threads,
    using `bge-m3` and the libSQL vector store. Its `skillResultRedactor` hook strips
    skill results before observation. The observer and reflector prompts treat
    quoted, fetched and tool-produced content as untrusted.

### Unprompted answers (relevance engine)

[`src/mastra/chat/relevance.ts`](src/mastra/chat/relevance.ts) runs only when
`RELEVANCE_ENGINE_ENABLED=true`. It considers only top-level messages in the channel
ids listed in `RELEVANCE_ENGINE_CHANNELS` (comma-separated), and only when the message
is not from a bot and does not mention archy. The classifier sees the message and the
last 5 channel messages, each cut to 400 characters. It returns `trigger`,
`confidence` and an `intent`. archy answers when `trigger` is true and `confidence` is
at least 0.8, and a `bug_report` intent adds the bug-triage playbook. Unprompted turns
use a separate prompt set ([`prompts/unprompted.ts`](src/mastra/prompts/unprompted.ts))
and get no footer. They skip `runTurn`, so they get neither `withHistory` nor the
attachment handling.

## Connectors and access

| Source  | Reads                                                                                                                                                                                              | Writes                                           | How it is secured                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Linear  | Linear MCP (`mcp.linear.app`), with `LINEAR_API_KEY`                                                                                                                                               | Yes, after a person approves each write in Slack | `readsOnly` in [`mcp/tool-approval.ts`](src/mastra/mcp/tool-approval.ts) requires approval for every tool that does not declare `readOnlyHint` or that declares `destructiveHint`. An annotation can relax approval but never grant a write.                                                                                                                                                                                                                                                                                                 |
| PostHog | PostHog MCP (`mcp.posthog.com`): 17 allowlisted tools covering SQL, insights, dashboards, error tracking, logs, flags and experiments                                                              | No                                               | The server enforces read-only through `?readonly=true` and `x-posthog-read-only: true`, and the tool list is fixed in [`mcp/posthog.ts`](src/mastra/mcp/posthog.ts).                                                                                                                                                                                                                                                                                                                                                                         |
| Vercel  | Vercel MCP (`mcp.vercel.com`): `vercel_list_projects`, `vercel_list_deployments`, `vercel_get_deployment`, `vercel_list_deployment_events`, `vercel_get_runtime_logs`, `vercel_get_runtime_errors` | No                                               | Vercel tokens have no read-only mode. `admitVercel` in [`mcp/vercel.ts`](src/mastra/mcp/vercel.ts) admits these 6 tools by name and drops every other `vercel_*` tool, including `vercel_get_project_env`, which Vercel annotates as read-only. It removes the team argument and always passes `VERCEL_TEAM_ID`.                                                                                                                                                                                                                             |
| GitHub  | `gh` and `git` in the sandbox, for `quiverai/quiverai-monorepo` only                                                                                                                               | No                                               | The GitHub App mints a token scoped to that repository with read access to Contents, Pull requests, Actions, Checks, Commit statuses and Issues ([`lib/github.ts`](src/mastra/lib/github.ts)). The token goes into E2B egress rules ([`workspace/network.ts`](src/mastra/workspace/network.ts)), which set the `Authorization` header on requests to `api.github.com`, `github.com` and `uploads.github.com`. The sandbox's `GH_TOKEN`/`GITHUB_TOKEN` is a placeholder. The token is re-minted when less than 15 minutes of its hour remain. |
| Slack   | Channels, threads, users, files, canvases, and search (through `SLACK_USER_TOKEN`)                                                                                                                 | Messages, files, reactions, canvases             | Requests are checked against the signing secret. Scopes are listed in the manifests.                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Web     | Exa search and page extraction                                                                                                                                                                     | No                                               | Needs only `EXA_API_KEY`.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |

Every MCP server is a fixed entry in [`src/mastra/mcp/index.ts`](src/mastra/mcp/index.ts)
and pins `allowedHosts`, so a redirect cannot carry its bearer token to another host.

**Code mode.** Tools annotated `readOnlyHint` (after `admitVercel` sets it on the
Vercel reads) are not in the orchestrator's tool list. They are exposed only inside
`query_connectors` ([`tools/code-mode.ts`](src/mastra/tools/code-mode.ts)), which runs
a TypeScript program in QuickJS against `external_*` functions, with a 5-minute
timeout. Code mode calls `tool.execute()` directly and skips Mastra's approval check,
so any tool that does not declare itself read-only stays a direct tool
([`mcp/visibility.ts`](src/mastra/mcp/visibility.ts)). That way Linear writes still go
through the approval prompt.

## Local development

1. From the repo root, run `pnpm install`.
2. Create the dev Slack app at https://api.slack.com/apps from
   [`slack-manifest.dev.json`](slack-manifest.dev.json) (**archy (dev)**, bot
   `archy-dev`). Replace `<YOUR-TUNNEL-URL>` in its two request URLs, or set them in
   step 5. A scope or event change goes into both manifests.
3. Run `cp .env.example .env` and fill it in. [`.env.example`](.env.example)
   explains each value, and [`src/env.ts`](src/env.ts) validates them at startup.
   archy refuses to start if a required value is missing.
   - Required: `SLACK_BOT_TOKEN`, `SLACK_SIGNING_SECRET`, `SLACK_USER_TOKEN`,
     `LINEAR_API_KEY`, `POSTHOG_API_KEY` (a `phx_` personal key), `VERCEL_TOKEN`,
     `VERCEL_TEAM_ID`, `DATABASE_URL`, `E2B_API_KEY` (`e2b_` plus hex),
     `EXA_API_KEY`, `CLOUDFLARE_API_KEY` and `CLOUDFLARE_ACCOUNT_ID`.
   - Optional: `DATABASE_AUTH_TOKEN`, `MASTRA_API_TOKEN` (at least 32 characters),
     `LANGFUSE_BASE_URL`, `RELEVANCE_ENGINE_ENABLED` and
     `RELEVANCE_ENGINE_CHANNELS`.
   - `LANGFUSE_PUBLIC_KEY` and `LANGFUSE_SECRET_KEY` must be set together or not at
     all.
   - `GITHUB_APP_ID`, `GITHUB_APP_PRIVATE_KEY` (with newlines escaped) and
     `GITHUB_APP_INSTALLATION_ID` must be set together or not at all. Without them,
     the sandbox has no repository checkout and no GitHub access.
   - `DATABASE_URL="file:./archy.db"` is resolved relative to `packages/mastra`.
     libSQL creates its tables on first use, so no migration step is needed.
4. Start the agent and a public URL. Slack cannot deliver events to `localhost`.

   ```bash
   pnpm --filter @quiverai/mastra run dev:e2e    # mastra dev + untun tunnel, stopped together
   # or, in two terminals:
   pnpm --filter @quiverai/mastra run dev        # http://localhost:4111
   pnpm --filter @quiverai/mastra run dev:tunnel
   ```

   [`scripts/dev-e2e.sh`](scripts/dev-e2e.sh) waits for `/api` to answer before it
   opens the tunnel, then prints the webhook path. Set `MASTRA_PORT` to use a port
   other than 4111.

5. In the Slack app, set the Event Subscriptions and Interactivity request URLs to
   `<tunnel-url>/api/agents/orchestrator/channels/slack/webhook`. The agent id is
   `orchestrator`, from [`src/mastra/config.ts`](src/mastra/config.ts). A wrong path
   fails quietly: Slack accepts it, and archy only logs
   `Received a Slack webhook, but this agent doesn't have a Slack adapter`. A free
   tunnel's URL changes on every restart.
6. Set `MASTRA_API_TOKEN` whenever the tunnel is up. The tunnel exposes the whole API,
   not just the webhook, and setting the token turns auth on locally, Studio included.

**Traces.** Locally, traces, logs and metrics go to `observability.duckdb`, next to
the libSQL file. Everything else is stored in libSQL. To read traces, open Studio at
http://localhost:4111 or call the `/api/observability/*` routes (for example
`/api/observability/traces`) with `Authorization: Bearer $MASTRA_API_TOKEN` if auth is
on. If the Langfuse keys are set, traces go to Langfuse as well. The root agent
span carries the Slack channel, thread, message and user as metadata
([`observability/slack-identity.ts`](src/mastra/observability/slack-identity.ts)).

Other scripts: `build`, `start`, `typecheck`, `lint`, `fmt`, `test` and
`test:coverage`. The only file with a coverage floor is
`src/mastra/lib/directory/join.ts` ([`vitest.config.ts`](vitest.config.ts)).

## Deploying to Vercel

The Vercel project is `archy-mastra`, served at `https://archy-mastra.vercel.app`.
[`vercel.json`](vercel.json) sets:

- the install command: a filtered, frozen-lockfile install
- the build command: `pnpm run build`, which runs `mastra build`
- Fluid compute
- an `ignoreCommand` that skips a deploy unless something changed in this package,
  `tsconfig`, `patches/`, `pnpm-lock.yaml`, `pnpm-workspace.yaml` or the root
  `package.json`

When `VERCEL` is set, [`src/mastra/index.ts`](src/mastra/index.ts) builds with
`VercelDeployer`, using `maxDuration` 1800 and with Studio disabled. Without `VERCEL`, the same build produces `.mastra/output`
for `pnpm start`.

**Project settings**

- Root directory: `packages/mastra`, with "Include files outside the root directory"
  turned on.
- A Pro or Enterprise plan, with Fluid compute. `maxDuration` 1800 is Vercel's
  extended maximum, which is in beta; the generally available maximum is 800.
- Large functions turned on. The bundled function is well over the 250 MB standard
  limit.

**Production environment variables**

- Every required value from `.env.example`, using the production Slack app's
  credentials. Those credentials belong only in the Vercel project, never in a local
  `.env`.
- `MASTRA_API_TOKEN`, `LANGFUSE_PUBLIC_KEY` and `LANGFUSE_SECRET_KEY`, plus
  `LANGFUSE_BASE_URL` for any region but the EU cloud. The first three are required
  on Vercel, and `src/env.ts` rejects the boot without them.
- `DATABASE_URL` (the Turso `libsql://...turso.io` URL) and `DATABASE_AUTH_TOKEN`.
- The three `GITHUB_APP_*` values, if the sandbox should have the repository.
- `RELEVANCE_ENGINE_*`, if unprompted answers should be on.

**Production Slack app.** The production app, **archy**, is created from
[`slack-manifest.json`](slack-manifest.json). Its request URLs already point at
`https://archy-mastra.vercel.app`. After a manifest change, update the app's manifest
and reinstall it to the workspace so that new scopes and events take effect.

**What differs on Vercel**

- **Auth is always on.** `server.auth` is `SimpleAuth`, which accepts only
  `Authorization: Bearer $MASTRA_API_TOKEN`. Every `/api/*` route needs it. The Slack
  webhook is the only public route, and it checks Slack's signature instead.
- **The scheduler is off.** Mastra's scheduler needs a long-running process, so `wait`
  and scheduled tasks fire only under `pnpm dev` or `pnpm start`. On Vercel the model
  is not offered `wait` or the scheduled-task tools.
- **Traces go only to Langfuse.** DuckDB needs a disk that persists, so the
  `MastraStorageExporter` is not used, and the Langfuse exporter runs in realtime
  mode, exporting each span as it ends. Each turn flushes observability inside
  `waitUntil`.
- **The database is Turso.** libSQL holds memory, vectors and schedules.
- **Timed-out Slack retries are dropped.** A cold start takes longer than the 3
  seconds Slack waits for an acknowledgement, so Slack resends the event, and each
  resend lands on another cold instance. `SlackAgentAdapter.handleWebhook` in
  [`chat/adapter.ts`](src/mastra/chat/adapter.ts) answers a retry whose
  `X-Slack-Retry-Reason` is `http_timeout` with a 200 before verifying or reading it.
  Retries after any other failure go through, and the Redis dedupe below skips them if
  the first delivery was already handled.
- **Chat state lives in Redis.** [`chat/state.ts`](src/mastra/chat/state.ts)
  puts the Chat SDK's thread subscriptions, locks, dedupe keys and caches in Redis
  (`@chat-adapter/state-redis`, keys under `archy:chat:`). Slack sends a channel
  message that tags archy twice, as `app_mention` and as `message`, with the same
  timestamp; the Chat SDK claims `dedupe:slack:<ts>` with an atomic set-if-absent, so
  only the first copy runs a turn, whichever instance it lands on. `REDIS_URL` is
  required on Vercel, and `src/env.ts` rejects the boot without it.
  Locally, without it, the state stays in process, which is right for one server.

## The Mastra patch

[`patches/@mastra+core@1.69.0-alpha.1.patch`](../../patches/@mastra+core@1.69.0-alpha.1.patch)
patches both `dist/agent-*` bundles of `@mastra/core` and is registered under
`patchedDependencies` in `pnpm-workspace.yaml`. It fixes two things in the LLM
execution step:

- **In-stream model fallback.** Stock Mastra moves to the next model in the fallback
  list only when the model call throws. An error delivered as an in-band stream chunk
  returns normally, so the remaining models were never tried. The patch sets
  `advanceFallbackModel` in that case.
- **A fresh retry budget per model.** When the patch switches models, it resets
  `processorRetryCount` to 0, so the new model does not inherit the exhausted count of
  the model it replaces.

The upstream issue is mastra-ai/mastra#21280. PR #24475 covers the advance but not
the budget. The patch is why archy pins the 1.69 alphas: `@mastra/core`,
`@mastra/deployer` and `@mastra/server` at `1.69.0-alpha.1`, `@mastra/deployer-vercel`
at `1.2.28-alpha.1`, and the `mastra` CLI at `1.31.1-alpha.2`. Deployer 1.69
(mastra-ai/mastra#21716) carries workspace pnpm patches into the build output's
install, so the deployed function runs the patched core. Rollup content-hashes the
bundle file names, so a version bump makes the patch fail to apply
(`ERR_PNPM_PATCH_FAILED`) instead of silently dropping it.

## Known limits

The open work is in [`TODO.md`](TODO.md). It includes leaving the 1.69 alphas, the
first Vercel deploy, the scheduler on Vercel, the in-memory channel state and `!stop`
across instances, the silent-triage mode, the E2B to Vercel Sandbox move, evals, and
the `typescript: 6.0.3` pin.
