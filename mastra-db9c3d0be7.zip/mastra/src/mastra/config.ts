import { env } from "@/env";

export const sandbox = {
  codeModeTimeout: 5 * 60 * 1000,
  timeout: 16 * 60 * 1000,
  workdir: "/home/user",
};

export const upload = {
  maxBytes: 1_000_000_000,
};

export const file = {
  maxReadBytes: 10 * 1024 * 1024,
};

export const image = {
  maxViewBytes: 10 * 1024 * 1024,
  maxContextImages: 8,
  maxContextBytes: 60 * 1024 * 1024,
};

export const agent = {
  id: "orchestrator",
  maxSteps: 1000,
  maxTokens: { input: 1_000_000, output: 65_536 },
  modelTimeout: { firstChunkMs: 2 * 60 * 1000, stepMs: 5 * 60 * 1000 },
};

export const summarizer = {
  id: "summarizer",
  maxTokens: { output: 32_768 },
};

export const scheduledTasks = {
  minInterval: env.NODE_ENV === "production" ? 30 * 60 * 1000 : 60 * 1000,
};

export const relevance = {
  maxContextMessages: 5,
  maxContextChars: 400,
  minConfidence: 0.8,
};
