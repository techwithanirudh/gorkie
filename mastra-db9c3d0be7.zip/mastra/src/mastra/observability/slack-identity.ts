import type { AnySpan, SpanOutputProcessor } from "@mastra/core/observability";
import { SpanType } from "@mastra/core/observability";
import { z } from "zod";
import { channelSchema } from "../lib/context";

const channel = channelSchema.extend({ eventType: z.string().optional() });

export const slackIdentity: SpanOutputProcessor = {
  name: "slack-identity",
  process(span?: AnySpan): AnySpan | undefined {
    if (!span) {
      return span;
    }

    const parentSpanId = span.getParentSpanId();
    const parsed =
      span.type === SpanType.AGENT_RUN && (parentSpanId === undefined || parentSpanId === "")
        ? channel.safeParse(span.requestContext?.channel)
        : undefined;
    delete span.requestContext;
    if (parsed?.success !== true) {
      return span;
    }
    const slack = parsed.data;
    span.metadata = {
      ...span.metadata,
      channelId: slack.channelId,
      eventType: slack.eventType,
      isDM: slack.isDM,
      messageId: slack.messageId,
      sessionId: slack.threadId,
      userId: slack.userId,
      userName: slack.userName,
    };
    return span;
  },
  shutdown: () => Promise.resolve(),
};
