import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import type { ModelWithRetries } from "@mastra/core/agent";
import { env } from "@/env";

export const titleModel = "cloudflare-workers-ai/@cf/deepseek-ai/deepseek-v4-flash-0731";

export const models = (): ModelWithRetries[] => [
  { maxRetries: 3, model: titleModel },
  { maxRetries: 3, model: "cloudflare-workers-ai/@cf/zai-org/glm-5.3-flash" },
];

export const classifier: ModelWithRetries[] = [
  { maxRetries: 3, model: "cloudflare-workers-ai/@cf/openai/gpt-oss-120b" },
  { maxRetries: 3, model: "cloudflare-workers-ai/@cf/ibm-granite/granite-4.0-h-micro" },
];

const cloudflare = createOpenAICompatible({
  apiKey: env.CLOUDFLARE_API_KEY,
  baseURL: `https://api.cloudflare.com/client/v4/accounts/${env.CLOUDFLARE_ACCOUNT_ID}/ai/v1`,
  name: "cloudflare-workers-ai",
});

export const embedder = cloudflare.embeddingModel("@cf/baai/bge-m3");
