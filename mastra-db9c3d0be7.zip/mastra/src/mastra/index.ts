import path from "node:path";
import { Mastra } from "@mastra/core/mastra";
import { VercelDeployer } from "@mastra/deployer-vercel";
import { MastraCompositeStore } from "@mastra/core/storage";
import type { ObservabilityStorage } from "@mastra/core/storage";
import { SpanType } from "@mastra/core/observability";
import { SimpleAuth } from "@mastra/core/server";
import { LangfuseExporter } from "@mastra/langfuse";
import { MastraStorageExporter, Observability } from "@mastra/observability";
import { env } from "@/env";
import { resolveFromPackageRoot } from "@/package-root";
import { exploreAgent as explore } from "./agents/explore";
import orchestrator from "./agents/orchestrator";
import { researchAgent as research } from "./agents/research";
import { summarizer } from "./agents/summarizer";
import { setChat } from "./chat/instance";
import { setMastra } from "./chat/mastra-instance";
import { pubsub } from "./chat/pubsub";
import { registerRelevanceEngine, relevanceClassifier } from "./chat/relevance";
import { libsqlStore } from "./db/client";
import { logger } from "./lib/logger";
import { slackIdentity } from "./observability/slack-identity";
import { isWaitSchedule } from "./tools/scheduled-tasks";

process.on("unhandledRejection", (err) => {
  logger.error("[process] unhandled rejection", { err });
});
process.on("uncaughtException", (err: Error) => {
  logger.error("[process] uncaught exception", { err });
});

const onDisk = env.VERCEL === undefined;
const DAY_MS = 24 * 60 * 60 * 1000;
const traceRetention = {
  logs: { maxAge: "7d" },
  metrics: { maxAge: "7d" },
  scores: { maxAge: "7d" },
  spans: { maxAge: "7d" },
} as const;

const localObservabilityStore = async (): Promise<ObservabilityStorage | null> => {
  const { DuckDBStore } = await import("@mastra/duckdb");
  const url = env.DATABASE_URL;
  const observabilityPath = url.startsWith("file:")
    ? path.join(
        path.dirname(resolveFromPackageRoot(url.slice("file:".length))),
        "observability.duckdb",
      )
    : resolveFromPackageRoot("observability.duckdb");
  const store = await new DuckDBStore({
    memoryLimit: "4GB",
    path: observabilityPath,
    threads: 2,
  }).getStore("observability");
  if (store === undefined) {
    return null;
  }
  try {
    await store.init();
  } catch (error) {
    logger.error("[observability] local trace store failed to open; running without it", {
      error,
    });
    return null;
  }
  const prune = async (): Promise<void> => {
    try {
      await store.prune(traceRetention);
    } catch (error) {
      logger.warn("[observability] pruning old traces failed", { error });
    }
  };
  void prune();
  setInterval(() => void prune(), DAY_MS).unref();
  return store;
};

const langfuse =
  env.LANGFUSE === null ? undefined : new LangfuseExporter({ ...env.LANGFUSE, realtime: !onDisk });

const observabilityStore = onDisk ? await localObservabilityStore() : null;

const exporters = [
  ...(observabilityStore ? [new MastraStorageExporter()] : []),
  ...(langfuse ? [langfuse] : []),
];

const auth =
  env.MASTRA_API_TOKEN === undefined
    ? undefined
    : new SimpleAuth({
        tokens: { [env.MASTRA_API_TOKEN]: { id: "archy-operator", name: "archy operator" } },
      });

export const mastra = new Mastra({
  agents: {
    explore,
    orchestrator,
    "relevance-classifier": relevanceClassifier,
    research,
    summarizer,
  },
  logger,
  pubsub,
  observability: new Observability({
    configs: {
      default: {
        excludeSpanTypes: [
          SpanType.MAPPING,
          SpanType.MEMORY_OPERATION,
          SpanType.MODEL_STEP,
          SpanType.PROCESSOR_RUN,
          SpanType.SKILL_ACTION,
          SpanType.WORKSPACE_ACTION,
        ],
        serviceName: "orchestrator",
        exporters,
        spanOutputProcessors: [slackIdentity],
      },
    },
  }),
  deployer:
    process.env.VERCEL === undefined
      ? undefined
      : new VercelDeployer({
          // Vercel's extended maximum on Pro and Enterprise (beta, Fluid compute only).
          maxDuration: 1800,
          studio: false,
        }),
  schedules: {
    prepare: async ({ mastra: runtime, schedule }) => {
      const current = await runtime.schedules.get(schedule.id);
      if (current && isWaitSchedule(current)) {
        await runtime.schedules.delete(schedule.id);
      }
    },
  },
  scheduler: onDisk ? undefined : { enabled: false },
  server: { auth },
  storage: new MastraCompositeStore({
    id: "composite-storage",
    default: libsqlStore,
    domains: observabilityStore ? { observability: observabilityStore } : {},
  }),
});

await mastra.startWorkers();
setMastra(mastra);

const connectChannels = async (): Promise<void> => {
  try {
    await orchestrator.getChannels()?.initialize(mastra);
    const sdk = orchestrator.getChannels()?.sdk;
    if (!sdk) {
      return;
    }
    setChat(sdk);
    registerRelevanceEngine(sdk);
    logger.info("[agent] online");
  } catch (error) {
    logger.error("[agent] initialization failed", { error });
  }
};

void connectChannels();
