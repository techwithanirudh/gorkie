import { LibSQLStore, LibSQLVector } from "@mastra/libsql";
import { env } from "@/env";

export const libsqlStore = new LibSQLStore({
  authToken: env.DATABASE_AUTH_TOKEN,
  id: "main-storage",
  url: env.DATABASE_URL,
});

export const libsqlVector = new LibSQLVector({
  authToken: env.DATABASE_AUTH_TOKEN,
  url: env.DATABASE_URL,
  id: "main-vector",
});
