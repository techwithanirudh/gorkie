import { detectMediaType } from "@ai-sdk/provider-utils";
import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { image } from "../config";
import { input, output } from "../types/tools/index";
import { requireSandbox } from "../workspace";

export const viewImageTool = createTool({
  id: "view_image",
  description:
    "Look at an image in the sandbox (png, jpeg, gif, webp) so you can actually see it. Pass just the path. This is how you view an image: read_file with an encoding returns text or base64, which you cannot see.",
  inputSchema: input({
    path: z.string().min(1).describe("Sandbox path to the image file."),
  }),
  outputSchema: output({
    data: z.string(),
    mediaType: z.string(),
    path: z.string(),
  }),
  toModelOutput: (out) => ({
    type: "content",
    value: [
      { text: `${out.path} (${out.mediaType})`, type: "text" },
      { data: out.data, mediaType: out.mediaType, type: "media" },
    ],
  }),
  execute: async ({ path }, context) => {
    if (context?.requestContext === undefined) {
      throw new Error("No workspace context.");
    }
    const sandbox = await requireSandbox(context.requestContext);
    const stat = await sandbox.retryOnDead(() => sandbox.e2b.files.getInfo(path));
    if (stat.size > image.maxViewBytes) {
      throw new Error(
        `${path} is ${Math.round(stat.size / 1_000_000)}MB, too large to view inline.`,
      );
    }
    const bytes = Buffer.from(
      await sandbox.retryOnDead(() => sandbox.e2b.files.read(path, { format: "bytes" })),
    );
    const mediaType = detectMediaType({ data: bytes, topLevelType: "image" });
    if (
      mediaType === undefined ||
      !["image/gif", "image/jpeg", "image/png", "image/webp"].includes(mediaType)
    ) {
      throw new Error(
        `${path} is not a viewable image (png, jpeg, gif, webp). Use read_file for other files.`,
      );
    }
    return {
      data: bytes.toString("base64"),
      mediaType,
      path,
    };
  },
});
