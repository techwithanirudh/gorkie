import { createTool } from "@mastra/core/tools";
import type { CanvasesSectionsLookupArguments } from "@slack/web-api";
import { z } from "zod";
import { slack } from "../../chat/client";
import { input, output } from "../../types/tools/index";
import { canvasIdSchema } from "./canvas-id";

export const lookupCanvasSectionsTool = createTool({
  id: "lookup_canvas_sections",
  description:
    "Find section ids in one Slack canvas by header type, contained text, or both. Use this before edit_canvas when changing a specific section rather than replacing the whole canvas.",
  inputSchema: input({
    canvasId: canvasIdSchema,
    sectionTypes: z
      .array(z.enum(["any_header", "h1", "h2", "h3"]))
      .min(1)
      .optional(),
    containsText: z.string().min(1).optional(),
  }).refine(({ sectionTypes, containsText }) => sectionTypes ?? containsText, {
    message: "Provide sectionTypes, containsText, or both.",
  }),
  outputSchema: output({
    canvasId: z.string(),
    sections: z.array(z.unknown()),
  }),
  execute: async ({ canvasId, sectionTypes, containsText }) => {
    const [firstSectionType, ...restSectionTypes] = sectionTypes ?? [];
    let criteria: CanvasesSectionsLookupArguments["criteria"];
    if (firstSectionType) {
      criteria = { section_types: [firstSectionType, ...restSectionTypes] };
      if (containsText !== undefined) {
        criteria.contains_text = containsText;
      }
    } else if (containsText === undefined) {
      throw new Error("Provide sectionTypes, containsText, or both.");
    } else {
      criteria = { contains_text: containsText };
    }
    const response = await slack.webClient.canvases.sections.lookup({
      canvas_id: canvasId,
      criteria,
    });
    return {
      canvasId,
      sections: response.sections ?? [],
    };
  },
});
