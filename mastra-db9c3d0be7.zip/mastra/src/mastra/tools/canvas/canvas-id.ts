import { z } from "zod";

export const canvasIdSchema = z
  .string()
  .regex(/^F[A-Z0-9]+$/u, "Must be a bare Slack file id (e.g. F0123ABCD), not a URL or permalink.")
  .describe("Slack canvas id, e.g. F0123ABCD.");
