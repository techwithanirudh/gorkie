import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { slack } from "../../chat/client";
import { channelContext } from "../../lib/context";
import { rawId } from "../../lib/ids";
import { input, output } from "../../types/tools/index";

const canvasFile = z
  .looseObject({
    created: z.number().optional(),
    id: z.string(),
    name: z.string().optional(),
    permalink: z.string().optional(),
    title: z.string().optional(),
    updated: z.number().optional(),
  })
  .transform((f) => ({
    canvasId: f.id,
    created: f.created,
    permalink: f.permalink,
    title: f.title === undefined || f.title === "" ? f.name : f.title,
    updated: f.updated,
  }));

const nextPageAfter = (
  paging: { page?: number; pages?: number } | undefined,
): number | undefined => {
  const { page } = paging ?? {};
  if (page === undefined || page === 0) {
    return undefined;
  }
  const { pages } = paging ?? {};
  if (pages === undefined || pages === 0) {
    return undefined;
  }
  return page < pages ? page + 1 : undefined;
};

export const listCanvasesTool = createTool({
  id: "list_canvases",
  description:
    "List one page of Slack canvases visible to the bot, optionally filtered by title. Channel scope defaults to the current channel. Workspace scope includes standalone canvases and canvases from other accessible channels. Pass the returned nextPage back as page to fetch more.",
  inputSchema: input({
    query: z.string().min(1).optional().describe("Case-insensitive title filter."),
    scope: z
      .enum(["channel", "workspace"])
      .default("channel")
      .describe(
        "Use channel for the current or specified channel, or workspace for all accessible canvases.",
      ),
    channelId: z
      .string()
      .optional()
      .describe(
        "Channel id (slack:C...) to use instead of the current channel. Only valid with channel scope.",
      ),
    limit: z.coerce.number().int().min(1).max(100).default(20),
    page: z.coerce.number().int().min(1).default(1),
  }).refine(
    ({ scope, channelId }) =>
      !(scope === "workspace" && channelId !== undefined && channelId !== ""),
    {
      message: "channelId cannot be used with workspace scope.",
      path: ["channelId"],
    },
  ),
  outputSchema: output({
    scope: z.enum(["channel", "workspace"]),
    channelId: z.string().optional(),
    canvases: z.array(
      z.strictObject({
        canvasId: z.string(),
        title: z.string().optional(),
        created: z.number().optional(),
        updated: z.number().optional(),
        permalink: z.string().optional(),
      }),
    ),
    nextPage: z.number().optional(),
  }),
  execute: async ({ query, scope, channelId, limit, page }, context) => {
    const id =
      scope === "workspace"
        ? undefined
        : (channelId ?? channelContext(context?.requestContext).channelId);
    const hasId = id !== undefined && id !== "";
    if (scope === "channel" && !hasId) {
      throw new Error("No channel to list canvases from.");
    }

    const listArgs: Parameters<typeof slack.webClient.files.list>[0] = {
      types: "canvas",
      count: limit,
      page,
    };
    if (hasId) {
      listArgs.channel = rawId(id);
    }
    const response = await slack.webClient.files.list(listArgs);
    const normalizedQuery = query !== undefined && query !== "" ? query.toLowerCase() : undefined;
    const canvases = (response.files ?? [])
      .map((f) => canvasFile.parse(f))
      .filter(
        (canvas) =>
          normalizedQuery === undefined ||
          (canvas.title !== undefined && canvas.title.toLowerCase().includes(normalizedQuery)),
      );
    const nextPage = nextPageAfter(response.paging);

    return {
      scope,
      channelId: id,
      canvases,
      nextPage,
    };
  },
});
