import { createCanvasTool } from "./create";
import { editCanvasTool } from "./edit";
import { listCanvasesTool } from "./list";
import { readCanvasTool } from "./read";
import { lookupCanvasSectionsTool } from "./sections";

export const canvasTools = {
  create_canvas: createCanvasTool,
  edit_canvas: editCanvasTool,
  list_canvases: listCanvasesTool,
  lookup_canvas_sections: lookupCanvasSectionsTool,
  read_canvas: readCanvasTool,
};
