import type { ToolsInput } from "@mastra/core/agent";
import { env } from "@/env";
import { mcpTools } from "../mcp";
import { visibility } from "../mcp/visibility";
import { canvasTools } from "./canvas";
import { fetchUrlTool } from "./fetch-url";
import { scheduledTaskTools } from "./scheduled-tasks";
import { searchWebTool } from "./search-web";
import { slackTools } from "./slack";
import { skipTool } from "./skip";
import { viewImageTool } from "./view-image";
import { waitTool } from "./wait";

const onVercel = env.VERCEL !== undefined;
const waitTools: ToolsInput = onVercel ? {} : { wait: waitTool };
const schedulingTools: ToolsInput = onVercel ? {} : scheduledTaskTools;

export const orchestratorTools = async () => ({
  ...Object.fromEntries(
    Object.entries(await mcpTools()).filter(([, tool]) => visibility(tool) === "direct"),
  ),
  fetch_url: fetchUrlTool,
  get_permalink: slackTools.get_permalink,
  get_slack_file: slackTools.get_slack_file,
  get_user: slackTools.get_user,
  join_thread: slackTools.join_thread,
  leave_thread: slackTools.leave_thread,
  post_message: slackTools.post_message,
  react: slackTools.react,
  read_conversation_history: slackTools.read_conversation_history,
  search_slack: slackTools.search_slack,
  search_web: searchWebTool,
  skip: skipTool,
  summarize_thread: slackTools.summarize_thread,
  upload_file: slackTools.upload_file,
  view_image: viewImageTool,
  ...waitTools,
});

export const deferredTools = () => ({
  ...schedulingTools,
  get_channel_info: slackTools.get_channel_info,
  list_channels: slackTools.list_channels,
  list_threads: slackTools.list_threads,
  ...canvasTools,
});
