import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { chat } from "../../chat/instance";
import { channelContext } from "../../lib/context";
import { input, output } from "../../types/tools/index";
import { setThreadState } from "../../chat/state";

export const joinThreadTool = createTool({
  id: "join_thread",
  description:
    "Rejoin the current thread: start auto-responding to its messages again after leaving it. Use this when someone asks you to come back, follow along, or start listening again. Without it a thread you left still responds to a direct @mention anywhere in it, but standing auto-response only re-arms when the mention lands on the thread's very first message.",
  inputSchema: input({}),
  outputSchema: output({ threadId: z.string() }),
  execute: async (_input, context) => {
    const { threadId } = channelContext(context?.requestContext);
    if (threadId === undefined || threadId === "") {
      throw new Error("No current thread.");
    }
    const thread = chat().thread(threadId);
    await thread.subscribe();
    await setThreadState(thread, { respondOnThreadMessages: true });
    return { threadId };
  },
});
