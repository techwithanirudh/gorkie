import { fetchSlackFile } from "@chat-adapter/slack/api";
import { createTool } from "@mastra/core/tools";
import type { E2BSandbox } from "@mastra/e2b";
import type { EntryInfo } from "e2b";
import { z } from "zod";
import { env } from "@/env";
import { slack } from "../../chat/client";
import { logger } from "../../lib/logger";
import { input, output } from "../../types/tools/index";
import { sandboxPath as p, requireSandbox } from "../../workspace";

const sh = (value: string): string => `'${value.replaceAll("'", "'\\''")}'`;

const formatBytes = (value: number): string => {
  if (value < 1024 * 1024) {
    return `${Math.ceil(value / 1024)} KB`;
  }
  return `${Math.ceil(value / 1024 / 1024)} MB`;
};

const throwIfAborted = (signal?: AbortSignal): void => {
  if (signal?.aborted === true) {
    throw new Error("File download aborted.");
  }
};

const removeQuietly = async (sandbox: E2BSandbox, targetPath: string): Promise<void> => {
  try {
    await sandbox.e2b.files.remove(targetPath);
  } catch (error) {
    logger.debug("[slack] could not remove temporary download", { error, targetPath });
  }
};

const getInfoQuietly = async (
  sandbox: E2BSandbox,
  targetPath: string,
): Promise<EntryInfo | undefined> => {
  try {
    return await sandbox.retryOnDead(() => sandbox.e2b.files.getInfo(targetPath));
  } catch {
    return undefined;
  }
};

const probeContentLength = async (
  url: string,
  signal: AbortSignal | undefined,
): Promise<number | undefined> => {
  try {
    const response = await fetch(url, {
      headers: { authorization: `Bearer ${env.SLACK_BOT_TOKEN}` },
      method: "HEAD",
      signal,
    });
    const size = Number(response.headers.get("content-length"));
    return Number.isFinite(size) && size >= 0 ? size : undefined;
  } catch {
    return undefined;
  }
};

interface DownloadPaths {
  path: string;
  partPath: string;
  nextPath: string;
  mergePath: string;
}

const commitDownload = async (sandbox: E2BSandbox, paths: DownloadPaths): Promise<void> => {
  await sandbox.retryOnDead(async () => {
    await removeQuietly(sandbox, paths.path);
    await sandbox.e2b.files.rename(paths.partPath, paths.path);
    await removeQuietly(sandbox, paths.nextPath);
    await removeQuietly(sandbox, paths.mergePath);
  });
};

const mergeDownload = async (sandbox: E2BSandbox, paths: DownloadPaths): Promise<void> => {
  const result = await sandbox.retryOnDead(() =>
    sandbox.e2b.commands.run(
      `cat ${sh(paths.partPath)} ${sh(paths.nextPath)} > ${sh(paths.mergePath)} && mv ${sh(paths.mergePath)} ${sh(paths.partPath)} && rm -f ${sh(paths.nextPath)}`,
    ),
  );
  if (result.exitCode !== 0) {
    throw new Error(`Failed to merge resumed download: ${result.stderr}`);
  }
};

const fetchResponse = (url: string, signal: AbortSignal | undefined, resumeOffset?: number) =>
  fetchSlackFile({
    fetch: (fetchInput: Parameters<typeof fetch>[0], init?: RequestInit) => {
      const requestHeaders = new Headers(init?.headers);
      if (resumeOffset !== undefined) {
        requestHeaders.set("range", `bytes=${resumeOffset}-`);
      }
      return fetch(fetchInput, {
        ...init,
        headers: requestHeaders,
        signal,
      });
    },
    token: env.SLACK_BOT_TOKEN,
    url,
  });

const writeResponseBody = async (
  sandbox: E2BSandbox,
  body: ReadableStream<Uint8Array>,
  targetPath: string,
  signal: AbortSignal | undefined,
): Promise<number> => {
  let downloaded = 0;
  // Not wrapped in retryOnDead: a ReadableStream is single-use, so a retry
  // would re-pipe an already-locked stream (and double-count `downloaded`).
  await sandbox.e2b.files.write(
    targetPath,
    body.pipeThrough(
      new TransformStream<Uint8Array, Uint8Array>({
        transform(chunk, controller) {
          throwIfAborted(signal);
          downloaded += chunk.byteLength;
          controller.enqueue(chunk);
        },
      }),
    ),
    { signal, useOctetStream: true },
  );
  throwIfAborted(signal);
  return downloaded;
};

const downloadToSandbox = async ({
  sandbox,
  url,
  paths,
  expectedSize,
  signal,
}: {
  sandbox: E2BSandbox;
  url: string;
  paths: DownloadPaths;
  expectedSize: number | undefined;
  signal: AbortSignal | undefined;
}): Promise<number> => {
  const existingPart = await getInfoQuietly(sandbox, paths.partPath);
  const resumeAt = existingPart?.size ?? 0;
  if (expectedSize !== undefined && resumeAt === expectedSize) {
    await commitDownload(sandbox, paths);
    return expectedSize;
  }

  if (expectedSize !== undefined && resumeAt > expectedSize) {
    await removeQuietly(sandbox, paths.partPath);
  }
  await removeQuietly(sandbox, paths.nextPath);
  await removeQuietly(sandbox, paths.mergePath);

  const resumeOffset = expectedSize !== undefined && resumeAt < expectedSize ? resumeAt : 0;
  const response = await fetchResponse(url, signal, resumeOffset > 0 ? resumeOffset : undefined);
  if (!(response.ok && (resumeOffset === 0 || response.status === 206))) {
    throw new Error(`Failed to download Slack file: ${response.status}`);
  }
  if (!response.body) {
    throw new Error("Slack file response did not include a body.");
  }

  const downloadedSize = await writeResponseBody(
    sandbox,
    response.body,
    resumeOffset > 0 ? paths.nextPath : paths.partPath,
    signal,
  );

  if (resumeOffset > 0) {
    await mergeDownload(sandbox, paths);
  }

  const finalPart = await sandbox.retryOnDead(() => sandbox.e2b.files.getInfo(paths.partPath));
  if (expectedSize !== undefined && finalPart.size !== expectedSize) {
    throw new Error(
      `Downloaded ${formatBytes(finalPart.size)} but expected ${formatBytes(expectedSize)}.`,
    );
  }
  await commitDownload(sandbox, paths);

  return expectedSize ?? downloadedSize;
};

const resolveDownloadTarget = async (file: string, filename: string | undefined) => {
  const fileId = /(?<fileId>F[A-Z0-9]{6,})/u.exec(file)?.[1];
  if (fileId === undefined || fileId === "") {
    throw new Error(
      `Not a Slack file id: "${file}". Pass a Slack file id like F0123ABCD (or a Slack file permalink that contains one). get_slack_file only downloads Slack files; use fetch_url for arbitrary web URLs.`,
    );
  }

  const { file: fileInfo } = await slack.webClient.files.info({ file: fileId });
  const url = fileInfo?.url_private_download ?? fileInfo?.url_private;
  if (url === undefined || url === "") {
    throw new Error(
      `Could not resolve a download URL for Slack file ${fileId}. It may have been deleted, or the bot may not have access to it.`,
    );
  }
  const defaultName = fileInfo?.name ?? fileId;
  const sanitized = (filename ?? defaultName).replaceAll(/[^\w.-]+/gu, "_");
  const name =
    sanitized === "" || sanitized === "." || sanitized === ".." ? "slack-file" : sanitized;
  const path = p("downloads", name);
  const paths: DownloadPaths = {
    path,
    partPath: `${path}.part`,
    nextPath: `${path}.next`,
    mergePath: `${path}.merge`,
  };
  return { fileInfo, url, name, paths };
};

export const getSlackFileTool = createTool({
  id: "get_slack_file",
  description:
    "Download one Slack upload, snippet, or image into the thread sandbox for reading or processing. Pass a Slack file id such as F0123ABCD, or a Slack file permalink containing one. Use fetch_url for web URLs and read_canvas for canvases. Preserve a useful image extension so read_file can infer its MIME type.",
  inputSchema: input({
    file: z
      .string()
      .min(1)
      .describe(
        "A Slack file id (e.g. F0123ABCD). A Slack file permalink containing the id also works; the id is extracted from it.",
      ),
    filename: z.string().optional().describe("Optional name to save it as."),
  }),
  outputSchema: output({
    path: z.string(),
    filename: z.string(),
    mimeType: z.string().optional(),
    size: z.number(),
  }),
  execute: async ({ file, filename }, context) => {
    if (context?.requestContext === undefined) {
      throw new Error("No workspace context.");
    }
    const sandbox = await requireSandbox(context.requestContext);
    const { fileInfo, url, name, paths } = await resolveDownloadTarget(file, filename);
    const { path } = paths;
    await sandbox.retryOnDead(() => sandbox.e2b.files.makeDir(p("downloads")));
    const formatResult = (size: number) => ({
      path,
      filename: name,
      mimeType: fileInfo?.mimetype,
      size,
    });

    const expectedSize = fileInfo?.size ?? (await probeContentLength(url, context.abortSignal));

    const existingFinal = await getInfoQuietly(sandbox, path);
    if (expectedSize !== undefined && existingFinal?.size === expectedSize) {
      return formatResult(expectedSize);
    }

    if (expectedSize === 0) {
      await sandbox.retryOnDead(() =>
        sandbox.e2b.commands.run(`rm -f ${sh(path)} && : > ${sh(path)}`),
      );
      return formatResult(expectedSize);
    }

    const finalSize = await downloadToSandbox({
      sandbox,
      url,
      paths,
      expectedSize,
      signal: context.abortSignal,
    });

    return formatResult(finalSize);
  },
});
