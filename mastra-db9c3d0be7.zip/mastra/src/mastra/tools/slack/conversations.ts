import type { Message } from "chat";
import { z } from "zod";
import { slack } from "../../chat/client";
import { parseSlackId, rawId, threadIdOf } from "../../lib/ids";
import { logger } from "../../lib/logger";
import { ALREADY_IN_CHANNEL } from "../../lib/logger/slack";

const joinedChannels = new Set<string>();
export const slackErrorSchema = z.looseObject({
  data: z.looseObject({ error: z.string().optional() }).optional(),
});

export const joinChannel = async (channelId: string): Promise<void> => {
  const id = rawId(channelId);
  if (joinedChannels.has(id)) {
    return;
  }
  try {
    await slack.webClient.conversations.join({ channel: id });
    joinedChannels.add(id);
  } catch (error) {
    // Other failures may be transient, so they are not cached.
    if (slackErrorSchema.safeParse(error).data?.data?.error === ALREADY_IN_CHANNEL) {
      joinedChannels.add(id);
      return;
    }
    logger.debug("[slack] could not join the channel", { channelId, error });
  }
};

export const slackThreadId = ({
  channelId,
  threadId,
}: {
  channelId?: string;
  threadId: string;
}): string => threadIdOf(parseSlackId(threadId, { channel: channelId })) ?? threadId;

export const formatMessage = (message: Message) => ({
  attachments: message.attachments.map((a) => ({
    type: a.type,
    name: a.name,
    mimeType: a.mimeType,
    url: a.url,
  })),
  author: {
    fullName: message.author.fullName,
    isBot: message.author.isBot,
    isMe: message.author.isMe,
    userId: message.author.userId,
    userName: message.author.userName,
  },
  dateSent: message.metadata.dateSent.toISOString(),
  edited: message.metadata.edited,
  id: message.id,
  isMention: message.isMention,
  text: message.text,
  threadId: message.threadId,
});
