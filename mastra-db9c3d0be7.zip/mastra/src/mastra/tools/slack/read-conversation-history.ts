import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { slack } from "../../chat/client";
import { isComment } from "../../chat/message";
import { channelContext } from "../../lib/context";
import { chatChannelId } from "../../lib/ids";
import { input, output, slackMessageSchema } from "../../types/tools/index";
import { formatMessage, joinChannel, slackThreadId } from "./conversations";

export const readConversationHistoryTool = createTool({
  id: "read_conversation_history",
  description:
    "Read one chronological page of raw messages from a Slack channel or thread when exact wording matters. This does not search or filter message text; use search_slack for a keyword query and summarize_thread when a long thread only needs a summary. Pass the returned cursor back to page through more history. The current conversation is always readable; other channels must be public or a private channel the bot has already been invited to — public channels are joined automatically.",
  inputSchema: input({
    channelId: z
      .string()
      .optional()
      .describe(
        "Conversation id (slack:C..., slack:D..., or slack:G...) to read conversation-level history. Omit for the current conversation. Never derive this from a user id.",
      ),
    threadId: z
      .string()
      .optional()
      .describe(
        "Thread id (slack:<conversation-id>:ts), Slack message permalink, or message timestamp paired with channelId. Omit for the current conversation.",
      ),
    limit: z.coerce.number().int().min(1).max(200).default(40),
    cursor: z.string().optional().describe("Slack pagination cursor from a previous response."),
    includeComments: z
      .boolean()
      .default(false)
      .describe(
        "Include messages whose first line starts with ##. People use those for side remarks they are not asking you to act on, so they are left out unless you ask for them. The result says so when any were dropped.",
      ),
  }),
  outputSchema: output({
    channelId: z.string(),
    messages: z.array(slackMessageSchema),
    nextCursor: z.string().optional(),
    note: z.string().optional(),
  }),
  execute: async ({ channelId, threadId, limit, cursor, includeComments }, context) => {
    const ctx = channelContext(context?.requestContext);
    const suppliedThreadId =
      threadId ?? (channelId !== undefined && channelId !== "" ? undefined : ctx.threadId);
    const tid =
      suppliedThreadId !== undefined && suppliedThreadId !== ""
        ? slackThreadId({ channelId, threadId: suppliedThreadId })
        : undefined;
    const resolvedChannelId = tid === undefined ? channelId : slack.decodeThreadId(tid).channel;
    if (resolvedChannelId === undefined || resolvedChannelId === "") {
      throw new Error("Pass channelId or threadId, or run inside a thread.");
    }

    const chId = chatChannelId(resolvedChannelId);
    await joinChannel(chId);

    const result =
      tid === undefined
        ? await slack.fetchChannelMessages(chId, { limit, cursor })
        : await slack.fetchMessages(tid, { limit, cursor });

    const kept = includeComments
      ? result.messages
      : result.messages.filter((message) => !isComment(message));
    const omitted = result.messages.length - kept.length;

    return {
      channelId: chId,
      messages: kept.map(formatMessage),
      nextCursor: result.nextCursor,
      note:
        omitted > 0
          ? `${omitted} ${omitted === 1 ? "message" : "messages"} starting with ## were left out of this page. They are side comments nobody addressed to you. Call this again with includeComments: true if you need them.`
          : undefined,
    };
  },
});
