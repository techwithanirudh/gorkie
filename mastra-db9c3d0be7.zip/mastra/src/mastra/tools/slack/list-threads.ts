import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { slack } from "../../chat/client";
import { channelContext } from "../../lib/context";
import { chatChannelId } from "../../lib/ids";
import { input, output, slackMessageSchema } from "../../types/tools/index";
import { formatMessage, joinChannel } from "./conversations";

export const listThreadsTool = createTool({
  id: "list_threads",
  description:
    "List recent threads in a Slack channel. The current conversation is always readable; other channels must be public or a private channel the bot has already been invited to — public channels are joined automatically. Defaults to the current channel.",
  inputSchema: input({
    channelId: z
      .string()
      .optional()
      .describe(
        "Conversation id (slack:C..., slack:D..., or slack:G...); defaults to the current conversation.",
      ),
    limit: z.coerce.number().int().min(1).max(100).default(20),
    cursor: z.string().optional(),
  }),
  outputSchema: output({
    channelId: z.string(),
    threads: z.array(
      z.strictObject({
        id: z.string(),
        replyCount: z.number().optional(),
        lastReplyAt: z.string().optional(),
        rootMessage: slackMessageSchema,
      }),
    ),
    nextCursor: z.string().optional(),
  }),
  execute: async ({ channelId, limit, cursor }, context) => {
    const ctx = channelContext(context?.requestContext);
    const id = channelId ?? ctx.channelId;
    if (id === undefined || id === "") {
      throw new Error("No channel to list threads from.");
    }

    const chId = chatChannelId(id);
    await joinChannel(chId);

    const result = await slack.listThreads(chId, { limit, cursor });
    return {
      channelId: chId,
      threads: result.threads.map((thread) => ({
        id: thread.id,
        replyCount: thread.replyCount,
        lastReplyAt: thread.lastReplyAt?.toISOString(),
        rootMessage: formatMessage(thread.rootMessage),
      })),
      nextCursor: result.nextCursor,
    };
  },
});
