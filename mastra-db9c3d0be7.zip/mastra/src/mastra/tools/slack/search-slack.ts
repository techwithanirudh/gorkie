import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { env } from "@/env";
import { slack } from "../../chat/client";
import { chat } from "../../chat/instance";
import { channelContext } from "../../lib/context";
import { chatChannelId } from "../../lib/ids";
import { input, output } from "../../types/tools/index";
import { slackErrorSchema } from "./conversations";

const contextMessageSchema = z
  .looseObject({
    channel_id: z.string().optional(),
    text: z.string().optional(),
    ts: z.string().optional(),
    user_id: z.string().optional(),
  })
  .transform((message) => ({
    channelId:
      message.channel_id !== undefined && message.channel_id !== ""
        ? chatChannelId(message.channel_id)
        : undefined,
    text: message.text ?? "",
    ts: message.ts,
    userId: message.user_id,
  }));

const searchResponseSchema = z.looseObject({
  response_metadata: z.looseObject({ next_cursor: z.string().optional() }).optional(),
  results: z
    .looseObject({
      messages: z
        .array(
          z
            .looseObject({
              author_name: z.string().optional(),
              author_user_id: z.string().optional(),
              channel_id: z.string().optional(),
              channel_name: z.string().optional(),
              content: z.string().optional(),
              context_messages: z
                .looseObject({
                  after: z.array(contextMessageSchema).optional(),
                  before: z.array(contextMessageSchema).optional(),
                })
                .optional(),
              permalink: z.string().optional(),
              team_id: z.string().optional(),
            })
            .transform((message) => ({
              after: (message.context_messages?.after ?? []).slice(0, 3),
              author: message.author_name,
              before: (message.context_messages?.before ?? []).slice(-3),
              channelId:
                message.channel_id !== undefined && message.channel_id !== ""
                  ? chatChannelId(message.channel_id)
                  : undefined,
              channelName: message.channel_name,
              permalink: message.permalink,
              text: (message.content ?? "").slice(0, 1200),
              userId: message.author_user_id,
            })),
        )
        .optional(),
    })
    .optional(),
});

type SearchResponse = z.infer<typeof searchResponseSchema>;

const toOutput = async ({
  response,
  threadId,
}: {
  response: SearchResponse;
  threadId?: string;
}) => {
  const messages = response.results?.messages ?? [];
  const channelIds = new Set<string>();
  for (const message of messages) {
    if (message.channelId !== undefined && message.channelId !== "") {
      channelIds.add(message.channelId);
    }
    for (const item of [...message.before, ...message.after]) {
      const channelId = item.channelId ?? message.channelId;
      if (channelId !== undefined && channelId !== "") {
        channelIds.add(channelId);
      }
    }
  }

  const lookupVisibility = async (channelId: string): Promise<string | undefined> => {
    if (threadId !== undefined && threadId !== "" && channelId === chatChannelId(threadId)) {
      return channelId;
    }
    try {
      const metadata = await chat().channel(channelId).fetchMetadata();
      return metadata.channelVisibility === "workspace" ? channelId : undefined;
    } catch (error) {
      if (slackErrorSchema.safeParse(error).data?.data?.error === "channel_not_found") {
        return undefined;
      }
      throw error;
    }
  };
  const visibilityBatchSize = 4;
  const ids = [...channelIds];
  const batches = Array.from({ length: Math.ceil(ids.length / visibilityBatchSize) }, (_, index) =>
    ids.slice(index * visibilityBatchSize, (index + 1) * visibilityBatchSize),
  );
  const lookupBatches = async (remaining: string[][]): Promise<(string | undefined)[]> => {
    const [batch, ...rest] = remaining;
    if (batch === undefined) {
      return [];
    }
    const results = await Promise.all(batch.map(lookupVisibility));
    return [...results, ...(await lookupBatches(rest))];
  };
  const resolved = await lookupBatches(batches);
  const readable = new Set(resolved.filter((channelId) => channelId !== undefined));

  return {
    messages: messages.flatMap((message) => {
      const { channelId } = message;
      if (!(channelId !== undefined && channelId !== "" && readable.has(channelId))) {
        return [];
      }
      const contextText = (items: typeof message.before) =>
        items
          .filter((item) => readable.has(item.channelId ?? channelId))
          .map((item) => item.text.slice(0, 400));
      return [
        {
          ...message,
          after: contextText(message.after),
          before: contextText(message.before),
        },
      ];
    }),
    nextCursor: response.response_metadata?.next_cursor,
  };
};

export const searchSlackTool = createTool({
  id: "search_slack",
  description:
    "Run one Slack message search for past conversations, decisions, links, people, or internal references. Use Slack search syntax to narrow by keywords, names, channels, senders, or dates. Public channels only: DMs, private channels, and Slack Connect conversations are never searched. This returns one result page with short surrounding context; pass the returned cursor back to page through more matches, and call again with a different query for another search. Search runs as the workspace-wide public identity, so it needs a live message in the thread and never runs on scheduled or unattended turns.",
  inputSchema: input({
    query: z
      .string()
      .min(1)
      .max(500)
      .describe(
        'Slack search syntax (e.g. "deploy issue in:#eng", "from:alex budget"). For from:/to:, use the person\'s Slack username, NOT their raw user id (from:U0123ABCD will not match).',
      ),
    cursor: z
      .string()
      .optional()
      .describe("Cursor from a previous result page, passed back unchanged."),
  }),
  outputSchema: output({
    messages: z.array(
      z.strictObject({
        author: z.string().optional(),
        userId: z.string().optional(),
        channelId: z.string().optional(),
        channelName: z.string().optional(),
        text: z.string(),
        before: z.array(z.string()),
        after: z.array(z.string()),
        permalink: z.string().optional(),
      }),
    ),
    nextCursor: z.string().optional(),
  }),
  execute: async ({ query, cursor }, context) => {
    const { messageId, threadId } = channelContext(context?.requestContext);
    if (messageId === undefined || messageId === "") {
      throw new Error(
        "Slack search needs a live message in this thread. archy does not run the workspace search identity on scheduled or unattended runs. Ask the user to mention the bot, then search again.",
      );
    }
    const response = searchResponseSchema.parse(
      await slack.webClient.apiCall("assistant.search.context", {
        // Slack reads these as comma-separated strings. WebClient JSON-encodes an
        // array, which Slack then ignores, and an ignored channel_types silently
        // reopens DMs and private channels to whatever the token can reach.
        channel_types: "public_channel",
        content_types: "messages",
        cursor,
        include_context_messages: true,
        limit: 10,
        query,
        token: env.SLACK_USER_TOKEN,
      }),
    );
    return await toOutput({ response, threadId });
  },
});
