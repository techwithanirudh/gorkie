import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { slack } from "../../chat/client";
import { chatChannelId } from "../../lib/ids";
import { input, optionalCursor, output } from "../../types/tools/index";

const present = (value: string | undefined): string | undefined =>
  value === undefined || value === "" ? undefined : value;

export const listChannelsTool = createTool({
  id: "list_channels",
  description:
    "List or filter Slack channels visible to the bot. Search applies to channel names, topics, and purposes within each paginated Slack result page.",
  inputSchema: input({
    query: z.string().min(1).optional(),
    includeArchived: z.boolean().default(false),
    limit: z.coerce.number().int().min(1).max(200).default(100),
    cursor: optionalCursor,
  }),
  outputSchema: output({
    channels: z.array(
      z.strictObject({
        channelId: z.string(),
        name: z.string().optional(),
        archived: z.boolean(),
        member: z.boolean(),
        private: z.boolean(),
        memberCount: z.number().optional(),
        purpose: z.string().optional(),
        topic: z.string().optional(),
      }),
    ),
    nextCursor: z.string().optional(),
  }),
  execute: async ({ query, includeArchived, limit, cursor }) => {
    const response = await slack.webClient.conversations.list({
      cursor,
      exclude_archived: !includeArchived,
      limit,
      types: "public_channel,private_channel",
    });
    const channels = (response.channels ?? []).flatMap((channel) =>
      channel.id !== undefined && channel.id !== ""
        ? [
            {
              channelId: chatChannelId(channel.id),
              name: channel.name,
              archived: channel.is_archived ?? false,
              member: channel.is_member ?? false,
              private: channel.is_private ?? false,
              memberCount: channel.num_members,
              purpose: present(channel.purpose?.value),
              topic: present(channel.topic?.value),
            },
          ]
        : [],
    );
    const normalizedQuery = query !== undefined && query !== "" ? query.toLowerCase() : undefined;
    const matches =
      normalizedQuery === undefined
        ? channels
        : channels.filter((channel) =>
            [channel.name, channel.topic, channel.purpose].some(
              (value) => value !== undefined && value.toLowerCase().includes(normalizedQuery),
            ),
          );
    return {
      channels: matches,
      nextCursor: present(response.response_metadata?.next_cursor),
    };
  },
});
