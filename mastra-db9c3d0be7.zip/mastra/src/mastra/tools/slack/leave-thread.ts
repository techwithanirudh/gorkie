import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { chat } from "../../chat/instance";
import { channelContext } from "../../lib/context";
import { input, output } from "../../types/tools/index";
import { setThreadState } from "../../chat/state";

export const leaveThreadTool = createTool({
  id: "leave_thread",
  description:
    "Leave the current thread: stop auto-responding to its messages. Use this when asked to stop following a thread, be quiet, or let people talk without you. You can still be pinged back with a direct @mention.",
  inputSchema: input({}),
  outputSchema: output({ threadId: z.string() }),
  execute: async (_input, context) => {
    const { threadId } = channelContext(context?.requestContext);
    if (threadId === undefined || threadId === "") {
      throw new Error("No current thread.");
    }
    const thread = chat().thread(threadId);
    await setThreadState(thread, { respondOnThreadMessages: false });
    await thread.unsubscribe();
    return { threadId };
  },
});
