import { SlackFormatConverter } from "@chat-adapter/slack";
import { createTool } from "@mastra/core/tools";
import type { UserInfo } from "chat";
import { z } from "zod";
import { slack } from "../../chat/client";
import { chat } from "../../chat/instance";
import { slackDestination, targetSchema } from "../../chat/target";
import { channelContext } from "../../lib/context";
import { threadIdOf } from "../../lib/ids";
import { logger } from "../../lib/logger";
import { input, output } from "../../types/tools/index";
import { joinChannel } from "./conversations";

const markdownConverter = new SlackFormatConverter();

let cachedBotName: string | undefined;

const botDisplayName = async (botUserId: string | undefined): Promise<string> => {
  if (cachedBotName !== undefined) {
    return cachedBotName;
  }
  if (botUserId === undefined || botUserId === "") {
    return "archy";
  }
  let info: Awaited<ReturnType<typeof slack.webClient.users.info>> | null;
  try {
    info = await slack.webClient.users.info({ user: botUserId });
  } catch {
    info = null;
  }
  const profile = info?.user?.profile;
  const name = [profile?.display_name, profile?.real_name, info?.user?.name].find(
    (value) => value !== undefined && value !== "",
  );
  cachedBotName = name ?? "archy";
  return cachedBotName;
};

const resolveRequesterUser = async (userId: string | undefined): Promise<UserInfo | null> => {
  if (userId === undefined || userId === "") {
    return null;
  }
  try {
    return await chat().getUser(userId);
  } catch (error) {
    logger.debug("[post_message] failed to resolve requester for attribution", { error, userId });
    return null;
  }
};

export const postMessageTool = createTool({
  id: "post_message",
  description: `Send a markdown message to a different Slack thread, channel, or user.

Never use this to answer the current conversation, and never for status or progress updates in this thread: your normal assistant response, progress notes included, is already streamed here. Use this tool only when the user explicitly asks you to send something to a different thread, channel, or person (for example posting an update into another channel on their behalf).

Nothing here checks the target against the current channel or the requester: this can post to any channel or thread the bot is in, and DM anyone. That is not permission to. Only send to a different thread, channel, or person when the requester explicitly names that destination, and only DM someone other than the requester when the requester asks for that specific person.

Every post automatically uses the requester's Slack avatar and labels the sender as "Name [archy]". Do not add that attribution yourself in the message text; there is no way to override or customize it.

Errors: channel_not_found usually means the bot isn't a member of that private channel; not_in_channel means it hasn't joined yet. Either way, tell the user to invite the bot there.`,
  inputSchema: input({
    target: targetSchema.describe("Required destination outside the current conversation."),
    message: z.string().min(1).describe("Markdown message body."),
  }),
  outputSchema: output({
    messageId: z.string(),
    threadId: z.string().optional(),
  }),
  execute: async ({ target, message }, context) => {
    const ctx = channelContext(context?.requestContext);
    try {
      if (target.type !== "user") {
        await joinChannel(target.id);
      }
      const { channel, threadTs } = await slackDestination(target);
      const requesterUser = await resolveRequesterUser(ctx.userId);
      const requester = requesterUser?.userName ?? ctx.userName;
      const bot = await botDisplayName(ctx.botUserId);
      const credited = Boolean(requester) && target.type !== "user";
      const username = credited ? `${requester} [${bot}]` : bot;
      const avatarUrl = credited ? requesterUser?.avatarUrl : undefined;
      const chatApi = slack.webClient.chat;
      const { postMessage } = chatApi;
      const sent = await postMessage.call(chatApi, {
        channel,
        ...markdownConverter.toSlackPayload({ markdown: message }),
        icon_url: avatarUrl === "" ? undefined : avatarUrl,
        thread_ts: threadTs,
        username,
      });
      if (sent.ts === undefined || sent.ts === "") {
        throw new Error("Slack posted the message without returning its id.");
      }
      return {
        messageId: sent.ts,
        threadId: threadIdOf({ channel, ts: threadTs }),
      };
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      if (reason.includes("channel_not_found")) {
        throw new Error(
          "Slack rejected the post with channel_not_found. For private channels this usually means the bot is not a member. Ask a member to invite the bot in that channel, then retry. If the channel is public, double-check the channel id.",
          { cause: error },
        );
      }
      if (reason.includes("not_in_channel")) {
        throw new Error(
          "Slack rejected the post with not_in_channel. Invite the bot to that channel, then retry.",
          { cause: error },
        );
      }
      throw error;
    }
  },
});
