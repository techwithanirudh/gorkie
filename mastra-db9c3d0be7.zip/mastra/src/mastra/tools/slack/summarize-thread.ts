import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { summarizer } from "../../agents/summarizer";
import { slack } from "../../chat/client";
import { channelContext } from "../../lib/context";
import { chatChannelId } from "../../lib/ids";
import { input, output } from "../../types/tools/index";
import { joinChannel, slackThreadId } from "./conversations";

export const summarizeThreadTool = createTool({
  id: "summarize_thread",
  description:
    "Summarize up to 100 messages from one Slack thread without returning its full transcript to the caller. Defaults to the current thread. The current conversation is always readable; other threads must be in a public channel or a private channel the bot has already been invited to — public channels are joined automatically. Use read_conversation_history when exact wording or message metadata matters. This tool summarizes one thread per call; call it again for other threads.",
  inputSchema: input({
    threadId: z
      .string()
      .optional()
      .describe(
        "Thread to summarize (slack:<conversation-id>:ts) or a Slack message permalink. Defaults to the current thread.",
      ),
    instructions: z.string().optional().describe("Optional focus or format for the summary."),
  }),
  outputSchema: output({
    messageCount: z.number().int().min(1),
    summary: z.string(),
  }),
  execute: async ({ threadId, instructions }, context) => {
    const ctx = channelContext(context?.requestContext);
    const suppliedThreadId = threadId ?? ctx.threadId;
    if (suppliedThreadId === undefined || suppliedThreadId === "") {
      throw new Error("No thread to summarize.");
    }
    const target = slackThreadId({ threadId: suppliedThreadId });

    const channelId = chatChannelId(slack.channelIdFromThreadId(target));
    await joinChannel(channelId);

    const result = await slack.fetchMessages(target, {
      limit: 100,
      direction: "backward",
    });
    if (result.messages.length === 0) {
      throw new Error("No messages found in the thread.");
    }

    const lines = result.messages.map((message, index) => {
      const author = message.author.fullName || message.author.userName || message.author.userId;
      const attachments = message.attachments
        .map((attachment) => {
          const label = attachment.name ?? attachment.type;
          const url =
            attachment.url === undefined || attachment.url === "" ? "" : `, ${attachment.url}`;
          return `[attachment: ${label}${url}]`;
        })
        .join(" ");
      const suffix = attachments ? ` ${attachments}` : "";
      return `${index + 1}. [${message.metadata.dateSent.toISOString()}] ${author} (${message.author.userId}): ${message.text}${suffix}`;
    });
    const transcript = lines.join("\n");

    const focus =
      instructions === undefined || instructions === ""
        ? ""
        : `Focus requested by the user: ${instructions}\n\n`;
    const prompt = `${focus}<transcript>\n${transcript}\n</transcript>`;
    const { text } = await summarizer.generate(prompt);

    return {
      messageCount: result.messages.length,
      summary: text,
    };
  },
});
