import { getChannelInfoTool } from "./get-channel-info";
import { getPermalinkTool } from "./get-permalink";
import { getSlackFileTool } from "./get-slack-file";
import { getUserTool } from "./get-user";
import { joinThreadTool } from "./join-thread";
import { leaveThreadTool } from "./leave-thread";
import { listChannelsTool } from "./list-channels";
import { listThreadsTool } from "./list-threads";
import { postMessageTool } from "./post-message";
import { reactTool } from "./react";
import { readConversationHistoryTool } from "./read-conversation-history";
import { searchSlackTool } from "./search-slack";
import { summarizeThreadTool } from "./summarize-thread";
import { uploadFileTool } from "./upload-file";

export const slackTools = {
  get_channel_info: getChannelInfoTool,
  get_permalink: getPermalinkTool,
  get_slack_file: getSlackFileTool,
  get_user: getUserTool,
  join_thread: joinThreadTool,
  leave_thread: leaveThreadTool,
  list_channels: listChannelsTool,
  list_threads: listThreadsTool,
  post_message: postMessageTool,
  react: reactTool,
  read_conversation_history: readConversationHistoryTool,
  search_slack: searchSlackTool,
  summarize_thread: summarizeThreadTool,
  upload_file: uploadFileTool,
};
