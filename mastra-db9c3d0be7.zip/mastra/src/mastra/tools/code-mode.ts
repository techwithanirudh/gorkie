import type { ToolsInput } from "@mastra/core/agent";
import { createCodeMode, createTool } from "@mastra/core/tools";
import type { Tool } from "@mastra/core/tools";
import { QuickJsCodeModeTransport } from "@mastra/quickjs";
import { z } from "zod";
import { sandbox as config } from "../config";
import { mcpTools } from "../mcp";
import { visibility } from "../mcp/visibility";

const maxTextLength = 40_000;

const jsonSchema = z.json();
type Json = z.infer<typeof jsonSchema>;

const textResultSchema = z.object({
  content: z.array(z.object({ text: z.string(), type: z.literal("text") })).min(1),
});
const resultWrapperSchema = z.strictObject({ result: jsonSchema });
const objectSchema = z.record(z.string(), jsonSchema);

// Vercel puts every payload under `result`, and a list can nest again under its
// own name: `{ deployments: { pagination, deployments } }`.
const peel = (value: Json): Json => {
  const wrapper = resultWrapperSchema.safeParse(value);
  if (wrapper.success) {
    return peel(wrapper.data.result);
  }
  const object = objectSchema.safeParse(value);
  const [only, ...others] = object.success ? Object.entries(object.data) : [];
  if (only === undefined || others.length > 0) {
    return value;
  }
  const [key, inner] = only;
  const nested = objectSchema.safeParse(inner);
  return nested.success && key in nested.data ? nested.data : value;
};

const clip = (text: string): string => {
  if (text.length <= maxTextLength) {
    return text;
  }
  const lineEnd = text.lastIndexOf("\n", maxTextLength);
  const kept = text.slice(0, lineEnd > 0 ? lineEnd : maxTextLength);
  return `${kept}\n\n[query_connectors truncated this result: kept the first ${kept.length} of ${text.length} characters. Narrow the call to read the rest.]`;
};

const decode = (text: string): Json => {
  try {
    return peel(jsonSchema.parse(JSON.parse(text)));
  } catch {
    return clip(text);
  }
};

// MCP servers answer with `{ content: [{ type: "text", text }] }`, where the text
// is usually JSON. Programs get the payload itself, so none of them re-derives
// the envelope; anything else, such as structured content, passes through.
const readable = (tool: Tool): Tool =>
  createTool({
    description: tool.description,
    execute: async (input, context) => {
      const result = await tool.execute?.(input, context);
      const envelope = textResultSchema.safeParse(result);
      if (!envelope.success) {
        return result;
      }
      const payloads = envelope.data.content.map(({ text }) => decode(text));
      return payloads.length === 1 ? payloads[0] : payloads;
    },
    id: tool.id,
    inputSchema: tool.inputSchema,
  });

const codeModeTools = async (): Promise<ToolsInput> => {
  const mcp = await mcpTools();
  return Object.fromEntries(
    Object.entries(mcp)
      .filter(([, tool]) => visibility(tool) === "codeMode")
      .map(([id, tool]) => [id, readable(tool)]),
  );
};

const description =
  "Read from the Linear, PostHog, and Vercel connectors by writing a TypeScript program. " +
  "Their read tools exist only here, as the external_* functions this tool's instructions " +
  "declare: they are not in your tool list and tool search will not return them. Batch " +
  "several reads into one program rather than running one program per read. Each function " +
  "resolves to the connector's payload, already parsed: JSON arrives as objects with any " +
  "`result` wrapper removed, and a connector that answers in text, such as Vercel runtime " +
  "errors and logs or PostHog SQL, arrives as a string, cut to " +
  `${maxTextLength.toLocaleString("en-US")} characters with a note when longer.`;

type CodeMode = ReturnType<typeof createCodeMode>;

const createConnectorCodeMode = async (): Promise<CodeMode> => {
  const created = createCodeMode(
    { id: "query_connectors", timeout: config.codeModeTimeout, tools: await codeModeTools() },
    new QuickJsCodeModeTransport(),
  );
  // Assigned rather than spread: the tool is a class instance, and a spread
  // copy would drop its prototype.
  Object.assign(created.tool, { description });
  return created;
};

let created: Promise<CodeMode> | undefined;

export const codeMode = async (): Promise<CodeMode> => {
  created ??= createConnectorCodeMode();
  return await created;
};
