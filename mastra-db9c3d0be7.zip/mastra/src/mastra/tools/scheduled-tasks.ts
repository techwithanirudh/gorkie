import type { AgentSchedule, AnySchedule, Schedules } from "@mastra/core/schedules";
import { createTool } from "@mastra/core/tools";
import { computeNextFireAt, validateCron } from "@mastra/core/workflows";
import { z } from "zod";
import { agent as agentConfig, scheduledTasks } from "../config";
import { channelContext } from "../lib/context";
import { input, output } from "../types/tools/index";

export const waitMetadata = { kind: "wait" };

export const isWaitSchedule = (schedule: AnySchedule): boolean =>
  schedule.metadata?.kind === waitMetadata.kind;

const isScheduledTask = (schedule: AnySchedule): schedule is AgentSchedule =>
  schedule.agentId === agentConfig.id && !isWaitSchedule(schedule);

const minMinutes = scheduledTasks.minInterval / 60_000;

const assertMinimumInterval = (cron: string, timezone?: string): void => {
  validateCron(cron, timezone);
  let previous = computeNextFireAt(cron, { timezone });
  for (let i = 1; i < 5; i += 1) {
    let fire: number;
    try {
      fire = computeNextFireAt(cron, { after: previous, timezone });
    } catch {
      break;
    }
    const gap = fire - previous;
    if (gap < scheduledTasks.minInterval) {
      throw new Error(
        `That schedule fires every ${Math.round(gap / 60_000)} minutes. Minimum interval is ${minMinutes} minutes.`,
      );
    }
    previous = fire;
  }
};

const conversation = (
  agent: { resourceId?: string; threadId?: string } | undefined,
  schedules: Schedules | undefined,
) => {
  const { resourceId, threadId } = agent ?? {};
  if (!schedules || resourceId === undefined || resourceId === "") {
    throw new Error("No current Slack conversation with a schedule service to manage.");
  }
  return { resourceId, schedules, threadId };
};

const manageTool = (id: string, description: string, action: "delete" | "pause" | "resume") =>
  createTool({
    id,
    description,
    inputSchema: input({ id: z.string().min(1).describe("Schedule ID.") }),
    outputSchema: output({ schedule: z.unknown() }),
    execute: async ({ id: scheduleId }, context) => {
      const { resourceId, schedules } = conversation(context.agent, context.mastra?.schedules);
      const schedule = await schedules.get(scheduleId);
      if (!schedule || !isScheduledTask(schedule) || schedule.resourceId !== resourceId) {
        throw new Error(`Schedule ${scheduleId} was not found in this conversation.`);
      }
      if (action === "delete") {
        await schedules.delete(scheduleId);
        return { schedule };
      }
      return { schedule: await schedules[action](scheduleId) };
    },
  });

export const scheduledTaskTools = {
  create_scheduled_task: createTool({
    id: "create_scheduled_task",
    description: `Create a recurring schedule for the current Slack conversation. Use a valid cron expression and optional IANA timezone. Minimum interval is ${minMinutes} minutes between fires, each run costs model credits: never request a faster cadence, refuse and offer the nearest ${minMinutes}-minute-or-slower option instead.`,
    inputSchema: input({
      task: z.string().min(1).describe("Prompt to run on the schedule."),
      cron: z
        .string()
        .min(1)
        .describe(
          `Cron expression for when to run. Minimum interval: ${minMinutes} minutes between fires.`,
        ),
      name: z
        .string()
        .min(1)
        .max(120)
        .optional()
        .describe("Short human-readable name for the schedule."),
      timezone: z.string().min(1).optional().describe("IANA timezone, such as America/New_York."),
    }),
    outputSchema: output({ schedule: z.unknown() }),
    execute: async ({ task, cron, name, timezone }, context) => {
      const { resourceId, schedules, threadId } = conversation(
        context.agent,
        context.mastra?.schedules,
      );
      if (threadId === undefined || threadId === "") {
        throw new Error("No current Slack thread to schedule into.");
      }
      assertMinimumInterval(cron, timezone);
      return {
        schedule: await schedules.create({
          agentId: agentConfig.id,
          cron,
          ifActive: { behavior: "persist" },
          ifIdle: {
            behavior: "wake",
            streamOptions: {
              requestContext: { channel: channelContext(context.requestContext) },
            },
          },
          name,
          prompt: task,
          resourceId,
          signalType: "notification",
          threadId,
          timezone,
        }),
      };
    },
  }),
  delete_scheduled_task: manageTool(
    "delete_scheduled_task",
    "Permanently delete a recurring schedule.",
    "delete",
  ),
  list_scheduled_tasks: createTool({
    id: "list_scheduled_tasks",
    description: "List recurring schedules belonging to the current Slack conversation resource.",
    inputSchema: input({}),
    outputSchema: output({ schedules: z.array(z.unknown()) }),
    execute: async (_input, context) => {
      const { resourceId, schedules } = conversation(context.agent, context.mastra?.schedules);
      const rows = await schedules.list({ agentId: agentConfig.id, resourceId });
      return { schedules: rows.filter(isScheduledTask) };
    },
  }),
  pause_scheduled_task: manageTool(
    "pause_scheduled_task",
    "Pause a recurring schedule without deleting it.",
    "pause",
  ),
  resume_scheduled_task: manageTool(
    "resume_scheduled_task",
    "Resume a paused schedule in the current Slack conversation.",
    "resume",
  ),
};
