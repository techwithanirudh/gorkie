import type { CoreSystemMessage } from "@mastra/core/llm";
import type { RequestContext } from "@mastra/core/request-context";
import { companyPrompt } from "./company";
import { connectorsPrompt } from "./connectors";
import { contextPrompt } from "./context";
import { corePrompt, progressPrompt } from "./core";
import { guardrailsPrompt } from "./guardrails";
import { investigationPrompt } from "./investigation";
import { personalityPrompt } from "./personality";
import { playbookPrompt } from "./playbooks";
import { reasoningPrompt } from "./reasoning";
import { slackPrompt } from "./slack";
import { toolsPrompt } from "./tools";
import { unpromptedPrompt } from "./unprompted";

const sharedPrompts = [
  personalityPrompt,
  slackPrompt,
  toolsPrompt,
  companyPrompt,
  connectorsPrompt,
  investigationPrompt,
  guardrailsPrompt,
];

const promptedPrompts = [corePrompt, progressPrompt, reasoningPrompt, ...sharedPrompts];

const unpromptedPrompts = [corePrompt, ...sharedPrompts, unpromptedPrompt];

export const instructions = (requestContext: RequestContext): CoreSystemMessage[] => {
  const prompts = requestContext.get("unprompted") === true ? unpromptedPrompts : promptedPrompts;
  const context = contextPrompt(requestContext);
  const messages: CoreSystemMessage[] = [{ content: prompts.join("\n\n"), role: "system" }];
  if (context) {
    messages.push({ content: context, role: "system" });
  }
  const playbook = playbookPrompt(requestContext.get("playbook"));
  if (playbook !== undefined) {
    messages.push({ content: playbook, role: "system" });
  }
  return messages;
};
