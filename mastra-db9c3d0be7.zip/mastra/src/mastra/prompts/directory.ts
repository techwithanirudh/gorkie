import type { Directory } from "../lib/directory";
import { resolveDirectory } from "../lib/directory";

const detail = (person: { timezone?: string; title?: string }): string => {
  const parts = [person.title, person.timezone].filter(Boolean);
  return parts.length > 0 ? ` · ${parts.join(", ")}` : "";
};

const handle = (name: string, slackHandle: string | undefined): string =>
  slackHandle !== undefined && slackHandle !== name ? `${name} (@${slackHandle})` : name;

const renderDirectory = (directory: Directory): string | undefined => {
  const linked = directory.people.filter((person) => person.linear);
  const unlinked = directory.people.filter((person) => !person.linear);
  if (linked.length === 0 && unlinked.length === 0) {
    return undefined;
  }

  const lines: string[] = [
    "<directory>",
    "Everyone in this Slack workspace, joined to their Linear account by email address. Read a person out of here instead of searching for them.",
    "",
    "Each line is: name (Slack handle) · slack <id> · linear <id> · title, timezone.",
    "`slack` and `linear` are column labels, not part of the value. A Slack id looks like U0123ABCD and a Linear id is a bare UUID. Pass the id exactly as printed, with nothing prepended. A tool given `linear:<uuid>` fails to find the user.",
    "",
  ];

  for (const person of linked) {
    lines.push(
      `- ${handle(person.name, person.handle)} · slack ${person.slackId} · linear ${person.linear?.id}${detail(person)}`,
    );
  }

  if (unlinked.length > 0) {
    lines.push("", "In Slack with no Linear account:");
    for (const person of unlinked) {
      lines.push(
        `- ${handle(person.name, person.handle)} · slack ${person.slackId}${detail(person)}`,
      );
    }
  }

  if (directory.linearOnly.length > 0) {
    lines.push("", "In Linear with no Slack account:");
    for (const person of directory.linearOnly) {
      lines.push(`- ${person.name} (@${person.displayName}) · linear ${person.id}`);
    }
  }

  lines.push(
    "",
    "Do not pass `me` to Linear. It resolves to the API key's owner rather than to whoever is asking.",
    "",
    "Someone who is not listed here is not in this workspace. Say so rather than guessing at a name that looks close.",
    "</directory>",
  );

  return lines.join("\n");
};

export const directoryPrompt = async (): Promise<string | undefined> => {
  const directory = await resolveDirectory();
  return directory ? renderDirectory(directory) : undefined;
};
