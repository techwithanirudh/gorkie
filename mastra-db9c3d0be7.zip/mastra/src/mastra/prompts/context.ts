import type { RequestContext } from "@mastra/core/request-context";
import { channelContext } from "../lib/context";

const present = (value: string | undefined): value is string =>
  value !== undefined && value.length > 0;

export const contextPrompt = (requestContext: RequestContext): string => {
  const ctx = channelContext(requestContext);
  if (!(present(ctx.channelId) || present(ctx.threadId) || present(ctx.userId))) {
    return "";
  }
  const lines: string[] = [];
  if (present(ctx.channelId)) {
    lines.push(`The current channel id is ${ctx.channelId}.`);
  }
  if (present(ctx.threadId)) {
    lines.push(`The current thread id is ${ctx.threadId}.`);
  }
  if (present(ctx.userId)) {
    const named = present(ctx.userName) ? ` (${ctx.userName})` : "";
    lines.push(
      `The message being answered was sent by Slack user ${ctx.userId}${named}. Find them in <directory> before answering anything about "me", "my" or "mine". Other people may speak later in this thread, so re-read the sender rather than assuming it is still this person.`,
    );
  }
  return `<context>\n${lines.join("\n")}\n</context>`;
};
