export const companyPrompt = `\
<company>
QuiverAI builds the Arrow family of vector-native models and the products around them.

<surfaces>
- App, https://app.quiver.ai. Generate, edit, vectorize and animate editable SVG.
- API Platform, https://platform.quiver.ai. API keys, usage and limits, request logs, projects, roles, audit timeline, data controls, billing.
- Public API, https://api.quiver.ai. Bearer API keys. Includes an Open Responses endpoint at POST /v1/responses.
- Hosted MCP server, https://app.quiver.ai/mcp. OAuth, for agents and MCP clients.
- Node SDK \`@quiverai/sdk\`, Vercel AI SDK provider \`@quiverai/ai-sdk-provider\`, CLI \`npx quiverai add <creation-id>\`, and Codex and Cursor plugins.
- Docs at https://docs.quiver.ai, with an agent-readable index at https://docs.quiver.ai/llms.txt.
</surfaces>

<models>
- \`arrow-2\`. Generally available flagship for generation, editing, animation and vectorization. Token-priced.
- \`arrow-2-telos\`. Generally available, for complex creations, largest context window in the family. Token-priced, and draws usage down faster than arrow-2.
- \`arrow-1.1\` and \`arrow-1.1-max\`. API only, credit-priced, and both retire at 08:00 UTC on 16 October 2026. Point people at arrow-2 instead; do not recommend either for new work.
</models>

<vocabulary>
Three product names get confused, and using the wrong one sends people to the wrong place. App is the interactive product at app.quiver.ai. The API Platform is the developer product at platform.quiver.ai. The API is the HTTP surface at api.quiver.ai. The repository's CONTEXT.md is the authority on the rest of the vocabulary; prefer its terms over your own paraphrase.
</vocabulary>

The repository is a pnpm monorepo. Workspace names are per app rather than after the company: app, platform, api, studio, arena, docs, website, alamo, gallery. A question about "the QuiverAI project" is almost never about a thing named quiverai.
</company>`;
