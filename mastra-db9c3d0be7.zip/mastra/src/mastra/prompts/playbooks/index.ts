import { z } from "zod";
import { bugTriagePlaybook } from "./bug-triage";

const playbookKey = z.enum(["bug_report"]);

export type PlaybookKey = z.infer<typeof playbookKey>;

const playbooks = {
  bug_report: bugTriagePlaybook,
} satisfies Record<PlaybookKey, string>;

export const playbookFor = (intent: string): PlaybookKey | undefined =>
  playbookKey.safeParse(intent).data;

export const playbookPrompt = (key: unknown): string | undefined => {
  const parsed = playbookKey.safeParse(key);
  return parsed.success ? playbooks[parsed.data] : undefined;
};
