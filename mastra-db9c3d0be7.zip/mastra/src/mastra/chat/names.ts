import type { UsersInfoResponse, UsersProfileGetResponse } from "@slack/web-api";
import { rawId } from "../lib/ids";
import type { UserProfile } from "../types";
import { logger } from "../lib/logger";
import { slack } from "./client";
import { chat } from "./instance";

const isPresent = (value: string | undefined): value is string =>
  value !== undefined && value !== "";

const blankToUndefined = (value: string | undefined): string | undefined =>
  value === undefined || value === "" ? undefined : value;

const toUserProfile = (
  raw: UsersProfileGetResponse["profile"],
  info: UsersInfoResponse["user"],
): UserProfile => ({
  displayName: blankToUndefined(raw?.display_name),
  fields: Object.values(raw?.fields ?? {}).flatMap((field) =>
    isPresent(field.value) && isPresent(field.label)
      ? [{ label: field.label, value: field.value }]
      : [],
  ),
  pronouns: blankToUndefined(raw?.pronouns),
  realName: blankToUndefined(raw?.real_name),
  status: blankToUndefined(raw?.status_text),
  timezone: blankToUndefined(info?.tz),
  timezoneLabel: blankToUndefined(info?.tz_label),
  title: blankToUndefined(raw?.title),
});

export const resolveUserProfile = async (id: string): Promise<UserProfile | undefined> => {
  const userId = rawId(id);
  const cacheKey = `slack:user-profile:${userId}`;
  const bot = chat();
  const cached = await bot.getState().get<UserProfile>(cacheKey);
  if (cached) {
    return cached;
  }

  const user = await bot.getUser(userId);
  let profile: UserProfile | undefined;
  try {
    const [{ profile: raw }, { user: info }] = await Promise.all([
      slack.webClient.users.profile.get({
        include_labels: true,
        user: userId,
      }),
      slack.webClient.users.info({ user: userId }),
    ]);
    if (!(raw || user)) {
      return undefined;
    }
    profile = toUserProfile(raw, info);
    try {
      await bot.getState().set(cacheKey, profile, 86_400_000);
    } catch (error) {
      logger.debug("[slack] could not cache user profile", { error, userId });
    }
  } catch {
    if (!user) {
      return undefined;
    }
    profile = { fields: [] };
    try {
      await bot.getState().set(cacheKey, profile, 60_000);
    } catch (error) {
      logger.debug("[slack] could not cache fallback user profile", { error, userId });
    }
  }

  return {
    ...profile,
    displayName: user?.userName ?? profile.displayName,
    realName: user?.fullName ?? profile.realName,
  };
};
