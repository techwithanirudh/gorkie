import type { Message } from "chat";
import { z } from "zod";

const slackRawText = z.looseObject({ text: z.string() });

export const rawText = (message: Message): string => {
  const raw = slackRawText.safeParse(message.raw);
  return raw.success ? raw.data.text : message.text;
};

export const withoutLeadingMentions = (text: string): string =>
  text.replace(/^\s*(?:<@[A-Z0-9][A-Z0-9._-]*(?:\|[^>]+)?>\s*)+/u, "");

export const isComment = (message: Message): boolean => {
  const first = rawText(message)
    .split("\n")
    .find((line) => line.trim() !== "");
  return first !== undefined && withoutLeadingMentions(first).trimStart().startsWith("##");
};
