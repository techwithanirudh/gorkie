import type { Message, Thread } from "chat";
import { logger } from "../lib/logger";
import { attachments } from "./attachments";
import { slack } from "./client";
import { handleCommand } from "./commands";
import { withHistory } from "./history";
import { isComment } from "./message";
import { setThreadState, threadState } from "./state";

type DefaultHandler = (thread: Thread, message: Message) => Promise<void>;

const FROM_A_BOT = "from a bot";

const declined = (reason: string, thread: Thread, message: Message): void => {
  logger.debug("[chat] message not answered", {
    author: message.author.userName,
    isMention: message.isMention,
    messageId: message.id,
    reason,
    threadId: thread.id,
  });
};

export const isFromBot = (message: Message): boolean =>
  message.author.isBot === true || message.author.userId === "USLACKBOT" || message.author.isMe;

export const mentionsArchy = (message: Message): boolean => {
  const { botUserId } = slack;
  return (
    message.isMention === true ||
    (botUserId !== undefined && message.text.includes(`<@${botUserId}>`))
  );
};

const turnMessage = async (thread: Thread, message: Message): Promise<Message> =>
  await withHistory({ message: attachments(message), thread });

const runTurn = async (
  thread: Thread,
  message: Message,
  defaultHandler: DefaultHandler,
): Promise<void> => {
  if (await handleCommand({ message, thread })) {
    declined("handled as a command", thread, message);
    return;
  }
  logger.info("[chat] turn started", {
    attachments: message.attachments.map((attachment) => ({
      name: attachment.name,
      mimeType: attachment.mimeType,
      size: attachment.size,
      url: attachment.url ?? attachment.fetchMetadata?.url,
    })),
    author: message.author.userName,
    text: message.text,
    threadId: thread.id,
  });

  await defaultHandler(thread, await turnMessage(thread, message));
};

export const onMention = async (
  thread: Thread,
  message: Message,
  defaultHandler: DefaultHandler,
): Promise<void> => {
  if (isFromBot(message)) {
    declined(FROM_A_BOT, thread, message);
    return;
  }
  if (slack.decodeThreadId(message.threadId).threadTs === message.id) {
    await setThreadState(thread, { respondOnThreadMessages: true });
  }
  await runTurn(thread, message, defaultHandler);
};

export const onSubscribedMessage = async (
  thread: Thread,
  message: Message,
  defaultHandler: DefaultHandler,
): Promise<void> => {
  if (isFromBot(message) || isComment(message)) {
    declined(isFromBot(message) ? FROM_A_BOT : "a comment", thread, message);
    return;
  }
  const state = await threadState(thread);
  const isFollowingThread = state?.respondOnThreadMessages === true;
  if (!(isFollowingThread || mentionsArchy(message))) {
    declined("not a mention and not following this thread", thread, message);
    return;
  }
  await runTurn(thread, message, defaultHandler);
};

export const onDirectMessage = async (
  thread: Thread,
  message: Message,
  defaultHandler: DefaultHandler,
): Promise<void> => {
  if (isFromBot(message)) {
    declined(FROM_A_BOT, thread, message);
    return;
  }
  await runTurn(thread, message, defaultHandler);
};
