import { agent as agentConfig } from "../../config";
import { logger } from "../../lib/logger";
import type { CommandHandler } from "../../types";
import { getMastra } from "../mastra-instance";

const stopThread = async (threadId: string): Promise<"aborted" | "cancelled" | "idle"> => {
  const mastra = getMastra();
  const orchestrator = mastra.getAgent(agentConfig.id);
  const runs = orchestrator.listActiveThreadRuns().filter((run) => run.threadId === threadId);
  const manager = mastra.backgroundTaskManager;

  let backgroundTasks: { id: string }[] = [];
  if (manager) {
    try {
      const listed = await manager.listTasks({
        agentId: agentConfig.id,
        status: ["pending", "running", "suspended"],
        threadId,
      });
      backgroundTasks = listed.tasks;
    } catch (error) {
      logger.warn("[commands] Failed to list background tasks for stop", {
        error,
        threadId,
      });
    }
  }

  const isRunning = runs.length > 0;
  if (!isRunning && backgroundTasks.length === 0) {
    return "idle";
  }
  for (const { resourceId } of runs) {
    orchestrator.abortThreadStream({ resourceId, threadId });
  }
  if (manager) {
    const cancellations = await Promise.allSettled(
      backgroundTasks.map((task) => manager.cancel(task.id)),
    );
    if (cancellations.some(({ status }) => status === "rejected")) {
      logger.warn("[commands] Some background tasks failed to stop", {
        threadId,
      });
    }
  }
  return isRunning ? "aborted" : "cancelled";
};

export const stop: CommandHandler = async ({ message, thread }) => {
  const outcome = await stopThread(thread.id);
  if (outcome === "aborted") {
    return;
  }
  if (outcome === "cancelled") {
    await thread.post({ markdown: "_Stopped._" });
    return;
  }
  try {
    await thread.postEphemeral(message.author, "Nothing to stop right now.", {
      fallbackToDM: false,
    });
  } catch (error) {
    logger.warn("[commands] Failed to post stop feedback", {
      error,
      threadId: thread.id,
      userId: message.author.userId,
    });
  }
};
