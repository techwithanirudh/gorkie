import type { Message, Thread } from "chat";
import type { CommandHandler } from "../../types";
import { rawText, withoutLeadingMentions } from "../message";
import { stop } from "./stop";

const commands = new Map<string, CommandHandler>([["stop", stop]]);

export const handleCommand = async ({
  message,
  thread,
}: {
  message: Message;
  thread: Thread;
}): Promise<boolean> => {
  const body = withoutLeadingMentions(rawText(message)).trim();
  const match = /^!(?<name>\w+)\b/iu.exec(body);
  const name = match?.[1]?.toLowerCase();
  const command = name === undefined ? undefined : commands.get(name);
  if (!command) {
    return false;
  }
  await command({ message, thread });
  return true;
};
