import type { Chat, Message, Thread } from "chat";
import type { Mastra } from "@mastra/core/mastra";
import { Agent } from "@mastra/core/agent";
import { RequestContext } from "@mastra/core/request-context";
import { z } from "zod";
import { env } from "@/env";
import { relevance as config } from "../config";
import { rawId } from "../lib/ids";
import { logger } from "../lib/logger";
import { relevancePrompt } from "../prompts/relevance";
import { classifier as classifierModel } from "../providers";
import orchestrator from "../agents/orchestrator";
import { playbookFor } from "../prompts/playbooks";
import type { PlaybookKey } from "../prompts/playbooks";
import { slack } from "./client";
import { isFromBot, mentionsArchy } from "./handlers";
import { getMastra } from "./mastra-instance";

const intents = ["question", "bug_report", "decision_request", "status_check", "other"] as const;

const verdictSchema = z.object({
  confidence: z.number().min(0).max(1),
  intent: z.enum(intents),
  trigger: z.boolean(),
});

const optedInChannels = new Set(
  (env.RELEVANCE_ENGINE_CHANNELS ?? "")
    .split(",")
    .map((id) => id.trim())
    .filter((id) => id.length > 0),
);

export const relevanceClassifier = new Agent({
  description:
    "Judges whether an ambient Slack channel message (no mention, no active subscription) is worth archy answering unprompted.",
  id: "relevance-classifier",
  instructions: relevancePrompt,
  model: classifierModel,
  name: "Relevance Classifier",
});

const truncate = (text: string): string =>
  text.length > config.maxContextChars ? `${text.slice(0, config.maxContextChars)}…` : text;

const collectLines = async (
  source: AsyncIterable<Message>,
  excludeMessageId: string,
): Promise<string[]> => {
  const lines: string[] = [];
  for await (const previous of source) {
    if (previous.id !== excludeMessageId) {
      const author = previous.author.fullName || previous.author.userName || previous.author.userId;
      lines.push(`[${author}]: ${truncate(previous.text)}`);
    }
    if (lines.length >= config.maxContextMessages) {
      break;
    }
  }
  return lines.toReversed();
};

const contextWindow = async (thread: Thread, message: Message): Promise<string[]> =>
  await collectLines(thread.channel.messages, message.id);

const classify = async (
  contextLines: string[],
  message: Message,
): Promise<z.infer<typeof verdictSchema> | undefined> => {
  const author = message.author.fullName || message.author.userName || message.author.userId;
  const prompt = [
    ...(contextLines.length > 0
      ? ["[Recent channel messages, oldest first, background only]", ...contextLines, ""]
      : []),
    `[Candidate message from ${author}]: ${truncate(message.text)}`,
  ].join("\n");

  const { object } = await relevanceClassifier.generate(prompt, {
    modelSettings: { maxOutputTokens: 8192 },
    structuredOutput: { schema: verdictSchema },
  });
  // Typed as always present, but malformed JSON from the model produces no object.
  return verdictSchema.safeParse(object).data;
};

interface TurnRunner {
  handleChatMessage: (
    thread: Thread,
    message: Message,
    mastra: Mastra,
    requestContext: RequestContext,
    signalMetadata: Readonly<Record<never, never>>,
  ) => Promise<void>;
}

const isTurnRunner = (value: unknown): value is TurnRunner =>
  typeof value === "object" &&
  value !== null &&
  "handleChatMessage" in value &&
  typeof value.handleChatMessage === "function";

const answer = async (
  thread: Thread,
  message: Message,
  playbook: PlaybookKey | undefined,
): Promise<boolean> => {
  const runner: unknown = orchestrator.getChannels();
  if (!isTurnRunner(runner)) {
    logger.error("[relevance] cannot answer: AgentChannels no longer exposes handleChatMessage");
    return false;
  }
  const requestContext = new RequestContext();
  requestContext.set("unprompted", true);
  if (playbook !== undefined) {
    requestContext.set("playbook", playbook);
  }
  await runner.handleChatMessage(thread, message, getMastra(), requestContext, {});
  return true;
};

const evaluateAmbientMessage = async (thread: Thread, message: Message): Promise<void> => {
  if (isFromBot(message) || mentionsArchy(message)) {
    return;
  }

  if (slack.decodeThreadId(message.threadId).threadTs !== message.id) {
    return;
  }

  const channelId = rawId(thread.channelId);
  if (!optedInChannels.has(channelId)) {
    return;
  }

  try {
    const contextLines = await contextWindow(thread, message);
    const verdict = await classify(contextLines, message);
    if (verdict === undefined) {
      logger.warn("[relevance] classifier returned no verdict", {
        channelId,
        messageId: message.id,
      });
      return;
    }
    const wouldSpeak = verdict.trigger && verdict.confidence >= config.minConfidence;
    const playbook = playbookFor(verdict.intent);
    const answered = wouldSpeak && (await answer(thread, message, playbook));
    logger.info("[relevance] verdict", {
      answered,
      playbook,
      channelId,
      confidence: verdict.confidence,
      decision: wouldSpeak ? "answer" : "stay-quiet",
      intent: verdict.intent,
      messageId: message.id,
      threadId: thread.id,
      withheld: verdict.trigger && !wouldSpeak,
    });
  } catch (error) {
    logger.warn("[relevance] classifier call failed", { channelId, error, messageId: message.id });
  }
};

export const registerRelevanceEngine = (bot: Chat): void => {
  if (!env.RELEVANCE_ENGINE_ENABLED) {
    return;
  }
  bot.onNewMessage(/^/u, (thread, message) => evaluateAmbientMessage(thread, message));
};
