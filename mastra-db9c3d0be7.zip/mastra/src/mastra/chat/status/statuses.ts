import { z } from "zod";
import { fileName, fit, str } from "./format";
import type { Args } from "./format";

const postTargetSchema = z.looseObject({ type: z.string().optional() });

const withArg =
  (
    key: string,
    idle: string,
    prefix: string,
    suffix: string,
    display: (value: string) => string = (value) => value,
  ) =>
  (args: Args): string => {
    const value = str(args, key);
    return value === undefined ? idle : fit(prefix, display(value), suffix);
  };

const fixed = (text: string) => (): string => text;

const createScheduledTask = (args: Args) => {
  const name = str(args, "name") ?? str(args, "task");
  return name === undefined ? "is scheduling a task…" : fit('is scheduling "', name, '"…');
};

const fetchUrl = (args: Args) => {
  const url = str(args, "url");
  if (url === undefined || !URL.canParse(url)) {
    return "is reading a web page…";
  }
  return fit("is reading ", new URL(url).hostname, "…");
};

const listFiles = (args: Args) => {
  const path = str(args, "path");
  return path === undefined || path === "."
    ? "is listing files…"
    : fit("is listing ", fileName(path), "…");
};

const postMessage = (args: Args) => {
  const target = postTargetSchema.safeParse(args.target).data;
  if (target?.type === "user") {
    return "is sending a DM…";
  }
  if (target?.type === "channel" || target?.type === "thread") {
    return `is sending a message to the ${target.type}…`;
  }
  return "is sending a message…";
};

const statusByTool = {
  create_canvas: withArg("title", "is creating a canvas…", 'is creating the canvas "', '"…'),
  create_scheduled_task: createScheduledTask,
  delete_file: withArg("path", "is deleting a file…", "is deleting ", "…", fileName),
  delete_scheduled_task: fixed("is deleting a scheduled task…"),
  edit_canvas: fixed("is editing a canvas…"),
  edit_file: withArg("path", "is editing a file…", "is editing ", "…", fileName),
  execute_command: withArg("command", "is running a command…", "is running `", "`…"),
  fetch_url: fetchUrl,
  file_stat: withArg("path", "is checking a file…", "is checking ", "…", fileName),
  get_channel_info: fixed("is checking a channel…"),
  get_permalink: fixed("is getting a Slack link…"),
  get_process_output: withArg("pid", "is checking a process…", "is checking process ", "…"),
  get_slack_file: fixed("is downloading a Slack file…"),
  get_user: fixed("is looking up a user…"),
  grep: withArg("pattern", "is searching files…", 'is searching files for "', '"…'),
  kill_process: withArg("pid", "is stopping a process…", "is stopping process ", "…"),
  leave_thread: fixed("is leaving the thread…"),
  list_canvases: withArg("query", "is listing canvases…", 'is listing canvases: "', '"…'),
  list_channels: withArg("query", "is listing channels…", 'is listing channels: "', '"…'),
  list_files: listFiles,
  list_scheduled_tasks: fixed("is checking scheduled tasks…"),
  list_threads: fixed("is listing threads…"),
  load_tool: fixed("is loading a tool…"),
  lookup_canvas_sections: fixed("is inspecting a canvas…"),
  pause_scheduled_task: fixed("is pausing a scheduled task…"),
  post_message: postMessage,
  react: (args) => {
    const emoji = str(args, "emoji");
    if (emoji === undefined) {
      return "is adding a reaction…";
    }
    return args.action === "remove"
      ? fit("is removing a :", emoji, ": reaction…")
      : fit("is adding a :", emoji, ": reaction…");
  },
  read_canvas: fixed("is reading a canvas…"),
  read_conversation_history: fixed("is reading Slack history…"),
  read_file: withArg("path", "is reading a file…", "is reading ", "…", fileName),
  resume_scheduled_task: fixed("is resuming a scheduled task…"),
  search_slack: withArg("query", "is searching Slack…", 'is searching Slack for "', '"…'),
  search_tools: withArg("query", "is looking for a tool…", 'is looking for a tool: "', '"…'),
  search_web: withArg("query", "is searching the web…", 'is searching the web for "', '"…'),
  skill: withArg("name", "is loading a skill…", "is loading the ", " skill…"),
  skill_search: withArg("query", "is looking for a skill…", 'is looking for a skill: "', '"…'),
  summarize_thread: withArg("instructions", "is summarizing the thread…", "is summarizing: ", "…"),
  upload_file: fixed("is uploading a file…"),
  view_image: withArg("path", "is looking at an image…", "is looking at ", "…", fileName),
  wait: withArg("reason", "is waiting…", "is waiting: ", "…"),
  write_file: withArg("path", "is writing a file…", "is writing ", "…", fileName),
} satisfies Record<string, (args: Args) => string>;

export const statuses = new Map(Object.entries(statusByTool));
