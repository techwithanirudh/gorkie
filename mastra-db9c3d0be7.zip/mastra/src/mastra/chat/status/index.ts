import { defaultTypingStatus } from "@mastra/core/channels";
import type { TypingStatusFn } from "@mastra/core/channels";
import { argsSchema, truncate } from "./format";
import { statuses } from "./statuses";

const label = (value: string): string => {
  const words = value
    .replaceAll(/(?<lower>[a-z0-9])(?<upper>[A-Z])/gu, "$1 $2")
    .replaceAll(/[_-]+/gu, " ")
    .trim()
    .split(/\s+/u)
    .filter(Boolean);

  return words.length === 0
    ? value
    : words
        .map((word) => `${word.charAt(0).toUpperCase()}${word.slice(1).toLowerCase()}`)
        .join(" ");
};

const delegationAgentIds = new Set(["research", "explore"]);

const delegatedChildTool = (
  rest: string,
): { agentId: string; childToolName: string } | undefined => {
  for (const agentId of delegationAgentIds) {
    const prefix = `${agentId}_`;
    if (rest.startsWith(prefix)) {
      return { agentId, childToolName: rest.slice(prefix.length) };
    }
  }
  return undefined;
};

export const status: TypingStatusFn = (chunk, context) => {
  if (chunk.type === "tool-call-approval") {
    return truncate(`is asking about ${label(chunk.payload.toolName)}…`);
  }
  if (chunk.type !== "tool-call") {
    const fallback = defaultTypingStatus(chunk, context);
    return fallback === false || fallback === null || fallback === undefined
      ? fallback
      : truncate(fallback);
  }

  const { toolName } = chunk.payload;

  if (toolName.startsWith("agent-")) {
    const rest = toolName.slice(6);
    const delegated = delegatedChildTool(rest);
    if (delegated) {
      return truncate(
        `is using ${delegated.agentId}: ${label(delegated.childToolName).toLowerCase()}…`,
      );
    }
    return truncate(`is spawning a ${label(rest).toLowerCase()} agent…`);
  }

  const args = argsSchema.safeParse(chunk.payload.args).data ?? {};
  const known = statuses.get(toolName)?.(args);
  if (known !== undefined && known !== "") {
    return truncate(known);
  }

  return truncate(`is using ${label(toolName).toLowerCase()}…`);
};
