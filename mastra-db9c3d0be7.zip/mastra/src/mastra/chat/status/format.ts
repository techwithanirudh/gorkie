import { z } from "zod";

export const argsSchema = z.record(z.string(), z.unknown());

export type Args = z.infer<typeof argsSchema>;

const nonEmptyString = z.string().min(1);

const maxSlackStatusLength = 50;

export const fit = (
  prefix: string,
  content: string,
  suffix: string,
  max = maxSlackStatusLength,
): string => {
  const budget = max - prefix.length - suffix.length;
  const flat = content.replaceAll(/\s+/gu, " ").trim();
  const clipped = flat.length > budget ? flat.slice(0, budget) : flat;
  return prefix + clipped + suffix;
};

export const truncate = (text: string, max = maxSlackStatusLength): string =>
  text.length > max ? text.slice(0, max) : text;

export const str = (args: Args, key: string): string | undefined =>
  nonEmptyString.safeParse(args[key]).data;

export const fileName = (path: string): string =>
  path.split("/").findLast((segment) => segment !== "") ?? path;
