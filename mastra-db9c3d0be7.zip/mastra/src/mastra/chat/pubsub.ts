import { RedisStreamsPubSub } from "@mastra/redis-streams";
import { env } from "@/env";
import { logger } from "../lib/logger";

export const pubsub =
  env.REDIS_URL === undefined
    ? undefined
    : new RedisStreamsPubSub({
        blockMs: 10_000,
        keyPrefix: "archy:pubsub",
        streamIdleTtlMs: 86_400_000,
        logger: {
          debug: (...args) => {
            logger.debug("[pubsub] redis streams", { args });
          },
          warn: (...args) => {
            logger.warn("[pubsub] redis streams", { args });
          },
        },
        url: env.REDIS_URL,
      });
