import { RedisStateAdapter } from "@chat-adapter/state-redis";
import type { ThreadStateStorage } from "@mastra/core/storage";
import type { Thread } from "chat";
import { z } from "zod";
import { env } from "@/env";
import { libsqlStore } from "../db/client";
import { logger } from "../lib/logger";
import { chatLogger } from "../lib/logger/chat";
import type { ThreadState } from "../types";

const STATE_TYPE = "archy:chat";

export const chatState =
  env.REDIS_URL === undefined
    ? undefined
    : new RedisStateAdapter({
        keyPrefix: "archy:chat",
        logger: chatLogger.child("redis"),
        url: env.REDIS_URL,
      });

let resolved: Promise<ThreadStateStorage | undefined> | undefined;

const threadStateStore = async (): Promise<ThreadStateStorage | undefined> => {
  resolved ??= (async () => {
    const store = await libsqlStore.getStore("threadState");
    if (store === undefined) {
      logger.error("[chat] thread state store is unavailable; state will not persist");
    }
    return store;
  })();
  return await resolved;
};

const threadStateSchema = z.looseObject({
  lastSeenMessage: z.string().optional(),
  respondOnThreadMessages: z.boolean().optional(),
});

export const threadState = async (thread: Thread): Promise<ThreadState | null> => {
  try {
    const store = await threadStateStore();
    const stored = await store?.getState({ threadId: thread.id, type: STATE_TYPE });
    return threadStateSchema.safeParse(stored).data ?? null;
  } catch (error) {
    logger.error("[chat] failed to read thread state", { error, threadId: thread.id });
    return null;
  }
};

export const setThreadState = async (thread: Thread, patch: ThreadState): Promise<void> => {
  try {
    const store = await threadStateStore();
    if (!store) {
      return;
    }
    const current = await threadState(thread);
    await store.setState({
      threadId: thread.id,
      type: STATE_TYPE,
      value: { ...current, ...patch },
    });
  } catch (error) {
    logger.error("[chat] failed to save thread state", { error, threadId: thread.id });
  }
};
