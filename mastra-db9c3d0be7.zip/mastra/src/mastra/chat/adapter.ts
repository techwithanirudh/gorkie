import { SlackAdapter } from "@chat-adapter/slack";
import type { WebhookOptions } from "chat";

const mentionPattern = /<@(?<userId>[A-Z0-9_]+)(?:\|(?<label>[^<>]+))?>/gu;

export class SlackAgentAdapter extends SlackAdapter {
  override async handleWebhook(request: Request, options?: WebhookOptions): Promise<Response> {
    const retryNum = request.headers.get("x-slack-retry-num");
    if (
      request.headers.get("x-slack-retry-reason") === "http_timeout" &&
      request.headers.get("x-slack-socket-token") === null
    ) {
      this.logger.debug("Dropping Slack event retry after a timeout", { retryNum });
      return new Response("ok", { status: 200 });
    }
    return await super.handleWebhook(request, options);
  }

  async postBlocks({
    blocks,
    text,
    threadId,
  }: {
    blocks: unknown[];
    text: string;
    threadId: string;
  }): Promise<void> {
    const { channel, threadTs } = this.decodeThreadId(threadId);
    const chatApi = this._client.chat;
    const { postMessage } = chatApi;
    await postMessage.call(
      chatApi,
      await this.withToken({ blocks, channel, text, thread_ts: threadTs }),
    );
  }

  protected override async resolveInlineMentions(text: string) {
    const mentionNames = new Map<string, string>();
    const missingIds = new Set<string>();

    for (const mention of text.matchAll(mentionPattern)) {
      const [, userId, label] = mention;
      if (userId === undefined || userId === "" || mentionNames.has(userId)) {
        continue;
      }
      if (label !== undefined && label !== "") {
        mentionNames.set(userId, label);
      } else {
        missingIds.add(userId);
      }
    }

    await Promise.all(
      [...missingIds].map(async (userId) => {
        const user = await this.lookupUser(userId);
        mentionNames.set(userId, user?.displayName ?? userId);
      }),
    );

    if (mentionNames.size === 0) {
      return text;
    }

    return text.replace(mentionPattern, (token, userId: string) => {
      const name = mentionNames.get(userId);
      return name === undefined ? token : `@${name} (${userId})`;
    });
  }
}
