import type { Mastra } from "@mastra/core/mastra";

let instance: Mastra | undefined;

export const setMastra = (mastra: Mastra): void => {
  instance = mastra;
};

export const getMastra = (): Mastra => {
  if (!instance) {
    throw new Error("Mastra is not initialized yet.");
  }
  return instance;
};
