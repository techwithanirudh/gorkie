import { cardToSlackBlocks } from "@chat-adapter/slack/blocks";
import { Card, Section } from "chat";

export const content = {
  home: {
    blocks: cardToSlackBlocks(
      Card({
        title: "I'm Archy",
        children: [
          Section([
            {
              type: "text",
              content:
                "I answer questions using context that is scattered across PostHog, Linear and this Slack workspace, and I link where each answer came from.\n\nMention me in any channel or thread, or message me here. I can file Linear issues too, but I will ask you to approve anything that changes something.",
            },
          ]),
        ],
      }),
    ),
    type: "home",
  },
  starters: [
    {
      title: "Explain an error",
      message:
        "What are the top errors in production over the last 24 hours, and how many users did each one hit? Link the PostHog issue for the worst one.",
    },
    {
      title: "Catch up on a ticket",
      message:
        "What is the current state of ENG-5412, what is blocking it, and who last touched it? Link the issue.",
    },
    {
      title: "Find what we decided",
      message:
        "Search Slack for what we decided about hosting the internal agent, and give me the permalinks to the messages that settled it.",
    },
    {
      title: "Check a deploy",
      message:
        "Did the latest production deploy succeed? If it failed, show me the build error and link the deployment.",
    },
  ],
};
