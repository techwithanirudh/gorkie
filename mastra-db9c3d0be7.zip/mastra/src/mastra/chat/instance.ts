import type { Chat } from "chat";

let instance: Chat | undefined;

export const setChat = (bot: Chat): void => {
  instance = bot;
};

export const chat = (): Chat => {
  if (!instance) {
    throw new Error("Chat SDK is not initialized yet.");
  }
  return instance;
};
