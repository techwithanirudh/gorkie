import type { Message, Thread } from "chat";
import { parseMarkdown, stringifyMarkdown } from "chat";
import { slack } from "./client";
import { isComment } from "./message";
import { setThreadState, threadState } from "./state";

const MAX_MESSAGES = 10;

const nameSelfMentions = (text: string): string => {
  const { botUserId } = slack;
  if (botUserId === undefined || botUserId === "") {
    return text;
  }
  return text.replaceAll(
    new RegExp(`<@${botUserId}(?:\\|[^<>]*)?>|@${botUserId}\\b`, "gu"),
    "@archy",
  );
};
const MAX_SCANNED = 30;

const attachmentSummary = (attachments: Message["attachments"]): string => {
  if (attachments.length === 0) {
    return "";
  }
  const files = attachments
    .map((file) => {
      const url = file.url ?? file.fetchMetadata?.url;
      const id = url?.match(/\bF[A-Z0-9]{6,}\b/u)?.[0];
      return [file.name ?? file.type, id ?? url].filter(Boolean).join(" ");
    })
    .join(", ");
  return ` [${attachments.length} attachment${attachments.length === 1 ? "" : "s"}: ${files}]`;
};

const historyLine = (thread: Thread, previous: Message): string => {
  const mention = thread.mentionUser(previous.author.userId);
  const author = previous.author.fullName || previous.author.userName;
  const bot = previous.author.isBot === true ? " (bot)" : "";
  const text = nameSelfMentions(stringifyMarkdown(previous.formatted).trim());
  return `[${author} (${mention})${bot}] (msg:${previous.id}): ${text}${attachmentSummary(previous.attachments)}`;
};

const unseenMessages = async ({
  lastSeenMessage,
  message,
  thread,
}: {
  lastSeenMessage: string | undefined;
  message: Message;
  thread: Thread;
}): Promise<{ comments: number; lines: string[] }> => {
  const lines: string[] = [];
  let scanned = 0;
  let comments = 0;
  for await (const previous of thread.messages) {
    if (previous.id === lastSeenMessage || scanned >= MAX_SCANNED) {
      return { comments, lines };
    }
    scanned += 1;
    if (isComment(previous)) {
      comments += 1;
    } else if (previous.id !== message.id && !previous.author.isMe) {
      lines.push(historyLine(thread, previous));
    }
    if (lines.length >= MAX_MESSAGES) {
      return { comments, lines };
    }
  }
  return { comments, lines };
};

export const withHistory = async ({
  message,
  thread,
}: {
  message: Message;
  thread: Thread;
}): Promise<Message> => {
  if (thread.isDM) {
    return message;
  }

  const state = await threadState(thread);
  const { comments, lines } = await unseenMessages({
    lastSeenMessage: state?.lastSeenMessage,
    message,
    thread,
  });

  await setThreadState(thread, { lastSeenMessage: message.id });
  if (lines.length === 0 && comments === 0) {
    return message;
  }

  const text = [
    ...(lines.length > 0
      ? [
          "[Recent messages in this thread, oldest first, that you have not seen yet]",
          ...lines.toReversed(),
        ]
      : []),
    ...(comments > 0
      ? [
          `[${comments} ${comments === 1 ? "message" : "messages"} starting with ## were left out. They are side comments nobody addressed to you, so act on them only if asked. Read them with read_conversation_history and includeComments if you need them.]`,
        ]
      : []),
    "",
    message.text,
  ].join("\n");
  message.text = text;
  message.formatted = parseMarkdown(text);
  return message;
};
