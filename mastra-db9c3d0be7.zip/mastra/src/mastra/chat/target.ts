import { z } from "zod";
import { parseSlackId, rawId } from "../lib/ids";
import { slack } from "./client";

export const targetSchema = z.object({
  id: z
    .string()
    .min(1)
    .describe(
      "Chat SDK id: thread (slack:<conversation-id>:ts), conversation (slack:C..., slack:D..., or slack:G...), or a user id.",
    ),
  type: z.enum(["thread", "channel", "user"]).describe("Target kind."),
});

export type Target = z.infer<typeof targetSchema>;

export const slackDestination = async (
  target: Target,
): Promise<{ channel: string; threadTs?: string }> => {
  if (target.type === "channel") {
    return { channel: rawId(target.id) };
  }
  if (target.type === "thread") {
    const { channel, ts } = parseSlackId(target.id);
    if (channel === undefined || channel === "") {
      throw new Error(`${target.id} is not a Slack thread id.`);
    }
    return { channel, threadTs: ts };
  }
  const dm = await slack.webClient.conversations.open({ users: rawId(target.id) });
  if (dm.channel?.id === undefined || dm.channel.id === "") {
    throw new Error(`Slack did not open a DM with ${target.id}.`);
  }
  return { channel: dm.channel.id };
};
