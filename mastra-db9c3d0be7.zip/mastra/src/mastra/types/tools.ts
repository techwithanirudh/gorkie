export type MastraStopCondition = (options: {
  steps: {
    finishReason?: string;
    toolCalls?: unknown[];
    toolResults?: { toolName?: string }[];
  }[];
}) => boolean;
