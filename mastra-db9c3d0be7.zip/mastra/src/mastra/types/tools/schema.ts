import { z } from "zod";

export const input = <const Fields extends Parameters<typeof z.strictObject>[0]>(fields: Fields) =>
  z.strictObject(fields);

export const output = <const Fields extends Parameters<typeof z.strictObject>[0]>(fields: Fields) =>
  z.strictObject(fields);

export const optionalCursor = z.string().min(1).optional();
