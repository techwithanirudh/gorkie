import { z } from "zod";

export const slackMessageSchema = z.strictObject({
  attachments: z.array(
    z.strictObject({
      type: z.string(),
      name: z.string().optional(),
      mimeType: z.string().optional(),
      url: z.string().optional(),
    }),
  ),
  author: z.strictObject({
    userId: z.string(),
    userName: z.string().optional(),
    fullName: z.string().optional(),
    isBot: z.union([z.boolean(), z.literal("unknown")]),
    isMe: z.boolean(),
  }),
  dateSent: z.string(),
  edited: z.boolean(),
  id: z.string(),
  isMention: z.boolean().optional(),
  text: z.string(),
  threadId: z.string().optional(),
});
