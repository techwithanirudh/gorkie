export interface SlackMember {
  displayName?: string;
  email?: string;
  id: string;
  realName?: string;
  timezone?: string;
  title?: string;
}

export interface LinearMember {
  active: boolean;
  displayName?: string;
  email?: string;
  id: string;
  name?: string;
}

interface LinearIdentity {
  displayName: string;
  id: string;
}

interface Person {
  email?: string;
  handle?: string;
  linear?: LinearIdentity;
  name: string;
  slackId: string;
  timezone?: string;
  title?: string;
}

interface LinearOnlyPerson {
  displayName: string;
  id: string;
  name: string;
}

export interface Directory {
  linearOnly: LinearOnlyPerson[];
  people: Person[];
}

const normalizeEmail = (email: string | undefined): string | undefined => {
  const trimmed = email?.trim().toLowerCase();
  return trimmed === undefined || trimmed.length === 0 ? undefined : trimmed;
};

const linearIdentity = (member: LinearMember): LinearOnlyPerson => {
  const displayName = member.displayName ?? member.name ?? member.id;
  return { displayName, id: member.id, name: member.name ?? displayName };
};

const byName = (a: { name: string }, b: { name: string }): number =>
  a.name < b.name ? -1 : a.name > b.name ? 1 : 0;

// Linear's synthetic integration and OAuth-app users are marked only by a `.linear.app` email domain.
export const joinDirectory = ({
  linearMembers,
  slackMembers,
}: {
  linearMembers: LinearMember[];
  slackMembers: SlackMember[];
}): Directory => {
  const real = linearMembers.flatMap((member) => {
    const email = normalizeEmail(member.email);
    return member.active && email !== undefined && !/\.linear\.app$/iu.test(email)
      ? [{ email, member }]
      : [];
  });
  const byEmail = new Map(real.map(({ email, member }) => [email, member]));

  const claimed = new Set<string>();
  const people: Person[] = slackMembers.map((member) => {
    const email = normalizeEmail(member.email);
    const match = email === undefined ? undefined : byEmail.get(email);
    if (match) {
      claimed.add(match.id);
    }
    return {
      email,
      handle: member.displayName,
      linear: match ? { displayName: linearIdentity(match).displayName, id: match.id } : undefined,
      name: member.realName ?? member.displayName ?? member.id,
      slackId: member.id,
      timezone: member.timezone,
      title: member.title,
    };
  });

  return {
    linearOnly: real
      .flatMap(({ member }) => (claimed.has(member.id) ? [] : [linearIdentity(member)]))
      .toSorted(byName),
    people: people.toSorted(byName),
  };
};
