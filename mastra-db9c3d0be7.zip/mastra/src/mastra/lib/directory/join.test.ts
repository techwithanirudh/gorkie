import { describe, expect, it } from "vitest";
import { joinDirectory, type LinearMember, type SlackMember } from "./join";

function slack(member: Partial<SlackMember> & { id: string }): SlackMember {
  return member;
}

function linear(member: Partial<LinearMember> & { id: string }): LinearMember {
  return { active: true, ...member };
}

describe("joinDirectory", () => {
  it("links a Slack person to the Linear user with the same email", () => {
    const { people } = joinDirectory({
      linearMembers: [linear({ displayName: "joan", email: "j@quiver.ai", id: "lin-1" })],
      slackMembers: [
        slack({
          displayName: "joan",
          email: "j@quiver.ai",
          id: "U1",
          realName: "Joan Rodriguez",
          timezone: "Europe/Amsterdam",
          title: "CEO",
        }),
      ],
    });

    expect(people).toEqual([
      {
        email: "j@quiver.ai",
        handle: "joan",
        linear: { displayName: "joan", id: "lin-1" },
        name: "Joan Rodriguez",
        slackId: "U1",
        timezone: "Europe/Amsterdam",
        title: "CEO",
      },
    ]);
  });

  it("matches emails that differ only by case or surrounding space", () => {
    const { people } = joinDirectory({
      linearMembers: [linear({ email: "  Sameer@Quiver.AI ", id: "lin-2", name: "Sameer" })],
      slackMembers: [slack({ email: "sameer@quiver.ai", id: "U2", realName: "Sameer" })],
    });

    expect(people[0]?.linear?.id).toBe("lin-2");
    expect(people[0]?.email).toBe("sameer@quiver.ai");
  });

  it.each([
    ["integration", "35aee299@integration.linear.app"],
    ["oauth app", "a4bc02c9@oauthapp.linear.app"],
    ["linear itself", "linear-f146d0e1@linear.linear.app"],
  ])("drops the synthetic Linear account for %s", (_label, email) => {
    const { linearOnly, people } = joinDirectory({
      linearMembers: [linear({ email, id: "bot", name: "Linear Asks" })],
      slackMembers: [slack({ email, id: "U3", realName: "Impostor" })],
    });

    expect(linearOnly).toEqual([]);
    expect(people[0]?.linear).toBeUndefined();
  });

  it("drops deactivated Linear users and those with no email", () => {
    const { linearOnly } = joinDirectory({
      linearMembers: [
        linear({ active: false, email: "gone@quiver.ai", id: "lin-3", name: "Gone" }),
        linear({ id: "lin-4", name: "No Email" }),
        linear({ email: "   ", id: "lin-5", name: "Blank Email" }),
      ],
      slackMembers: [],
    });

    expect(linearOnly).toEqual([]);
  });

  it("keeps a Slack person who has no Linear counterpart", () => {
    const { people } = joinDirectory({
      linearMembers: [linear({ email: "someone@quiver.ai", id: "lin-6" })],
      slackMembers: [
        slack({ email: "yli@a16z.com", id: "U4", realName: "Yoko Li" }),
        slack({ id: "U5", realName: "No Email At All" }),
      ],
    });

    expect(people.map((person) => [person.name, person.linear])).toEqual([
      ["No Email At All", undefined],
      ["Yoko Li", undefined],
    ]);
  });

  it("reports real Linear users who are not in Slack", () => {
    const { linearOnly } = joinDirectory({
      linearMembers: [
        linear({ displayName: "contractor", email: "c@vendor.com", id: "lin-7", name: "Contractor" }),
      ],
      slackMembers: [],
    });

    expect(linearOnly).toEqual([
      { displayName: "contractor", id: "lin-7", name: "Contractor" },
    ]);
  });

  it("does not list a matched Linear user as Linear-only", () => {
    const { linearOnly } = joinDirectory({
      linearMembers: [linear({ email: "a@quiver.ai", id: "lin-8", name: "A" })],
      slackMembers: [slack({ email: "a@quiver.ai", id: "U6", realName: "A" })],
    });

    expect(linearOnly).toEqual([]);
  });

  it("falls back through the available names", () => {
    const { linearOnly, people } = joinDirectory({
      linearMembers: [
        linear({ email: "d@quiver.ai", id: "lin-11", name: "Named Only" }),
        linear({ email: "e@quiver.ai", id: "lin-12" }),
      ],
      slackMembers: [
        slack({ displayName: "handle-only", id: "U7" }),
        slack({ id: "U8" }),
      ],
    });

    expect(people.map((person) => person.name)).toEqual(["U8", "handle-only"]);
    expect(linearOnly).toEqual([
      { displayName: "Named Only", id: "lin-11", name: "Named Only" },
      { displayName: "lin-12", id: "lin-12", name: "lin-12" },
    ]);
  });

  it("sorts by name and keeps ties stable so the rendered block is byte-identical", () => {
    const { people } = joinDirectory({
      linearMembers: [],
      slackMembers: [
        slack({ id: "U-c", realName: "Zoe" }),
        slack({ id: "U-a", realName: "Alex" }),
        slack({ id: "U-b", realName: "Alex" }),
      ],
    });

    expect(people.map((person) => [person.name, person.slackId])).toEqual([
      ["Alex", "U-a"],
      ["Alex", "U-b"],
      ["Zoe", "U-c"],
    ]);
  });
});
