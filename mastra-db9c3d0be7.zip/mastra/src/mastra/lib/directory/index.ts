import { logger } from "../logger";
import type { Directory } from "./join";
import { joinDirectory } from "./join";
import { listLinearMembers } from "./clients/linear";
import { listSlackMembers } from "./clients/slack";

export type { Directory } from "./join";

const TTL_MS = 6 * 60 * 60 * 1000;

interface Snapshot {
  directory: Directory;
  refreshedAt: number;
}

let snapshot: Snapshot | undefined;
let inFlight: Promise<Snapshot> | null = null;

const refresh = async (): Promise<Snapshot> => {
  const [slackMembers, linearMembers] = await Promise.all([
    listSlackMembers(),
    listLinearMembers(),
  ]);
  const directory = joinDirectory({ linearMembers, slackMembers });
  logger.info("[directory] refreshed");
  return { directory, refreshedAt: Date.now() };
};

const startRefresh = async (): Promise<Snapshot> => {
  inFlight ??= (async () => {
    try {
      const next = await refresh();
      snapshot = next;
      return next;
    } finally {
      inFlight = null;
    }
  })();
  return await inFlight;
};

const refreshInBackground = async (): Promise<void> => {
  try {
    await startRefresh();
  } catch (error) {
    logger.debug("[directory] background refresh failed, keeping the stale copy", { error });
  }
};

export const resolveDirectory = async (): Promise<Directory | undefined> => {
  const current = snapshot;
  if (current) {
    if (Date.now() - current.refreshedAt > TTL_MS) {
      void refreshInBackground();
    }
    return current.directory;
  }

  try {
    const next = await startRefresh();
    return next.directory;
  } catch (error) {
    logger.warn("[directory] could not build the workspace directory", { error });
    return undefined;
  }
};
