import { LinearClient } from "@linear/sdk";
import { env } from "@/env";
import type { LinearMember } from "../join";

const linearClient = new LinearClient({ apiKey: env.LINEAR_API_KEY });

const MAX_PAGES = 10;

type UserConnection = Awaited<ReturnType<typeof linearClient.users>>;

const fetchAllPages = async (
  connection: UserConnection,
  fetched: number,
): Promise<UserConnection> => {
  if (fetched === MAX_PAGES - 1 || !connection.pageInfo.hasNextPage) {
    return connection;
  }
  return await fetchAllPages(await connection.fetchNext(), fetched + 1);
};

export const listLinearMembers = async (): Promise<LinearMember[]> => {
  const connection = await fetchAllPages(await linearClient.users({ first: 250 }), 0);
  return connection.nodes.map((user) => ({
    active: user.active,
    displayName: user.displayName,
    email: user.email,
    id: user.id,
    name: user.name,
  }));
};
