import { z } from "zod";
import { slack } from "../../../chat/client";
import type { SlackMember } from "../join";

const slackListSchema = z.looseObject({
  members: z
    .array(
      z.looseObject({
        deleted: z.boolean().optional(),
        id: z.string(),
        is_bot: z.boolean().optional(),
        profile: z
          .looseObject({
            display_name: z.string().optional(),
            email: z.string().optional(),
            real_name: z.string().optional(),
            title: z.string().optional(),
          })
          .optional(),
        tz: z.string().optional(),
      }),
    )
    .optional(),
  response_metadata: z.looseObject({ next_cursor: z.string().optional() }).optional(),
});

const text = (value: string | undefined): string | undefined =>
  value === undefined || value.length === 0 ? undefined : value;

const MAX_PAGES = 20;

const listSlackMemberPages = async (
  page: number,
  cursor: string | undefined,
  members: SlackMember[],
): Promise<SlackMember[]> => {
  const response = slackListSchema.parse(await slack.webClient.users.list({ cursor, limit: 200 }));
  for (const member of response.members ?? []) {
    // Slackbot is a real member row with no profile worth carrying, and it
    // is not flagged `is_bot`.
    if (member.deleted === true || member.is_bot === true || member.id === "USLACKBOT") {
      continue;
    }
    members.push({
      displayName: text(member.profile?.display_name),
      email: text(member.profile?.email),
      id: member.id,
      realName: text(member.profile?.real_name),
      timezone: text(member.tz),
      title: text(member.profile?.title),
    });
  }
  const next = text(response.response_metadata?.next_cursor);
  if (next === undefined || page + 1 >= MAX_PAGES) {
    return members;
  }
  return await listSlackMemberPages(page + 1, next, members);
};

export const listSlackMembers = async (): Promise<SlackMember[]> =>
  await listSlackMemberPages(0, undefined, []);
