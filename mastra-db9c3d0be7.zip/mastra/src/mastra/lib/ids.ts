// The Chat SDK Slack adapter spells a conversation as `slack:<channel>` and a
// thread as `slack:<channel>:<ts>` (@chat-adapter/slack encodeThreadId).

const PREFIX = "slack:";
const PERMALINK = /archives\/(?<channel>[A-Z0-9]+)\/p(?<tsWhole>\d{10})(?<tsFrac>\d{6})/u;

interface SlackId {
  channel?: string;
  ts?: string;
}

const timestamp = (value: string | undefined): string | undefined => {
  if (value === undefined || value === "") {
    return undefined;
  }
  const digits = value.replace(".", "");
  return /^\d{16}$/u.test(digits) ? `${digits.slice(0, 10)}.${digits.slice(10)}` : undefined;
};

export const rawId = (id: string): string => {
  const bare = id.startsWith(PREFIX) ? id.slice(PREFIX.length) : id;
  const [head] = bare.split(":");
  return head === undefined || head === "" ? id : head;
};

export const chatChannelId = (id: string): string => `${PREFIX}${rawId(id)}`;

const nonEmpty = (value: string | undefined): value is string =>
  value !== undefined && value !== "";

export const threadIdOf = ({ channel, ts }: SlackId): string | undefined =>
  nonEmpty(channel) && nonEmpty(ts) ? `${PREFIX}${rawId(channel)}:${ts}` : undefined;

export const parseSlackId = (
  input: string | undefined,
  fallback?: { channel?: string },
): SlackId => {
  const channel =
    fallback?.channel !== undefined && fallback.channel !== ""
      ? rawId(fallback.channel)
      : undefined;
  if (input === undefined || input === "") {
    return { channel };
  }

  const permalink = PERMALINK.exec(input);
  if (permalink?.[1] !== undefined && permalink[1] !== "") {
    return { channel: permalink[1], ts: `${permalink[2]}.${permalink[3]}` };
  }

  if (input.startsWith(PREFIX)) {
    const [encoded, ts] = input.slice(PREFIX.length).split(":");
    return {
      channel: encoded === undefined || encoded === "" ? channel : encoded,
      ts: timestamp(ts),
    };
  }

  return { channel, ts: timestamp(input) };
};
