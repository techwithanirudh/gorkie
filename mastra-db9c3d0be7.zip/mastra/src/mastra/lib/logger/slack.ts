import { LogLevel } from "@slack/web-api";
import type { Logger as SlackLogger } from "@slack/web-api";
import { logger } from ".";
import { logMeta } from "./meta";

const TAG = "[slack:web-api]";

// Slack's error when the bot is already a member, the state we want. The
// WebClient logs it at warn.
export const ALREADY_IN_CHANNEL = "already_in_channel";

export const slackWebLogger: SlackLogger = {
  debug: (...args) => {
    logger.debug(TAG, logMeta(args));
  },
  info: (...args) => {
    logger.debug(TAG, logMeta(args));
  },
  warn: (...args) => {
    if (args.includes(ALREADY_IN_CHANNEL)) {
      logger.debug(TAG, logMeta(args));
    } else {
      logger.warn(TAG, logMeta(args));
    }
  },
  error: (...args) => {
    logger.error(TAG, logMeta(args));
  },
  setLevel: (): void => undefined,
  getLevel: () => LogLevel.DEBUG,
  setName: (): void => undefined,
};
