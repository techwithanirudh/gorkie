import type { logger } from ".";

type LogMeta = NonNullable<Parameters<typeof logger.info>[1]>;

const isLogMeta = (value: unknown): value is LogMeta =>
  typeof value === "object" && value !== null && !Array.isArray(value);

export const logMeta = (args: unknown[]): LogMeta => {
  const [first] = args;
  if (args.length === 1 && isLogMeta(first)) {
    return first;
  }
  return args.length > 0 ? { args } : {};
};
