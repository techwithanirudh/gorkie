import { PinoLogger } from "@mastra/loggers";

const SENSITIVE_FIELDS = [
  "requestBodyValues",
  "requestObject",
  "responseHeaders",
  "responseBody",
  "request",
  "client_secret",
  "refresh_token",
  "clientSecret",
  "refreshToken",
];
const ROOTS = ["", "*.", "error.", "err."];
const MAX_CAUSE_DEPTH = 4;

const redactPaths = (): string[] => {
  const paths: string[] = [];
  for (const root of ROOTS) {
    for (let depth = 0; depth <= MAX_CAUSE_DEPTH; depth += 1) {
      const prefix = root + "cause.".repeat(depth);
      for (const field of SENSITIVE_FIELDS) {
        paths.push(prefix + field);
      }
    }
  }
  return paths;
};

export const logger = new PinoLogger({
  level: "info",
  name: "orchestrator",
  redact: {
    censor: "[redacted]",
    paths: redactPaths(),
  },
});
