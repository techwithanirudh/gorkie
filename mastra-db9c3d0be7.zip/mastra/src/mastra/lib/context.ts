import type { RequestContext } from "@mastra/core/request-context";
import { z } from "zod";
import type { ChannelContext } from "../types";
import { logger } from "./logger";

export const channelSchema = z.looseObject({
  botUserId: z.string().optional(),
  channelId: z.string().optional(),
  isDM: z.boolean().optional(),
  messageId: z.string().optional(),
  threadId: z.string().optional(),
  userId: z.string().optional(),
  userName: z.string().optional(),
});

const channelJson = z.string().transform((text, ctx) => {
  try {
    const value: unknown = JSON.parse(text);
    return value;
  } catch {
    ctx.addIssue({ code: "custom", message: "Channel context is not valid JSON." });
    return z.NEVER;
  }
});

export const channelContext = (requestContext?: RequestContext): ChannelContext => {
  const raw = requestContext?.get("channel");
  if (raw === undefined || raw === null || raw === "") {
    return {};
  }
  const text = z.string().safeParse(raw);
  const decoded = text.success ? channelJson.safeParse(text.data) : undefined;
  if (decoded?.success === false) {
    return {};
  }
  const parsed = channelSchema.safeParse(decoded === undefined ? raw : decoded.data);
  if (!parsed.success) {
    logger.warn("[context] channel context did not match its shape", {
      issues: parsed.error.issues,
    });
    return {};
  }
  return parsed.data;
};
