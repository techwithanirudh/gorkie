import type { MastraStopCondition } from "../types";

export const toolCall =
  (toolName: string): MastraStopCondition =>
  ({ steps }) =>
    steps.at(-1)?.toolResults?.some((toolResult) => toolResult.toolName === toolName) ?? false;

export const stepCountIs =
  (stepCount: number): MastraStopCondition =>
  ({ steps }) =>
    steps.length === stepCount;
