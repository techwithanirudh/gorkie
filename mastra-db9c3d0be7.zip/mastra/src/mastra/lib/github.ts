import { createAppAuth } from "@octokit/auth-app";
import { env } from "@/env";
import { logger } from "./logger";

export const repository = { name: "quiverai-monorepo", owner: "quiverai" } as const;

const SANDBOX_PERMISSIONS = {
  actions: "read",
  checks: "read",
  contents: "read",
  issues: "read",
  pull_requests: "read",
  statuses: "read",
} as const satisfies Record<string, "read">;

const MIN_SANDBOX_LIFETIME_MS = 20 * 60_000;
export const TOP_UP_BELOW_MS = MIN_SANDBOX_LIFETIME_MS - 5 * 60_000;

const auth = env.GITHUB_APP && createAppAuth(env.GITHUB_APP);

export const mintSandboxToken = async (): Promise<{ expiresAt: number; token: string } | null> => {
  if (auth === null) {
    return null;
  }
  const options = {
    permissions: SANDBOX_PERMISSIONS,
    repositoryNames: [repository.name],
    type: "installation" as const,
  };
  try {
    let minted = await auth(options);
    if (Date.parse(minted.expiresAt) - Date.now() < MIN_SANDBOX_LIFETIME_MS) {
      minted = await auth({ ...options, refresh: true });
    }
    return { expiresAt: Date.parse(minted.expiresAt), token: minted.token };
  } catch (error) {
    if (error instanceof Error && "status" in error && error.status === 422) {
      logger.warn(
        `[github] the App installation has not approved every permission in ${Object.keys(SANDBOX_PERMISSIONS).join(", ")}, so the sandbox runs without GitHub until an org owner approves them`,
      );
      return null;
    }
    throw error;
  }
};

export const mintCloneToken = async (): Promise<string | undefined> => {
  if (auth === null) {
    return undefined;
  }

  const { token } = await auth({
    permissions: { contents: "read" },
    repositoryNames: [repository.name],
    type: "installation",
  });
  return token;
};
