import {
  isBadRequestError,
  PrefillErrorHandler,
  StreamErrorRetryProcessor,
} from "@mastra/core/processors";
import { z } from "zod";

const messageOf = (error: unknown): string => {
  if (typeof error === "string") {
    return error;
  }
  if (error instanceof Error) {
    return error.message;
  }
  return "";
};

const terminalPattern =
  /is not supported|unknown model|model[_ ]not[_ ]found|insufficient credits|no endpoints found/iu;

const isTerminalModelError = (error: unknown): boolean => terminalPattern.test(messageOf(error));

const econnresetMaxRetries = 2;
const econnresetRetryInitialDelayMs = 1000;
const econnresetRetryMaxDelayMs = 30_000;
const econnresetMessagePattern = /econnreset|socket hang up/iu;

const errorWithCode = z.looseObject({ code: z.string() });

const isEconnresetError = (error: unknown): boolean => {
  const coded = errorWithCode.safeParse(error);
  if (coded.success && coded.data.code.toUpperCase() === "ECONNRESET") {
    return true;
  }
  return econnresetMessagePattern.test(messageOf(error));
};

const rateLimitPattern = /temporarily rate-limited upstream|too many requests/iu;

const isRateLimitError = (error: unknown): boolean => rateLimitPattern.test(messageOf(error));

export const defaultErrorProcessors = () => [
  new StreamErrorRetryProcessor({
    delayMs: 3000,
    matchers: [
      { match: isTerminalModelError, maxRetries: 0 },
      { match: isBadRequestError, maxRetries: 0 },
      {
        match: isEconnresetError,
        maxRetries: econnresetMaxRetries,
        delayMs: ({ retryCount }) =>
          Math.min(econnresetRetryInitialDelayMs * 2 ** retryCount, econnresetRetryMaxDelayMs),
      },
      { match: isRateLimitError, maxRetries: 2, delayMs: 3000 },
    ],
    maxRetries: 2,
    retryUnknownErrors: true,
  }),
  new PrefillErrorHandler(),
];
