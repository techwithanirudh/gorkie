import { existsSync } from "node:fs";
import path from "node:path";
import type { RequestContext } from "@mastra/core/request-context";
import { LocalSkillSource, WORKSPACE_TOOLS, Workspace } from "@mastra/core/workspace";
import { E2BSandbox } from "@mastra/e2b";
import { sandbox as config } from "../config";
import { channelContext } from "../lib/context";
import { logger } from "../lib/logger";
import { E2BFilesystem } from "./filesystem";
import { createSandbox } from "./sandbox";
import {
  DELETE_FILE,
  EDIT_FILE,
  EXECUTE_COMMAND,
  FILE_STAT,
  GET_PROCESS_OUTPUT,
  GREP,
  KILL_PROCESS,
  LIST_FILES,
  READ_FILE,
  WRITE_FILE,
} from "./tool-names";

const reached = new WeakSet<RequestContext>();

export const usedSandbox = (requestContext: RequestContext): boolean => reached.has(requestContext);

const resolveE2BSandbox = async (
  target: Workspace,
  requestContext: RequestContext,
): Promise<E2BSandbox | undefined> => {
  const sandbox = await target.resolveSandbox({ requestContext });
  if (!(sandbox instanceof E2BSandbox)) {
    return undefined;
  }
  reached.add(requestContext);
  return sandbox;
};

// Mastra resolves workspace instructions before a thread is bound.
const sandboxKey = (requestContext: RequestContext): string =>
  channelContext(requestContext).threadId ?? "__unscoped__";

export { sandboxPath } from "./path";
export { workspaceToolNames } from "./tool-names";

export const workspace: Workspace = new Workspace({
  filesystem: async ({ requestContext }) => {
    const sandbox = await resolveE2BSandbox(workspace, requestContext);
    if (!sandbox) {
      throw new Error("No E2B sandbox available for filesystem.");
    }

    return new E2BFilesystem({
      sandbox,
      basePath: config.workdir,
    });
  },
  id: "main-workspace",
  name: "Workspace",
  sandbox: ({ requestContext }) => createSandbox(sandboxKey(requestContext)),
  sandboxCacheKey: ({ requestContext }) => sandboxKey(requestContext),
  skillSource: new LocalSkillSource({
    basePath:
      [
        path.resolve(process.cwd(), "workspace/skills"),
        path.resolve(import.meta.dirname, "../../workspace/skills"),
      ].find(existsSync) ?? path.resolve(process.cwd(), "workspace/skills"),
  }),
  skills: ["."],
  tools: {
    [WORKSPACE_TOOLS.FILESYSTEM.READ_FILE]: {
      name: READ_FILE,
      mediaTypes: ["application/pdf"],
    },
    [WORKSPACE_TOOLS.FILESYSTEM.WRITE_FILE]: {
      name: WRITE_FILE,
      requireReadBeforeWrite: true,
    },
    [WORKSPACE_TOOLS.FILESYSTEM.EDIT_FILE]: {
      name: EDIT_FILE,
      requireReadBeforeWrite: true,
    },
    [WORKSPACE_TOOLS.FILESYSTEM.LIST_FILES]: { name: LIST_FILES },
    [WORKSPACE_TOOLS.FILESYSTEM.DELETE]: { name: DELETE_FILE },
    [WORKSPACE_TOOLS.FILESYSTEM.FILE_STAT]: { name: FILE_STAT },
    [WORKSPACE_TOOLS.FILESYSTEM.MKDIR]: { enabled: false },
    [WORKSPACE_TOOLS.FILESYSTEM.GREP]: { name: GREP },
    [WORKSPACE_TOOLS.FILESYSTEM.AST_EDIT]: { enabled: false },
    [WORKSPACE_TOOLS.SANDBOX.EXECUTE_COMMAND]: {
      name: EXECUTE_COMMAND,
      backgroundProcesses: { abortSignal: false },
    },
    [WORKSPACE_TOOLS.SANDBOX.GET_PROCESS_OUTPUT]: {
      name: GET_PROCESS_OUTPUT,
    },
    [WORKSPACE_TOOLS.SANDBOX.KILL_PROCESS]: { name: KILL_PROCESS },
    [WORKSPACE_TOOLS.LSP.LSP_INSPECT]: { enabled: false },
  },
});

export const getSandbox = async (requestContext: RequestContext): Promise<E2BSandbox | undefined> =>
  await resolveE2BSandbox(workspace, requestContext);

export const requireSandbox = async (requestContext: RequestContext): Promise<E2BSandbox> => {
  const { threadId } = channelContext(requestContext);
  if (threadId === undefined || threadId === "") {
    throw new Error("No Slack thread bound for this run, so a sandbox tool cannot run here.");
  }
  const sandbox = await getSandbox(requestContext);
  if (!sandbox) {
    throw new Error("No sandbox available.");
  }
  await sandbox.ensureRunning();
  return sandbox;
};

export const pauseSandbox = async (requestContext: RequestContext): Promise<void> => {
  if (!usedSandbox(requestContext)) {
    return;
  }
  const { threadId } = channelContext(requestContext);
  try {
    const sandbox = await getSandbox(requestContext);
    await sandbox?.retryOnDead(() => sandbox.e2b.pause());
  } catch (error) {
    logger.debug("[sandbox] failed to pause", { error });
  }
  if (threadId !== undefined && threadId !== "") {
    workspace.clearSandboxCache(threadId);
  }
};
