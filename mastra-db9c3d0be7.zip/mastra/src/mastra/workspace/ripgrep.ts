import path from "node:path";
import type {
  FilesystemGrepMatch,
  FilesystemGrepOptions,
  FilesystemGrepResult,
} from "@mastra/core/workspace";
import { UnsupportedGrepPatternError } from "@mastra/core/workspace";
import { z } from "zod";

const outputByteLimit = 16 * 1024 * 1024;

const sh = (value: string): string => `'${value.replaceAll("'", "'\\''")}'`;

const arbitraryData = z.union([z.object({ text: z.string() }), z.object({ bytes: z.string() })]);

const ripgrepEvent = z.discriminatedUnion("type", [
  z.object({
    data: z.object({
      line_number: z.number(),
      lines: arbitraryData,
      path: arbitraryData,
      submatches: z.array(z.object({ start: z.number() })),
    }),
    type: z.enum(["match", "context"]),
  }),
  z.object({ type: z.enum(["begin", "end", "summary"]) }),
]);

const rawBytes = (data: z.infer<typeof arbitraryData>): Buffer =>
  "text" in data ? Buffer.from(data.text, "utf-8") : Buffer.from(data.bytes, "base64");

interface RipgrepSearch extends FilesystemGrepOptions {
  root: string;
}

export const ripgrepCommand = ({
  caseSensitive,
  contextLines = 0,
  includeHidden,
  maxCountPerFile,
  maxTotalMatches,
  pattern,
  root,
}: RipgrepSearch): string => {
  const args = [
    "rg",
    "--no-config",
    "--json",
    "--engine",
    "auto",
    "--sort",
    "path",
    caseSensitive ? "--case-sensitive" : "--ignore-case",
  ];
  if (includeHidden) {
    args.push("--hidden", "--glob", sh("!.git"));
  }
  if (maxCountPerFile !== undefined) {
    args.push("--max-count", String(Math.max(1, Math.ceil(maxCountPerFile))));
  }
  if (contextLines > 0) {
    args.push("--context", String(contextLines));
  }
  args.push("--regexp", sh(pattern), "--", sh(root));

  const caps = [];
  if (maxTotalMatches !== undefined) {
    caps.push(`head -n ${maxTotalMatches * (2 * contextLines + 3) + 1}`);
  }
  caps.push(`head -c ${outputByteLimit}`);

  return [
    `${args.join(" ")} | ${caps.join(" | ")}`,
    "status=$PIPESTATUS",
    'if [ "$status" -eq 1 ] || [ "$status" -eq 141 ]; then exit 0; fi',
    'exit "$status"',
  ].join("\n");
};

export const ripgrepFailure = (
  pattern: string,
  { exitCode, stderr }: { exitCode: number; stderr: string },
): Error => {
  if (/regex parse error|PCRE2|not allowed in a regex/u.test(stderr)) {
    return new UnsupportedGrepPatternError(pattern, stderr.trim());
  }
  return new Error(`ripgrep exited with ${exitCode}: ${stderr.trim()}`);
};

interface FileAccumulator {
  lines: Map<number, string>;
  matches: FilesystemGrepMatch[];
  path: string;
}

const contiguousLines = (
  lines: Map<number, string>,
  { count, from, step }: { count: number; from: number; step: 1 | -1 },
): string[] => {
  const found: string[] = [];
  let text = lines.get(from);
  while (text !== undefined && found.length < count) {
    found.push(text);
    text = lines.get(from + step * found.length);
  }
  return step === 1 ? found : found.toReversed();
};

const withContext = (file: FileAccumulator, contextLines: number): FilesystemGrepResult => ({
  path: file.path,
  matches: file.matches.map((match) =>
    contextLines === 0
      ? match
      : {
          ...match,
          after: contiguousLines(file.lines, {
            count: contextLines,
            from: match.line + 1,
            step: 1,
          }),
          before: contiguousLines(file.lines, {
            count: contextLines,
            from: match.line - 1,
            step: -1,
          }),
        },
  ),
});

export const parseRipgrepJson = (
  output: string,
  {
    contextLines = 0,
    maxTotalMatches = Number.POSITIVE_INFINITY,
    root,
  }: { contextLines?: number; maxTotalMatches?: number; root: string },
): FilesystemGrepResult[] => {
  const lines = output.split("\n");
  // The last segment is empty for complete output, or a line `head -c` cut short.
  lines.pop();
  const lineEvents = lines.flatMap((line) => {
    const event = ripgrepEvent.parse(JSON.parse(line));
    return event.type === "match" || event.type === "context" ? [event] : [];
  });

  const files: FileAccumulator[] = [];
  let total = 0;
  for (const event of lineEvents) {
    const filePath = path.posix.relative(root, rawBytes(event.data.path).toString("utf-8"));
    let file = files.at(-1);
    if (file?.path !== filePath) {
      if (total >= maxTotalMatches) {
        break;
      }
      file = { lines: new Map(), matches: [], path: filePath };
      files.push(file);
    }

    const bytes = rawBytes(event.data.lines);
    const text = bytes.toString("utf-8").replace(/\n$/u, "");
    file.lines.set(event.data.line_number, text);
    if (event.type === "match" && total < maxTotalMatches) {
      const start = event.data.submatches[0]?.start ?? 0;
      file.matches.push({
        column: bytes.subarray(0, start).toString("utf-8").length,
        line: event.data.line_number,
        text,
      });
      total += 1;
    }
  }
  return files.flatMap((file) =>
    file.matches.length > 0 ? [withContext(file, contextLines)] : [],
  );
};
