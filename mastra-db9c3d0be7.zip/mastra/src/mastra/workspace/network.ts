import type { E2BSandbox } from "@mastra/e2b";
import type { SandboxNetworkRule } from "e2b";
import { mintSandboxToken, repository, TOP_UP_BELOW_MS } from "../lib/github";
import { logger } from "../lib/logger";

const placeholder = Buffer.from(
  "nice try, we're not leaking real creds into a sandbox",
  "utf-8",
).toString("base64");

export const githubEnv = {
  GH_PROMPT_DISABLED: "1",
  GH_REPO: `${repository.owner}/${repository.name}`,
  GH_TOKEN: placeholder,
  GITHUB_TOKEN: placeholder,
  GIT_TERMINAL_PROMPT: "0",
} as const;

const grantedUntil = new WeakMap<E2BSandbox, number>();

export const grantGitHub = async (sandbox: E2BSandbox): Promise<void> => {
  try {
    const minted = await mintSandboxToken();
    if (minted === null) {
      return;
    }
    const bearer = [{ transform: { headers: { Authorization: `Bearer ${minted.token}` } } }];
    const basic = Buffer.from(`x-access-token:${minted.token}`, "utf-8").toString("base64");
    await sandbox.e2b.updateNetwork({
      rules: {
        "api.github.com": bearer,
        "github.com": [{ transform: { headers: { Authorization: `Basic ${basic}` } } }],
        "uploads.github.com": bearer,
      } satisfies Record<string, SandboxNetworkRule[]>,
    });
    grantedUntil.set(sandbox, minted.expiresAt);
  } catch (error) {
    logger.warn("[github] could not grant the sandbox GitHub access, so it runs without GitHub", {
      message: error instanceof Error ? error.message : String(error),
    });
  }
};

export const keepGitHubFresh = async (sandbox: E2BSandbox): Promise<void> => {
  const until = grantedUntil.get(sandbox);
  if (until !== undefined && until - Date.now() < TOP_UP_BELOW_MS) {
    await grantGitHub(sandbox);
  }
};
