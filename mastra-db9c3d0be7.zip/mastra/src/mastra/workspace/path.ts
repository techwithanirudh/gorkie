import path from "node:path";
import { sandbox } from "../config";

export const sandboxPath = (...parts: string[]): string =>
  path.posix.join(sandbox.workdir, ...parts);
