import path from "node:path";
import type {
  CopyOptions,
  FileContent,
  FileEntry,
  FileStat,
  FilesystemGrepOptions,
  FilesystemGrepResult,
  FilesystemInfo,
  ListOptions,
  ProviderStatus,
  ReadOptions,
  RemoveOptions,
  WriteOptions,
} from "@mastra/core/workspace";
import {
  DirectoryNotEmptyError,
  DirectoryNotFoundError,
  FileExistsError,
  FileNotFoundError,
  IsDirectoryError,
  MastraFilesystem,
  NotDirectoryError,
  PermissionError,
  StaleFileError,
  WorkspaceReadOnlyError,
} from "@mastra/core/workspace";
import type { E2BSandbox } from "@mastra/e2b";
import { CommandExitError, FileNotFoundError as E2BFileNotFoundError, FileType } from "e2b";
import { lookup } from "mime-types";
import { sandbox as config, file as fileLimits } from "../config";
import { parseRipgrepJson, ripgrepCommand, ripgrepFailure } from "./ripgrep";

interface FilesystemOptions {
  basePath?: string;
  readOnly?: boolean;
  sandbox: E2BSandbox;
}

const unknownModificationTime = (): Date => new Date(0);

export class E2BFilesystem extends MastraFilesystem {
  readonly id: string;
  readonly name = "E2BFilesystem";
  readonly provider = "e2b";
  readonly readOnly?: boolean;
  readonly basePath: string;
  status: ProviderStatus = "pending";

  constructor(options: FilesystemOptions) {
    super({ name: "E2BFilesystem" });
    this.id = `${options.sandbox.id}-filesystem`;
    this.basePath = path.posix.normalize(options.basePath ?? config.workdir);
    this.readOnly = options.readOnly;
    this.sandbox = options.sandbox;
  }

  private readonly sandbox: E2BSandbox;

  override async init(): Promise<void> {
    await this.sandbox.ensureRunning();
    await this.sandbox.retryOnDead(() => this.sandbox.e2b.files.makeDir(this.basePath));
  }

  async readFile(inputPath: string, options?: ReadOptions): Promise<string | Buffer> {
    await this.ensureReady();
    const filePath = this.resolve(inputPath);

    return await E2BFilesystem.attempt({
      absent: "file",
      inputPath,
      run: async () => {
        const info = await this.e2b(() => this.sandbox.e2b.files.getInfo(filePath));
        if (info.type === FileType.DIR) {
          throw new IsDirectoryError(inputPath);
        }
        if (info.size > fileLimits.maxReadBytes) {
          throw new Error(
            `${inputPath} is ${Math.round(info.size / 1_000_000)}MB, over the ${Math.round(fileLimits.maxReadBytes / 1_000_000)}MB read limit. Read a slice with execute_command (head, sed, tail) instead.`,
          );
        }

        if (options?.encoding) {
          if (options.encoding === "base64" || options.encoding === "hex") {
            const bytes = await this.e2b(() =>
              this.sandbox.e2b.files.read(filePath, { format: "bytes" }),
            );
            return Buffer.from(bytes).toString(options.encoding);
          }

          if (options.encoding === "binary") {
            const bytes = await this.e2b(() =>
              this.sandbox.e2b.files.read(filePath, { format: "bytes" }),
            );
            return Buffer.from(bytes).toString("binary");
          }

          return await this.e2b(() => this.sandbox.e2b.files.read(filePath, { format: "text" }));
        }

        const bytes = await this.e2b(() =>
          this.sandbox.e2b.files.read(filePath, { format: "bytes" }),
        );
        return Buffer.from(bytes);
      },
    });
  }

  async writeFile(inputPath: string, content: FileContent, options?: WriteOptions): Promise<void> {
    await this.ensureReady();
    this.assertWritable("writeFile");
    const filePath = this.resolve(inputPath);

    if (options?.recursive === false) {
      await this.assertParent({ filePath, inputPath });
    } else {
      await this.e2b(() => this.sandbox.e2b.files.makeDir(path.posix.dirname(filePath)));
    }

    if (options?.overwrite === false && (await this.exists(inputPath))) {
      throw new FileExistsError(inputPath);
    }

    const current = options?.expectedMtime ? await this.infoOrAbsent(filePath) : undefined;
    if (options?.expectedMtime && current) {
      const modifiedAt = current.modifiedTime ?? unknownModificationTime();
      if (modifiedAt.getTime() !== options.expectedMtime.getTime()) {
        throw new StaleFileError(inputPath, options.expectedMtime, modifiedAt);
      }
    }

    await this.e2b(() => this.sandbox.e2b.files.write(filePath, E2BFilesystem.e2bContent(content)));
  }

  async appendFile(inputPath: string, content: FileContent): Promise<void> {
    await this.ensureReady();
    this.assertWritable("appendFile");
    const filePath = this.resolve(inputPath);
    await this.e2b(() => this.sandbox.e2b.files.makeDir(path.posix.dirname(filePath)));
    const current = (await this.exists(inputPath))
      ? await this.e2b(() => this.sandbox.e2b.files.read(filePath, { format: "bytes" }))
      : new Uint8Array();
    await this.e2b(() =>
      this.sandbox.e2b.files.write(
        filePath,
        E2BFilesystem.e2bContent(Buffer.concat([Buffer.from(current), Buffer.from(content)])),
      ),
    );
  }

  async deleteFile(inputPath: string, options?: RemoveOptions): Promise<void> {
    await this.ensureReady();
    this.assertWritable("deleteFile");
    const filePath = this.resolve(inputPath);

    try {
      await E2BFilesystem.attempt({
        absent: "file",
        inputPath,
        run: async () => {
          const info = await this.e2b(() => this.sandbox.e2b.files.getInfo(filePath));
          if (info.type === FileType.DIR) {
            throw new IsDirectoryError(inputPath);
          }
          await this.e2b(() => this.sandbox.e2b.files.remove(filePath));
        },
      });
    } catch (error) {
      if (!(options?.force === true && error instanceof FileNotFoundError)) {
        throw error;
      }
    }
  }

  async copyFile(src: string, dest: string, options?: CopyOptions): Promise<void> {
    await this.ensureReady();
    this.assertWritable("copyFile");
    const srcPath = this.resolve(src);
    const destPath = this.resolve(dest);

    if (options?.overwrite === false && (await this.exists(dest))) {
      throw new FileExistsError(dest);
    }

    await E2BFilesystem.attempt({
      absent: "file",
      inputPath: src,
      run: async () => {
        const info = await this.e2b(() => this.sandbox.e2b.files.getInfo(srcPath));
        if (info.type === FileType.DIR) {
          throw new IsDirectoryError(src);
        }
        await this.e2b(() => this.sandbox.e2b.files.makeDir(path.posix.dirname(destPath)));
        const content = await this.e2b(() =>
          this.sandbox.e2b.files.read(srcPath, { format: "bytes" }),
        );
        await this.e2b(() =>
          this.sandbox.e2b.files.write(destPath, E2BFilesystem.e2bContent(content)),
        );
      },
    });
  }

  async moveFile(src: string, dest: string, options?: CopyOptions): Promise<void> {
    await this.ensureReady();
    this.assertWritable("moveFile");
    const srcPath = this.resolve(src);
    const destPath = this.resolve(dest);

    if (options?.overwrite === false && (await this.exists(dest))) {
      throw new FileExistsError(dest);
    }

    await this.e2b(() => this.sandbox.e2b.files.makeDir(path.posix.dirname(destPath)));
    await E2BFilesystem.attempt({
      absent: "file",
      inputPath: src,
      run: () => this.e2b(() => this.sandbox.e2b.files.rename(srcPath, destPath)),
    });
  }

  async mkdir(inputPath: string, options?: { recursive?: boolean }): Promise<void> {
    await this.ensureReady();
    this.assertWritable("mkdir");
    const dirPath = this.resolve(inputPath);

    if (options?.recursive === false) {
      await this.assertParent({ filePath: dirPath, inputPath });
    }

    const existing = await this.infoOrAbsent(dirPath);
    if (existing && existing.type !== FileType.DIR) {
      throw new FileExistsError(inputPath);
    }

    await this.e2b(() => this.sandbox.e2b.files.makeDir(dirPath));
  }

  async rmdir(inputPath: string, options?: RemoveOptions): Promise<void> {
    await this.ensureReady();
    this.assertWritable("rmdir");
    const dirPath = this.resolve(inputPath);

    try {
      await E2BFilesystem.attempt({
        absent: "directory",
        inputPath,
        run: async () => {
          const info = await this.e2b(() => this.sandbox.e2b.files.getInfo(dirPath));
          if (info.type !== FileType.DIR) {
            throw new NotDirectoryError(inputPath);
          }
          if (options?.recursive !== true) {
            const entries = await this.readdir(inputPath);
            if (entries.length > 0) {
              throw new DirectoryNotEmptyError(inputPath);
            }
          }
          await this.e2b(() => this.sandbox.e2b.files.remove(dirPath));
        },
      });
    } catch (error) {
      if (!(options?.force === true && error instanceof DirectoryNotFoundError)) {
        throw error;
      }
    }
  }

  async readdir(inputPath: string, options?: ListOptions): Promise<FileEntry[]> {
    await this.ensureReady();
    const dirPath = this.resolve(inputPath);

    return await E2BFilesystem.attempt({
      absent: "directory",
      inputPath,
      run: async () => {
        const info = await this.e2b(() => this.sandbox.e2b.files.getInfo(dirPath));
        if (info.type !== FileType.DIR) {
          throw new NotDirectoryError(inputPath);
        }

        const entries = await this.e2b(() =>
          this.sandbox.e2b.files.list(dirPath, {
            depth: options?.recursive === true ? (options.maxDepth ?? 100) : 1,
          }),
        );
        let extensions: string[] | undefined;
        if (Array.isArray(options?.extension)) {
          extensions = options.extension;
        } else if (options?.extension !== undefined && options.extension !== "") {
          extensions = [options.extension];
        }

        const results: FileEntry[] = [];
        for (const entry of entries) {
          const matchesExtension =
            extensions === undefined ||
            entry.type !== FileType.FILE ||
            extensions.some((ext) => {
              const normalized = ext.startsWith(".") ? ext : `.${ext}`;
              return entry.name.endsWith(normalized);
            });
          if (!matchesExtension) {
            continue;
          }
          results.push({
            name:
              options?.recursive === true ? path.posix.relative(dirPath, entry.path) : entry.name,
            type: entry.type === FileType.DIR ? "directory" : "file",
            size: entry.type === FileType.FILE ? entry.size : undefined,
            isSymlink: Boolean(entry.symlinkTarget) || undefined,
            symlinkTarget: entry.symlinkTarget,
          });
        }
        return results;
      },
    });
  }

  async exists(inputPath: string): Promise<boolean> {
    await this.ensureReady();
    return await this.e2b(() => this.sandbox.e2b.files.exists(this.resolve(inputPath)));
  }

  async stat(inputPath: string): Promise<FileStat> {
    await this.ensureReady();
    const filePath = this.resolve(inputPath);
    const info = await E2BFilesystem.attempt({
      absent: "file",
      inputPath,
      run: () => this.e2b(() => this.sandbox.e2b.files.getInfo(filePath)),
    });

    const mimeType = lookup(filePath);
    return {
      name: info.name,
      path: inputPath,
      type: info.type === FileType.DIR ? "directory" : "file",
      size: info.size,
      createdAt: info.modifiedTime ?? unknownModificationTime(),
      modifiedAt: info.modifiedTime ?? unknownModificationTime(),
      mimeType: mimeType === false || mimeType === "" ? undefined : mimeType,
    };
  }

  async grep(options: FilesystemGrepOptions): Promise<FilesystemGrepResult[]> {
    await this.ensureReady();
    const root = this.resolve(options.path);
    const command = ripgrepCommand({ ...options, root });

    try {
      const { stdout } = await this.e2b(() => this.sandbox.e2b.commands.run(command));
      return parseRipgrepJson(stdout, {
        contextLines: options.contextLines,
        maxTotalMatches: options.maxTotalMatches,
        root,
      });
    } catch (error) {
      if (error instanceof CommandExitError) {
        throw ripgrepFailure(options.pattern, error);
      }
      throw error;
    }
  }

  async realpath(inputPath: string): Promise<string> {
    return await Promise.resolve(this.resolve(inputPath));
  }

  getInfo(): FilesystemInfo<{ basePath: string }> {
    return {
      id: this.id,
      metadata: { basePath: this.basePath },
      name: this.name,
      provider: this.provider,
      readOnly: this.readOnly,
      status: this.status,
    };
  }

  getInstructions(): string {
    return `Filesystem tools read and write files inside the same E2B sandbox used by shell commands. Relative paths resolve under ${this.basePath}; absolute paths must stay under ${this.basePath}.`;
  }

  private resolve(inputPath: string): string {
    const resolved = path.posix.normalize(
      path.posix.isAbsolute(inputPath) ? inputPath : path.posix.join(this.basePath, inputPath),
    );
    if (!(resolved === this.basePath || resolved.startsWith(`${this.basePath}/`))) {
      throw new PermissionError(inputPath, "access");
    }
    return resolved;
  }

  private assertWritable(operation: string): void {
    if (this.readOnly === true) {
      throw new WorkspaceReadOnlyError(operation);
    }
  }

  private async assertParent({
    filePath,
    inputPath,
  }: {
    filePath: string;
    inputPath: string;
  }): Promise<void> {
    await E2BFilesystem.attempt({
      absent: "directory",
      inputPath: path.posix.dirname(inputPath),
      run: async () => {
        const info = await this.e2b(() =>
          this.sandbox.e2b.files.getInfo(path.posix.dirname(filePath)),
        );
        if (info.type !== FileType.DIR) {
          throw new NotDirectoryError(path.posix.dirname(inputPath));
        }
      },
    });
  }

  private static e2bContent(content: FileContent): string | ArrayBuffer {
    if (typeof content === "string") {
      return content;
    }
    const buffer = Buffer.from(content);
    return buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
  }

  private async e2b<T>(operation: () => Promise<T>): Promise<T> {
    return await this.sandbox.retryOnDead(operation);
  }

  private static missing(error: unknown): boolean {
    if (error instanceof E2BFileNotFoundError) {
      return true;
    }
    if (!(error instanceof Error)) {
      return false;
    }
    return error.name === "FileNotFoundError" || error.message.includes("[not_found]");
  }

  private async infoOrAbsent(
    filePath: string,
  ): Promise<Awaited<ReturnType<E2BSandbox["e2b"]["files"]["getInfo"]>> | null> {
    try {
      return await this.e2b(() => this.sandbox.e2b.files.getInfo(filePath));
    } catch (error) {
      if (E2BFilesystem.missing(error)) {
        return null;
      }
      throw error;
    }
  }

  private static async attempt<T>({
    absent,
    inputPath,
    run,
  }: {
    absent: "directory" | "file";
    inputPath: string;
    run: () => Promise<T>;
  }): Promise<T> {
    try {
      return await run();
    } catch (error) {
      if (!E2BFilesystem.missing(error)) {
        throw error;
      }
      const translated =
        absent === "directory"
          ? new DirectoryNotFoundError(inputPath)
          : new FileNotFoundError(inputPath);
      translated.cause = error;
      throw translated;
    }
  }
}
