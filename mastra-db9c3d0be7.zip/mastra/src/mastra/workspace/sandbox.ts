import { createHash } from "node:crypto";
import { E2BSandbox } from "@mastra/e2b";
import { env } from "@/env";
import { sandbox as config } from "../config";
import { sandboxPrompt } from "../prompts/features/sandbox";
import { githubEnv, grantGitHub } from "./network";
import { template } from "./template";

export const createSandbox = (threadId: string): E2BSandbox => {
  const id = `archy-${createHash("sha256").update(threadId).digest("hex").slice(0, 32)}`;

  return new E2BSandbox({
    apiKey: env.E2B_API_KEY,
    env: {
      SSL_CERT_FILE: "/usr/lib/ssl/cert.pem",
      ...githubEnv,
    },
    id,
    instructions: sandboxPrompt,
    metadata: { "thread-id": threadId },
    // Every create and resume: the rules are replaced with a freshly minted
    // token.
    onStart: async ({ sandbox }) => {
      if (sandbox instanceof E2BSandbox) {
        await grantGitHub(sandbox);
      }
    },
    template: template(),
    timeout: config.timeout,
  });
};
