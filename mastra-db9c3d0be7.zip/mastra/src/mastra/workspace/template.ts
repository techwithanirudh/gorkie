import { createRepoTemplate } from "@mastra/e2b";
import type { RepoTemplateOptions } from "@mastra/e2b";
import { mintCloneToken } from "../lib/github";
import { logger } from "../lib/logger";

const repoURL = "https://github.com/quiverai/quiverai-monorepo.git";

export const repoTemplateOptions: RepoTemplateOptions = {
  getRepositoryAccess: async () => {
    const token = await mintCloneToken();
    if (token === undefined) {
      logger.warn(
        "[workspace] no GitHub App configured, so the sandbox starts without a repository checkout",
      );
      throw new Error("GitHub App is not configured.");
    }
    return { authorization: { scheme: "bearer" as const, token }, cloneUrl: repoURL };
  },
  setupCommand: [
    "sudo apt-get update",
    "sudo apt-get install -y --no-install-recommends curl ca-certificates git fd-find ripgrep imagemagick ffmpeg python3-pip python3-pil expect zip unzip jq",
    // `fd-find` installs the binary as `fdfind` on Debian; archy is told `fd`.
    'if command -v fdfind >/dev/null 2>&1; then sudo ln -sf "$(command -v fdfind)" /usr/local/bin/fd; fi',
    // A cloned repository can carry hooks, and a hook runs whatever it likes
    // the first time a git command touches it.
    "sudo mkdir -p /etc/git/disabled-hooks && sudo git config --system core.hooksPath /etc/git/disabled-hooks",
    "curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg && sudo chmod go+r /usr/share/keyrings/githubcli-archive-keyring.gpg",
    'echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list >/dev/null && sudo apt-get update && sudo apt-get install -y gh',
    "python3 -m pip install --no-cache-dir --break-system-packages --no-user --upgrade pip",
    "python3 -m pip install --no-cache-dir --break-system-packages --no-user pillow matplotlib numpy pandas requests",
    // The template builder's base image carries a broken npm (every command
    // fails with "Class extends value undefined is not a constructor"), which a
    // regular sandbox from the same template does not show. Reinstalling Node
    // from the release tarball replaces npm with the copy bundled for that
    // release. Pinned to the repository's .nvmrc; agent-browser needs 24.
    'arch=$(uname -m | sed -e s/x86_64/x64/ -e s/aarch64/arm64/) && sudo rm -rf /usr/local/lib/node_modules/npm /usr/local/lib/node_modules/corepack && curl -fsSL "https://nodejs.org/dist/v24.15.0/node-v24.15.0-linux-$arch.tar.gz" | sudo tar -xz -C /usr/local --strip-components=1 && hash -r && node --version | grep -q "^v24\\." && npm --version',
    // npm reports a failed global install as a pointer to a debug log inside
    // the build VM, which nobody can read afterwards, so print it.
    "sudo npm install -g agent-browser wrangler || { sudo sh -c 'cat \"$(ls -t /root/.npm/_logs/*.log | head -1)\"'; exit 1; }",
    'sudo bash -lc "yes | agent-browser install --with-deps"',
  ],
};

export const template = () => createRepoTemplate(repoTemplateOptions);
