import { MCPClient } from "@mastra/mcp";
import { logger } from "../lib/logger";
import { linear } from "./linear";
import { posthog } from "./posthog";
import { admitVercel, vercel } from "./vercel";

// Every server pins `allowedHosts`. These URLs are constants rather than
// user-supplied configuration, so this is not guarding against an attacker
// choosing the address; it bounds where a redirect can take the client, and
// keeps the bearer token from following one somewhere else.
const client = new MCPClient({
  id: "mcp",
  servers: {
    linear,
    posthog,
    vercel,
  },
});
client.__setLogger(logger);

type McpTools = Awaited<ReturnType<MCPClient["listTools"]>>;

const listAdmitted = async (): Promise<McpTools> => {
  const tools: McpTools = {};
  for (const [id, tool] of Object.entries(await client.listTools())) {
    const admitted = admitVercel(id, tool);
    if (admitted) {
      tools[id] = admitted;
    }
  }
  return tools;
};

let listed: Promise<McpTools> | undefined;

export const mcpTools = async (): Promise<McpTools> => {
  listed ??= listAdmitted();
  return await listed;
};
