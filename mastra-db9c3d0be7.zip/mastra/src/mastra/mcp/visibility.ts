import { z } from "zod";

const mcpToolSchema = z.looseObject({
  mcp: z
    .looseObject({
      annotations: z.looseObject({ readOnlyHint: z.boolean().optional() }).optional(),
    })
    .optional(),
});

export type Visibility = "codeMode" | "direct";

// Mastra checks `requireApproval` in the agent's tool-call step, which code
// mode's dispatch does not go through: it calls `tool.execute()` directly. A
// write listed for code mode would run with no approval prompt, so anything not
// declaring itself read-only stays direct.
export const visibility = (tool: unknown): Visibility => {
  const parsed = mcpToolSchema.safeParse(tool);
  return parsed.success && parsed.data.mcp?.annotations?.readOnlyHint === true
    ? "codeMode"
    : "direct";
};
