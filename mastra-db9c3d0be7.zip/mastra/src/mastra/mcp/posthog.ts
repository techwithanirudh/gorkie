import type { MastraMCPServerDefinition } from "@mastra/mcp";
import { env } from "@/env";

const tools = [
  "execute-sql",
  "read-data-schema",
  "query-trends",
  "insight-query",
  "insights-list",
  "insight-get",
  "dashboards-get-all",
  "dashboard-get",
  "dashboard-insights-run",
  "query-error-tracking-issues-list",
  "query-error-tracking-issue",
  "query-error-tracking-issue-events",
  "feature-flag-get-definition-by-key",
  "experiment-list",
  "experiment-get",
  "experiment-results-get",
];

export const posthog: MastraMCPServerDefinition = {
  allowedHosts: ["mcp.posthog.com"],
  requestInit: {
    headers: {
      Accept: "application/json, text/event-stream",
      Authorization: `Bearer ${env.POSTHOG_API_KEY}`,
      "x-posthog-read-only": "true",
    },
  },
  url: new URL(`https://mcp.posthog.com/mcp?readonly=true&mode=tools&tools=${tools.join(",")}`),
};
