import type { MastraMCPServerDefinition } from "@mastra/mcp";
import { env } from "@/env";
import { readsOnly } from "./tool-approval";

export const linear: MastraMCPServerDefinition = {
  allowedHosts: ["mcp.linear.app"],
  requestInit: {
    headers: {
      Accept: "application/json, text/event-stream",
      Authorization: `Bearer ${env.LINEAR_API_KEY}`,
    },
  },
  requireToolApproval: readsOnly("linear"),
  url: new URL("https://mcp.linear.app/mcp"),
};
