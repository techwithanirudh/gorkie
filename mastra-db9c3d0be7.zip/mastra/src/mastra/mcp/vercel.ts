import { createTool } from "@mastra/core/tools";
import type { Tool } from "@mastra/core/tools";
import type { MastraMCPServerDefinition } from "@mastra/mcp";
import { z } from "zod";
import { env } from "@/env";

export const vercel: MastraMCPServerDefinition = {
  allowedHosts: ["mcp.vercel.com"],
  requestInit: {
    headers: {
      Accept: "application/json, text/event-stream",
      Authorization: `Bearer ${env.VERCEL_TOKEN}`,
    },
  },
  url: new URL("https://mcp.vercel.com"),
};

const reads = new Set([
  "vercel_get_deployment",
  "vercel_get_runtime_errors",
  "vercel_get_runtime_logs",
  "vercel_list_deployment_events",
  "vercel_list_deployments",
  "vercel_list_projects",
]);

const teamArguments = new Set(["slug", "teamId"]);

const objectSchema = z.looseObject({
  properties: z.record(z.string(), z.union([z.boolean(), z.looseObject({})])).default({}),
  required: z.array(z.string()).default([]),
});

// Vercel prints a request ID as `<region>::<id>`, and `x-vercel-id` can chain
// several regions, but the runtime-log filter matches only the last segment.
const argumentsSchema = z.looseObject({
  requestId: z
    .string()
    .transform((id) => id.split("::").at(-1) ?? id)
    .optional(),
});

const withoutTeam = <T>(entries: Record<string, T>): Record<string, T> =>
  Object.fromEntries(Object.entries(entries).filter(([name]) => !teamArguments.has(name)));

const scopeToTeam = (tool: Tool): Tool => {
  const schema = objectSchema.parse(
    tool.inputSchema?.["~standard"].jsonSchema.input({ target: "draft-2020-12" }),
  );
  return createTool({
    id: tool.id,
    description: tool.description,
    mcp: { annotations: { readOnlyHint: true } },
    inputSchema: {
      ...schema,
      properties: withoutTeam(schema.properties),
      required: schema.required.filter((name) => !teamArguments.has(name)),
      type: "object",
    },
    execute: async (input, context) =>
      await tool.execute?.(
        { ...withoutTeam(argumentsSchema.parse(input)), teamId: env.VERCEL_TEAM_ID },
        context,
      ),
  });
};

// Vercel annotates secret-returning tools such as `get_project_env` as read-only,
// so its tools are admitted by name and their annotations replaced.
export const admitVercel = (id: string, tool: Tool): Tool | undefined => {
  if (!id.startsWith("vercel_")) {
    return tool;
  }
  return reads.has(id) ? scopeToTeam(tool) : undefined;
};
