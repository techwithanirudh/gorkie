import { logger } from "../lib/logger";

interface ApprovalContext {
  annotations?: { destructiveHint?: boolean; readOnlyHint?: boolean };
  toolName: string;
}

// The MCP spec treats annotations as advisory, so `readOnlyHint` may only relax
// approval, never grant a write: anything that does not declare itself a read
// needs a person.
export const readsOnly =
  (server: string) =>
  ({ annotations, toolName }: ApprovalContext): boolean => {
    if (annotations?.destructiveHint !== true && annotations?.readOnlyHint === true) {
      return false;
    }
    logger.info("[mcp] tool needs approval", { server, toolName });
    return true;
  };
