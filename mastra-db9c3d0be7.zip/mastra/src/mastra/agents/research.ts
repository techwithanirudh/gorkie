import { Agent } from "@mastra/core/agent";
import { ProviderHistoryCompat, TokenLimiterProcessor } from "@mastra/core/processors";
import { InMemoryStore } from "@mastra/core/storage";
import { Memory } from "@mastra/memory";
import { agent as config } from "../config";
import { defaultErrorProcessors } from "../lib/error-handling";
import { stepCountIs } from "../lib/tools";
import { sandbox } from "../processors/sandbox";
import { moveToolImages } from "../processors/tool-media";
import { description, prompt } from "../prompts/agents/research";
import { models } from "../providers";
import { fetchUrlTool } from "../tools/fetch-url";
import { searchWebTool } from "../tools/search-web";
import { slackTools } from "../tools/slack";

export const researchAgent = new Agent({
  defaultOptions: {
    autoResumeSuspendedTools: true,
    modelSettings: {
      maxOutputTokens: 16_384,
      maxRetries: 5,
      reasoning: "medium",
      timeout: config.modelTimeout,
    },
    stopWhen: stepCountIs(config.maxSteps),
  },
  description,
  errorProcessors: defaultErrorProcessors(),
  id: "research",
  inputProcessors: [
    new TokenLimiterProcessor({
      limit: config.maxTokens.input,
      trimMode: "contiguous",
    }),
    new ProviderHistoryCompat({ additionalRules: [moveToolImages] }),
  ],
  instructions: () => [prompt],
  maxProcessorRetries: 2,
  memory: new Memory({ storage: new InMemoryStore() }),
  model: models,
  name: "Research",
  outputProcessors: [sandbox],
  tools: () => ({
    search_web: searchWebTool,
    fetch_url: fetchUrlTool,
    search_slack: slackTools.search_slack,
    read_conversation_history: slackTools.read_conversation_history,
    get_user: slackTools.get_user,
    get_channel_info: slackTools.get_channel_info,
    get_permalink: slackTools.get_permalink,
    summarize_thread: slackTools.summarize_thread,
  }),
});
