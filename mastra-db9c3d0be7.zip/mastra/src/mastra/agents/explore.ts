import { Agent } from "@mastra/core/agent";
import { ProviderHistoryCompat, TokenLimiterProcessor } from "@mastra/core/processors";
import { InMemoryStore } from "@mastra/core/storage";
import { Memory } from "@mastra/memory";
import { agent as config } from "../config";
import { defaultErrorProcessors } from "../lib/error-handling";
import { stepCountIs } from "../lib/tools";
import { sandbox } from "../processors/sandbox";
import { moveToolImages } from "../processors/tool-media";
import { description, prompt } from "../prompts/agents/explore";
import { models } from "../providers";
import { fetchUrlTool } from "../tools/fetch-url";
import { searchWebTool } from "../tools/search-web";
import { workspace } from "../workspace";

export const exploreAgent = new Agent({
  defaultOptions: {
    activeTools: [
      "read_file",
      "write_file",
      "edit_file",
      "delete_file",
      "list_files",
      "grep",
      "file_stat",
      "search_web",
      "fetch_url",
    ],
    autoResumeSuspendedTools: true,
    modelSettings: {
      maxOutputTokens: 16_384,
      maxRetries: 5,
      reasoning: "medium",
      timeout: config.modelTimeout,
      topP: 0.95,
    },
    stopWhen: stepCountIs(config.maxSteps),
  },
  description,
  errorProcessors: defaultErrorProcessors(),
  id: "explore",
  inputProcessors: [
    new TokenLimiterProcessor({
      limit: config.maxTokens.input,
      trimMode: "contiguous",
    }),
    new ProviderHistoryCompat({ additionalRules: [moveToolImages] }),
  ],
  instructions: prompt,
  maxProcessorRetries: 2,
  memory: new Memory({ storage: new InMemoryStore() }),
  model: models,
  name: "Explore",
  outputProcessors: [sandbox],
  tools: {
    fetch_url: fetchUrlTool,
    search_web: searchWebTool,
  },
  workspace,
});
