import type { ProcessOutputResultArgs, ProcessToolResultArgs } from "@mastra/core/processors";
import { sandbox as sandboxConfig } from "../config";
import { logger } from "../lib/logger";
import { getSandbox, pauseSandbox, usedSandbox, workspaceToolNames } from "../workspace";
import { keepGitHubFresh } from "../workspace/network";

export const sandbox = {
  description:
    "Extends sandbox lifetime during active tool use, then pauses it once the turn finishes.",
  id: "sandbox",
  name: "Sandbox Lifecycle",
  async processOutputResult(args: ProcessOutputResultArgs) {
    const { requestContext, messages } = args;
    if (requestContext) {
      await pauseSandbox(requestContext);
    }
    return messages;
  },
  async processToolResult(args: ProcessToolResultArgs) {
    const { requestContext, toolName } = args;
    if (!requestContext) {
      return;
    }
    if (!(usedSandbox(requestContext) || workspaceToolNames.has(toolName))) {
      return;
    }
    try {
      const activeSandbox = await getSandbox(requestContext);
      await activeSandbox?.retryOnDead(() => activeSandbox.e2b.setTimeout(sandboxConfig.timeout));
      if (activeSandbox) {
        await keepGitHubFresh(activeSandbox);
      }
    } catch (error) {
      logger.debug("[sandbox] failed to extend lifetime", { error });
    }
  },
};
