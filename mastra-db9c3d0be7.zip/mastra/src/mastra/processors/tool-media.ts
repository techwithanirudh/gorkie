import type { CompatRule } from "@mastra/core/processors";
import { image as imageLimits } from "../config";

interface MediaPart {
  data: string;
  mediaType: string;
  type: "media";
}

type Prompt = Parameters<NonNullable<CompatRule["applyToPrompt"]>>[0]["prompt"];
type ToolMessage = Extract<Prompt[number], { role: "tool" }>;

const byteLength = (base64: string): number => Math.ceil((base64.length * 3) / 4);

const collectToolImages = (prompt: Prompt): MediaPart[] => {
  const found: MediaPart[] = [];
  for (const message of prompt) {
    if (message.role !== "tool") {
      continue;
    }
    for (const part of message.content) {
      if (part.type !== "tool-result" || part.output.type !== "content") {
        continue;
      }
      for (const item of part.output.value) {
        if (item.type === "media" && item.mediaType.startsWith("image/")) {
          found.push(item);
        }
      }
    }
  }
  return found;
};

const keepWithinLimits = (found: MediaPart[]): Set<MediaPart> => {
  const keep = new Set<MediaPart>();
  let bytes = 0;
  for (const media of found.toReversed()) {
    const size = byteLength(media.data);
    if (keep.size >= imageLimits.maxContextImages || bytes + size > imageLimits.maxContextBytes) {
      break;
    }
    keep.add(media);
    bytes += size;
  }
  return keep;
};

const stripToolImages = (message: ToolMessage, keep: Set<MediaPart>) => {
  const relocated: MediaPart[] = [];
  const content = message.content.map((part) => {
    if (part.type !== "tool-result" || part.output.type !== "content") {
      return part;
    }
    let keptImage = false;
    let droppedImage = false;
    const kept = part.output.value.filter((item) => {
      if (item.type === "media" && item.mediaType.startsWith("image/")) {
        if (keep.has(item)) {
          relocated.push(item);
          keptImage = true;
        } else {
          droppedImage = true;
        }
        return false;
      }
      return true;
    });
    if (kept.length === part.output.value.length) {
      return part;
    }
    if (keptImage) {
      kept.push({
        type: "text",
        text: "Image attached in the following message.",
      });
    }
    if (droppedImage) {
      kept.push({
        type: "text",
        text: "Image omitted to stay within the model's image limit. Call view_image on the file again if you still need it.",
      });
    }
    return { ...part, output: { ...part.output, value: kept } };
  });
  return { content, relocated };
};

const relocateToolImages = (prompt: Prompt, keep: Set<MediaPart>): Prompt => {
  const next: Prompt = [];
  for (const message of prompt) {
    if (message.role !== "tool") {
      next.push(message);
      continue;
    }
    const { content, relocated } = stripToolImages(message, keep);
    next.push({ ...message, content });
    if (relocated.length > 0) {
      next.push({
        role: "user",
        content: [
          { type: "text", text: "Attached media from tool result:" },
          ...relocated.map((media) => ({
            type: "file" as const,
            data: media.data,
            mediaType: media.mediaType,
          })),
        ],
      });
    }
  }
  return next;
};

// OpenAI-compatible gateways drop media parts in tool results.
export const moveToolImages: CompatRule = {
  applyToPrompt({ prompt }) {
    const found = collectToolImages(prompt);
    return found.length === 0 ? undefined : relocateToolImages(prompt, keepWithinLimits(found));
  },
  name: "move-tool-images",
};
