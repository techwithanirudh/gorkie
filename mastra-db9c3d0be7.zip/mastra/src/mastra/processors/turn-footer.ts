import type { ProcessOutputResultArgs, ProcessOutputStreamArgs } from "@mastra/core/processors";
import { formatDuration } from "date-fns/formatDuration";
import { intervalToDuration } from "date-fns/intervalToDuration";
import { z } from "zod";
import { slack } from "../chat/client";
import { channelContext } from "../lib/context";
import { logger } from "../lib/logger";

export const turnFooter = {
  description: "Closes a turn with how long it took and a thumbs rating for the response.",
  id: "turn-footer",
  name: "Turn Footer",
  async processOutputResult(args: ProcessOutputResultArgs) {
    const { threadId } = channelContext(args.requestContext);
    const startTime = z.number().safeParse(args.state.startTime);
    const skipped = args.result.steps.some((step) =>
      step.toolResults.some((result) => result.payload.toolName === "skip"),
    );

    const answered = threadId !== undefined && threadId !== "" && args.result.text.trim() !== "";
    const unprompted = args.requestContext?.get("unprompted") === true;

    if (unprompted || skipped || !answered || !startTime.success) {
      return args.messages;
    }

    const elapsed = formatDuration(intervalToDuration({ start: startTime.data, end: Date.now() }), {
      format: ["hours", "minutes", "seconds"],
    });
    const text = `done in ${elapsed || "under a second"}`;
    try {
      await slack.postBlocks({
        blocks: [
          {
            type: "context",
            elements: [{ type: "mrkdwn", text: `_${text}_` }],
          },
        ],
        text,
        threadId,
      });
    } catch (error) {
      logger.warn("[turn-footer] failed to post", { threadId, error });
    }
    return args.messages;
  },
  processOutputStream: (args: ProcessOutputStreamArgs) => {
    args.state.startTime ??= Date.now();
    return Promise.resolve(args.part);
  },
};
