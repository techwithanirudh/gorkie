import type { ProcessOutputStreamArgs } from "@mastra/core/processors";
import type { ChunkType } from "@mastra/core/stream";
import { z } from "zod";

const delegatedToolChunk = z.looseObject({
  payload: z.looseObject({
    toolCallId: z.string(),
    toolName: z.string(),
  }),
  type: z.enum(["tool-call", "tool-result", "tool-error"]),
});

type DelegatedToolChunk = Extract<ChunkType, { type: "tool-call" | "tool-result" | "tool-error" }>;

const isDelegatedToolChunk = (value: unknown): value is DelegatedToolChunk =>
  delegatedToolChunk.safeParse(value).success;

const renameTool = <Chunk extends DelegatedToolChunk>(
  chunk: Chunk,
  toolCallId: string,
  toolName: string,
): Chunk => ({ ...chunk, payload: { ...chunk.payload, toolCallId, toolName } });

const relabelDelegatedTool = (part: ChunkType): ChunkType => {
  if (part.type !== "tool-output") {
    return part;
  }

  const output: unknown = part.payload.output;
  if (!isDelegatedToolChunk(output)) {
    return part;
  }

  return renameTool(
    output,
    `${part.payload.toolCallId}::${output.payload.toolCallId}`,
    `${part.payload.toolName ?? "agent"}_${output.payload.toolName}`,
  );
};

export const delegatedTools = {
  description: "Keeps delegated tool cards distinct in transcripts.",
  id: "delegated-tools",
  name: "Delegated Tool Output",
  processOutputStream: ({ part }: ProcessOutputStreamArgs) =>
    Promise.resolve(relabelDelegatedTool(part)),
};
