import "dotenv/config";
import path from "node:path";
import { createEnv } from "@t3-oss/env-core";
import { z } from "zod";
import { resolveFromPackageRoot } from "./package-root";

const FILE_SCHEME = "file:";

const resolveDatabaseUrl = (url: string): string => {
  const target = url.slice(FILE_SCHEME.length);
  return url.startsWith(FILE_SCHEME) && !path.isAbsolute(target)
    ? `${FILE_SCHEME}${resolveFromPackageRoot(target)}`
    : url;
};

const redisUrlSchema = z.url({
  error: "must be a redis:// or rediss:// URL",
  protocol: /^rediss?$/u,
});

export const env = createEnv({
  createFinalSchema: (variables) =>
    z.object(variables).transform((parsed, context) => {
      const {
        GITHUB_APP_ID: appId,
        GITHUB_APP_INSTALLATION_ID: installationId,
        GITHUB_APP_PRIVATE_KEY: privateKey,
        LANGFUSE_BASE_URL: baseUrl,
        LANGFUSE_PUBLIC_KEY: publicKey,
        LANGFUSE_SECRET_KEY: secretKey,
        ...rest
      } = parsed;
      if (rest.VERCEL !== undefined && rest.MASTRA_API_TOKEN === undefined) {
        context.issues.push({
          code: "custom",
          input: rest.VERCEL,
          message:
            "MASTRA_API_TOKEN must be set on Vercel: it is the only credential the Mastra HTTP API accepts, and nothing else in front of the deployment authenticates it.",
        });
      }
      if (rest.VERCEL !== undefined && rest.REDIS_URL === undefined) {
        context.issues.push({
          code: "custom",
          input: rest.VERCEL,
          message:
            "REDIS_URL must be set on Vercel: the chat SDK dedupes Slack events and locks threads in its state store, and an in-memory store cannot see across serverless instances, so archy would answer one message twice.",
        });
      }
      const LANGFUSE =
        publicKey !== undefined && secretKey !== undefined
          ? { baseUrl, publicKey, secretKey }
          : null;
      if (rest.VERCEL !== undefined && LANGFUSE === null) {
        context.issues.push({
          code: "custom",
          input: rest.VERCEL,
          message:
            "LANGFUSE_PUBLIC_KEY and LANGFUSE_SECRET_KEY must be set on Vercel: the DuckDB trace store needs a disk that survives, so Langfuse is the only exporter there.",
        });
      } else if (LANGFUSE === null && (publicKey ?? secretKey) !== undefined) {
        const unset = publicKey === undefined ? "LANGFUSE_PUBLIC_KEY" : "LANGFUSE_SECRET_KEY";
        context.issues.push({
          code: "custom",
          input: unset,
          message: `${unset} must be set: LANGFUSE_PUBLIC_KEY and LANGFUSE_SECRET_KEY are set together or not at all.`,
        });
      }
      if (appId !== undefined && installationId !== undefined && privateKey !== undefined) {
        return { ...rest, GITHUB_APP: { appId, installationId, privateKey }, LANGFUSE };
      }
      const missing = Object.entries({
        GITHUB_APP_ID: appId,
        GITHUB_APP_PRIVATE_KEY: privateKey,
        GITHUB_APP_INSTALLATION_ID: installationId,
      }).flatMap(([name, value]) => (value === undefined ? [name] : []));
      if (missing.length < 3) {
        context.issues.push({
          code: "custom",
          input: missing,
          message: `${missing.join(", ")} must be set: GITHUB_APP_ID, GITHUB_APP_PRIVATE_KEY and GITHUB_APP_INSTALLATION_ID are set together or not at all.`,
        });
        return z.NEVER;
      }
      return { ...rest, GITHUB_APP: null, LANGFUSE };
    }),
  emptyStringAsUndefined: true,
  runtimeEnv: process.env,
  server: {
    NODE_ENV: z.enum(["development", "production", "test"]).default("development"),

    // Set by the platform on every Vercel runtime and by nothing else.
    VERCEL: z.string().min(1).optional(),

    SLACK_BOT_TOKEN: z.string().min(1),
    SLACK_SIGNING_SECRET: z.string().min(1),
    SLACK_USER_TOKEN: z.string().min(1),

    // Inference routes through Cloudflare Workers AI. Mastra's model router
    // reads both when resolving a `cloudflare-workers-ai/...` id, so nothing in
    // this package constructs a provider client. The account id is not
    // optional: the endpoint is per-account and a missing one is a 404, not an
    // auth error.
    CLOUDFLARE_API_KEY: z.string().min(1),
    CLOUDFLARE_ACCOUNT_ID: z.string().min(1),

    LINEAR_API_KEY: z.string().min(1),
    POSTHOG_API_KEY: z.string().min(1),

    // Traces go to Langfuse. The Langfuse SDK reads these names from the
    // environment on its own; they are declared here so the pairing and the
    // Vercel requirement are checked at startup.
    LANGFUSE_PUBLIC_KEY: z.string().min(1).optional(),
    LANGFUSE_SECRET_KEY: z.string().min(1).optional(),
    LANGFUSE_BASE_URL: z.url().optional(),

    DATABASE_URL: z.string().min(1).transform(resolveDatabaseUrl),
    DATABASE_AUTH_TOKEN: z.string().min(1).optional(),

    MASTRA_API_TOKEN: z.string().min(32, "must be at least 32 characters").optional(),

    // Shared chat state: thread subscriptions, dedupe keys, thread locks and
    // caches. Unset keeps them in process, which is right for one local server
    // and wrong for Vercel, where the two copies of a tagged Slack message land
    // on different instances.
    REDIS_URL: redisUrlSchema.optional(),

    GITHUB_APP_ID: z.string().min(1).optional(),
    GITHUB_APP_PRIVATE_KEY: z
      .string()
      .min(1)
      .transform((pem) => pem.replaceAll(String.raw`\n`, "\n"))
      .optional(),
    GITHUB_APP_INSTALLATION_ID: z.string().min(1).optional(),

    E2B_API_KEY: z
      .string()
      .regex(/^e2b_[0-9a-f]+$/u, 'must be an E2B API key: "e2b_" followed by hex characters'),

    EXA_API_KEY: z.string().min(1),

    VERCEL_TOKEN: z.string().min(1),
    VERCEL_TEAM_ID: z.string().min(1),

    RELEVANCE_ENGINE_ENABLED: z.stringbool().optional().default(false),
    RELEVANCE_ENGINE_CHANNELS: z.string().optional(),
  },
});
