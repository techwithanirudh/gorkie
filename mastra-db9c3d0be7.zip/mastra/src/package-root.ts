import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { z } from "zod";

const PACKAGE_NAME = "@quiverai/mastra";

const manifest = z.object({ name: z.string().optional() });

// Walks up to this package's own manifest rather than applying a fixed offset,
// because the offset differs by runtime: `src/` under vitest, and the flat
// `.mastra/output/` bundle under both `mastra dev` and `mastra start`. The
// bundle carries a `package.json` of its own, named `server`, so the first
// manifest found is not necessarily this package's.
const findPackageRoot = (from: string): string => {
  const candidate = path.join(from, "package.json");
  if (
    existsSync(candidate) &&
    manifest.parse(JSON.parse(readFileSync(candidate, "utf-8"))).name === PACKAGE_NAME
  ) {
    return from;
  }
  const parent = path.dirname(from);
  if (parent === from) {
    throw new Error(`No ${PACKAGE_NAME} package.json above ${import.meta.dirname}.`);
  }
  return findPackageRoot(parent);
};

export const resolveFromPackageRoot = (target: string): string =>
  path.isAbsolute(target)
    ? path.normalize(target)
    : path.resolve(findPackageRoot(import.meta.dirname), target);
